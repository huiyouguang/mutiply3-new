var obsidian = require("obsidian");

const RECENT_FILES_PLUGIN_ID = "recent-files-obsidian";
const VIEW_TYPE = "recent-files";

const DEFAULT_SETTINGS = {
  showBorder: true,
  borderStyle: "solid",
  borderWidth: 3,
  borderRadius: 4,
  colorSource: "folder",
  showIcon: true,
  customIcon: "",
  textColor: "",
  textBold: false,
  hoverAnimation: true,
  hoverScale: 1.02,
  hoverShift: 4,
  rainbowColors: ["#FF6B6B", "#FFD93D", "#6BCB77", "#4D96FF", "#7C3AED", "#EC4899"],
};

class RecentFilesColorizer extends obsidian.Plugin {
  constructor() {
    super(...arguments);
    this.settings = DEFAULT_SETTINGS;
    this.colorConfig = {};
    this.observer = null;
  }

  async onload() {
    console.log("[RecentFilesColorizer] Loading...");

    // 修复: 使用 loadData() 而不是 loadDataJson()
    try {
      const data = await this.loadData();
      if (data) {
        this.settings = Object.assign({}, DEFAULT_SETTINGS, data);
      }
    } catch (e) {
      console.error("[RecentFilesColorizer] Load settings error:", e);
    }

    await this.loadColorConfig();

    this.addSettingTab(new RecentFilesColorizerSettingTab(this.app, this));

    // 注册视图事件 — 当 Recent Files 面板打开时应用颜色
    this.registerEvent(
      this.app.workspace.on("layout-change", () => {
        setTimeout(() => this.applyToAllViews(), 200);
      })
    );

    this.registerEvent(
      this.app.workspace.on("file-open", () => {
        setTimeout(() => this.applyToAllViews(), 200);
      })
    );

    // 使用 MutationObserver 监听 Recent Files 面板的变化
    this.setupMutationObserver();

    // 初始加载
    this.app.workspace.onLayoutReady(() => {
      setTimeout(() => this.applyToAllViews(), 500);
      setTimeout(() => this.applyToAllViews(), 1500);
      setTimeout(() => this.applyToAllViews(), 3000);
    });

    this.addCommand({
      id: "refresh-colors",
      name: "刷新颜色",
      callback: async () => {
        await this.loadColorConfig();
        this.applyToAllViews();
        new obsidian.Notice("颜色已刷新");
      },
    });

    // 定时轮询作为兜底方案
    this.registerInterval(
      window.setInterval(() => {
        this.applyToAllViews();
      }, 5000)
    );

    console.log("[RecentFilesColorizer] Loaded!");
  }

  onunload() {
    // 清理 MutationObserver
    if (this.observer) {
      this.observer.disconnect();
      this.observer = null;
    }
    console.log("[RecentFilesColorizer] Unloaded!");
  }

  setupMutationObserver() {
    this.observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        if (mutation.type === "childList" && mutation.addedNodes.length > 0) {
          for (const node of mutation.addedNodes) {
            if (node.nodeType === Node.ELEMENT_NODE) {
              // 检查是否包含 recent-files 相关元素
              if (node.querySelector && (
                node.querySelector(".recent-files-file") ||
                node.querySelector(".recent-files-title") ||
                node.classList.contains("recent-files-file")
              )) {
                setTimeout(() => this.applyToAllViews(), 100);
                return;
              }
            }
          }
        }
      }
    });

    // 在 workspace 容器上监听
    const container = this.app.workspace.containerEl;
    if (container) {
      this.observer.observe(container, {
        childList: true,
        subtree: true,
      });
    }
  }

  async loadColorConfig() {
    try {
      const path = ".obsidian/plugins/color-folders-files/data.json";
      if (await this.app.vault.adapter.exists(path)) {
        const content = await this.app.vault.adapter.read(path);
        const data = JSON.parse(content);
        if (data && data.styles) this.colorConfig = data.styles;
        console.log("[RecentFilesColorizer] Color config loaded, styles:", Object.keys(this.colorConfig).length);
      }
    } catch (e) {
      console.warn("[RecentFilesColorizer] Failed to load color config:", e);
    }
  }

  getRecentFilesData() {
    try {
      const plugin = this.app.plugins.getPlugin(RECENT_FILES_PLUGIN_ID);
      if (!plugin) {
        console.log("[RecentFilesColorizer] Recent Files plugin not found");
        return [];
      }
      // 尝试多种方式获取最近文件数据
      if (plugin.data && plugin.data.recentFiles) {
        return plugin.data.recentFiles;
      }
      if (plugin.recentFiles) {
        return plugin.recentFiles;
      }
      if (plugin.settings && plugin.settings.recentFiles) {
        return plugin.settings.recentFiles;
      }
      console.log("[RecentFilesColorizer] Recent files data not found in plugin", Object.keys(plugin));
    } catch (e) {
      console.warn("[RecentFilesColorizer] Error getting recent files:", e);
    }
    return [];
  }

  applyToAllViews() {
    const leaves = this.app.workspace.getLeavesOfType(VIEW_TYPE);
    if (leaves.length === 0) {
      // 尝试备用视图类型
      const altLeaves = this.app.workspace.getLeavesOfType("recent-files-obsidian");
      for (const leaf of altLeaves) {
        if (leaf.view && leaf.view.containerEl) {
          this.applyColorsToView(leaf.view.containerEl);
        }
      }
      return;
    }
    for (const leaf of leaves) {
      if (leaf.view && leaf.view.containerEl) {
        this.applyColorsToView(leaf.view.containerEl);
      }
    }
  }

  applyColorsToView(viewElement) {
    const recentFiles = this.getRecentFilesData();
    if (recentFiles.length === 0) return;

    // 兼容多种可能的 DOM 选择器
    let items = viewElement.querySelectorAll(".recent-files-file.tree-item.nav-file");
    if (items.length === 0) {
      items = viewElement.querySelectorAll(".recent-files-file");
    }
    if (items.length === 0) {
      items = viewElement.querySelectorAll(".tree-item.nav-file");
    }
    if (items.length === 0) {
      items = viewElement.querySelectorAll(".nav-file");
    }

    items.forEach((item, index) => {
      const fileData = recentFiles[index];
      if (!fileData) return;

      const style = this.findMatchingStyle(fileData.path);
      const rainbowColor = this.settings.rainbowColors[index % this.settings.rainbowColors.length];
      this.applyStyleToItem(item, style, rainbowColor, index);
    });
  }

  findMatchingStyle(filePath) {
    if (!this.colorConfig || !filePath) return null;

    const lastSlash = filePath.lastIndexOf("/");
    const folderPath = lastSlash >= 0 ? filePath.substring(0, lastSlash) : "";
    const fileName = filePath.substring(lastSlash + 1);

    const segments = folderPath.split("/").filter(s => s.length > 0);

    // Try full path match from most specific to least
    for (let i = segments.length; i >= 1; i--) {
      const path = segments.slice(0, i).join("/");
      if (this.colorConfig[path]) return this.colorConfig[path];
    }

    // Try last folder name
    if (segments.length > 0 && this.colorConfig[segments[segments.length - 1]]) {
      return this.colorConfig[segments[segments.length - 1]];
    }

    // Try file name
    if (this.colorConfig[fileName]) return this.colorConfig[fileName];

    return null;
  }

  applyStyleToItem(item, style, rainbowColor, index) {
    const s = this.settings;
    if (!s.showBorder) return;

    let bgColor = style ? style.backgroundColor || "" : "";
    let txtColor = style ? style.textColor || "" : "";
    if (s.textColor) txtColor = s.textColor;

    // Apply background
    if (bgColor) {
      item.style.backgroundColor = bgColor;
      item.style.borderRadius = "6px";
      item.style.marginBottom = "2px";

      const titleEl = item.querySelector(".recent-files-title") || item.querySelector(".tree-item-self");
      if (titleEl) {
        titleEl.style.backgroundColor = bgColor;
        titleEl.style.borderRadius = "6px";
      }
    }

    // Apply text color
    const titleEl = item.querySelector(".recent-files-title") || item.querySelector(".tree-item-self");
    if (titleEl) titleEl.style.color = txtColor || "";

    const nameEl = item.querySelector(".nav-file-title-content") || item.querySelector(".tree-item-inner");
    if (nameEl) nameEl.style.color = txtColor || "";

    // Apply bold
    if (s.textBold) {
      if (nameEl) nameEl.style.fontWeight = "bold";
      if (titleEl) titleEl.style.fontWeight = "bold";
    }

    // Apply left border
    const borderColor = s.colorSource === "rainbow" ? rainbowColor : (txtColor || "var(--interactive-accent)");
    item.style.borderLeft = `${s.borderWidth}px solid ${borderColor}`;
    item.style.borderRadius = `${s.borderRadius}px`;
    item.style.paddingLeft = "4px";
  }
}

class RecentFilesColorizerSettingTab extends obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }

  display() {
    const { containerEl } = this;
    containerEl.empty();
    containerEl.createEl("h2", { text: "Recent Files Colorizer" });

    const s = this.plugin.settings;

    new obsidian.Setting(containerEl)
      .setName("显示彩色边框")
      .addToggle((t) =>
        t.setValue(s.showBorder).onChange(async (v) => {
          s.showBorder = v;
          await this.plugin.saveData(s);
          this.plugin.applyToAllViews();
        })
      );

    new obsidian.Setting(containerEl)
      .setName("边框宽度")
      .addSlider((sl) =>
        sl.setLimits(1, 8, 1).setValue(s.borderWidth).onChange(async (v) => {
          s.borderWidth = v;
          await this.plugin.saveData(s);
          this.plugin.applyToAllViews();
        })
      );

    new obsidian.Setting(containerEl)
      .setName("边框圆角")
      .addSlider((sl) =>
        sl.setLimits(0, 12, 1).setValue(s.borderRadius).onChange(async (v) => {
          s.borderRadius = v;
          await this.plugin.saveData(s);
          this.plugin.applyToAllViews();
        })
      );

    new obsidian.Setting(containerEl)
      .setName("颜色来源")
      .addDropdown((d) =>
        d.addOption("folder", "彩色文件夹配置").addOption("rainbow", "彩虹颜色")
          .setValue(s.colorSource).onChange(async (v) => {
            s.colorSource = v;
            await this.plugin.saveData(s);
            this.plugin.applyToAllViews();
          })
      );

    new obsidian.Setting(containerEl)
      .setName("自定义文本颜色")
      .setDesc("留空则使用彩色文件夹配置")
      .addText((t) =>
        t.setPlaceholder("#FF6B6B").setValue(s.textColor).onChange(async (v) => {
          s.textColor = v;
          await this.plugin.saveData(s);
          this.plugin.applyToAllViews();
        })
      );

    new obsidian.Setting(containerEl)
      .setName("加粗文本")
      .addToggle((t) =>
        t.setValue(s.textBold).onChange(async (v) => {
          s.textBold = v;
          await this.plugin.saveData(s);
          this.plugin.applyToAllViews();
        })
      );

    new obsidian.Setting(containerEl)
      .setName("刷新颜色")
      .setDesc("重新加载颜色配置并应用")
      .addButton((b) =>
        b.setButtonText("刷新").onClick(async () => {
          await this.plugin.loadColorConfig();
          this.plugin.applyToAllViews();
          new obsidian.Notice("已刷新");
        })
      );
  }
}

module.exports = RecentFilesColorizer;
