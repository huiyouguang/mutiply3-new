/* ============================================================
 * 文本计算器 (Text Calc)  v1.1.0
 *
 * 触发规则：
 *   1. 行内出现 `=` 且等号后为空 → 计算等号前的内容并输出结果
 *      （支持中文等任意前缀，如：成本 100 + 50 =）
 *   2. 行首直接以数字开头、不含中文、不是日期、含有运算符
 *      → 自动计算该行
 *
 * 交互（参考 solve：默认只预览，不自动改你的文字）：
 *   - 实时预览：行尾显示 `= 结果` 装饰，不修改原文
 *   - 手动落笔：快捷键 / 点击装饰 / 命令面板
 *   - 可选自动：设置里开启「光标离开该行时自动写入」，绝不在输入中途打断
 *
 * 支持符号：+ - * / ^ 括号，x/X/×/⋅ 作乘号，÷ 作除号，% 作百分比
 * 安全求值：不用 eval，除零显示 ∞
 * ============================================================ */

/* ---------- 依赖安全获取：任何缺失只降级，不导致加载失败 ---------- */
let Plugin = null, ViewPlugin = null, Decoration = null, WidgetType = null;
let PluginSettingTab = null, Setting = null, Notice = null;
try {
  const obsidian = require('obsidian');
  Plugin = obsidian.Plugin;
  if (typeof obsidian.Notice === 'function') Notice = obsidian.Notice;
  if (typeof obsidian.ViewPlugin === 'function') ViewPlugin = obsidian.ViewPlugin;
  if (obsidian.Decoration && typeof obsidian.Decoration.set === 'function') Decoration = obsidian.Decoration;
  if (typeof obsidian.WidgetType === 'function') WidgetType = obsidian.WidgetType;
  if (typeof obsidian.PluginSettingTab === 'function') PluginSettingTab = obsidian.PluginSettingTab;
  if (typeof obsidian.Setting === 'function') Setting = obsidian.Setting;
} catch (e) {
  console.error('[text-calc] failed to require obsidian:', e);
}

const DEFAULT_SETTINGS = {
  autoCommitOnLeave: false, // 光标离开该行时自动写入（默认关，和 solve 一致）
  autoCommitDelay: 0        // 延迟自动写入毫秒数，0 = 关闭
};

/* ---------- 预处理：全角/符号归一 ---------- */
function preprocess(input) {
  let s = String(input);
  s = s.replace(/[０-９]/g, ch => String.fromCharCode(ch.charCodeAt(0) - 0xfee0));
  s = s.replace(/．/g, '.');
  s = s.replace(/[×⋅·]/g, '*').replace(/÷/g, '/');
  // x / X 作为乘号：数字或右括号 与 数字或左括号 之间（含中间空白）
  s = s.replace(/([\d)])\s*[xX]\s*([\d(])/g, '$1*$2');
  // 独立 x（前后空白）也作为乘号
  s = s.replace(/\s*[xX]\s*/g, '*');
  // 百分比：数字% → (数字/100)
  s = s.replace(/(\d+(?:\.\d+)?)%/g, '($1/100)');
  s = s.replace(/\s+/g, '');
  return s;
}

/* ---------- 递归下降求值器（不用 eval） ---------- */
class Parser {
  constructor(src) { this.s = src; this.i = 0; }
  peek() { return this.s[this.i]; }
  parseExpr() {
    let v = this.parseTerm();
    while (this.peek() === '+' || this.peek() === '-') {
      const op = this.peek(); this.i++;
      const r = this.parseTerm();
      v = op === '+' ? v + r : v - r;
    }
    return v;
  }
  parseTerm() {
    let v = this.parseFactor();
    while (this.peek() === '*' || this.peek() === '/') {
      const op = this.peek(); this.i++;
      const r = this.parseFactor();
      v = op === '*' ? v * r : v / r;
    }
    return v;
  }
  parseFactor() {
    const base = this.parseUnary();
    if (this.peek() === '^') { this.i++; return Math.pow(base, this.parseFactor()); }
    return base;
  }
  parseUnary() {
    if (this.peek() === '-') { this.i++; return -this.parseUnary(); }
    if (this.peek() === '+') { this.i++; return this.parseUnary(); }
    return this.parsePrimary();
  }
  parsePrimary() {
    if (this.peek() === '(') {
      this.i++;
      const v = this.parseExpr();
      if (this.peek() !== ')') throw new Error('mismatch )');
      this.i++;
      return v;
    }
    const m = /^\d+(?:\.\d+)?/.exec(this.s.slice(this.i));
    if (m) { this.i += m[0].length; return parseFloat(m[0]); }
    throw new Error('unexpected char: ' + this.s[this.i]);
  }
  atEnd() { return this.i >= this.s.length; }
}

function evaluate(input) {
  try {
    // 先剥离有序列表标记（`1. ` / `2) ` / `12. `），否则 `1. 10 + 20`
    // 会被下面的"数字相邻"检查误判成残缺表达式
    const raw = String(input).trim().replace(/^\d+\s*[.)]\s+/, '');
    // 两个数字/括号之间只有空白（缺少运算符）→ 残缺表达式，拒绝计算
    // 例：`T 2=30 x(...)` 过滤后变成 `2 30*(...)`，若不拦截会被拼成 230 而算错
    if (/[\d.)]\s+[\d.(]/.test(raw)) return null;
    const p = new Parser(preprocess(raw));
    const v = p.parseExpr();
    if (!p.atEnd()) return null;
    if (!isFinite(v) || isNaN(v)) return null;
    return v;
  } catch (e) { return null; }
}

/* ---------- 结果格式化 ---------- */
function formatResult(v) {
  if (v === Infinity || v === -Infinity) return '∞';
  if (Number.isNaN(v)) return null;
  const r = Math.round(v * 1e6) / 1e6;
  return String(r);
}

/* ---------- 提取 `=` 前的表达式（忽略中文等前缀） ---------- */
function extractExpr(beforeEq) {
  let s = String(beforeEq);
  // 必须在过滤字符「之前」先剥离列表标记，否则列表符号会被当成运算符：
  //   `-` 变负号（- 10+20 算成 10）、`*` 变乘号（* 10+20 解析失败）、
  //   `[x]` 的 x 变乘号、`1.` 造成数字相邻而被误判为残缺表达式
  // 只剥离「符号后跟空白」的写法，因此 `-10 + 20`、`1.5 + 2` 不受影响
  s = s.replace(/^\s*\d+\s*[.)]\s+/, ' ');            // 有序列表：1. / 1) / 12.
  s = s.replace(/^\s*[-*+]\s+(\[[ xX]\]\s+)?/, ' ');  // 无序/任务：- / * / +，含 - [ ]、 - [x]
  s = s.replace(/^\s*\[[ xX]\]\s+/, ' ');             // 单独的任务标记：[ ] / [x]
  s = s.replace(/[^0-9０-９.+\-*/^()xX×÷⋅·%]/g, ' ');
  s = s.trim();
  if (!s) return null;
  // 防止把日期当减法算（如 2024-01-01）
  if (/^\d{4}\s*-\s*\d{1,2}\s*-\s*\d{1,2}$/.test(s)) return null;
  return s;
}

/* ---------- 行分析：符合条件返回 { expr, result }，否则 null ---------- */
const HAS_OP = /[+\-*/^xX×÷⋅·%]/;

function analyzeLine(text) {
  const t = text.trim();
  if (!t) return null;

  if (t.includes('=')) {
    const idx = t.lastIndexOf('=');
    const after = t.slice(idx + 1).trim();
    if (after === '') {
      const expr = extractExpr(t.slice(0, idx));
      if (!expr) return null;
      const v = evaluate(expr);
      if (v === null) return null;
      return { expr, result: v };
    }
    // 已写入的结果（纯数字或 ∞，允许正负号与小数）→ 跳过
    // 注意：必须先判这个，否则 `-1482` 因含 `-` 会被当成表达式重复计算，导致无限写入
    if (/^[+\-]?\d+(?:\.\d+)?$/.test(after) || after === '∞') return null;
    // 等号后无运算符 → 不是表达式，跳过
    if (!HAS_OP.test(after)) return null;
    // 等号后含运算符 → 是待计算表达式（如 `= 2 + 3`）
    const expr = extractExpr(after);
    if (!expr) return null;
    const v = evaluate(expr);
    if (v === null) return null;
    return { expr, result: v };
  }

  // 行首必须为数字
  if (!/^[0-9０-９]/.test(t)) return null;
  // 不含中文
  if (/[\u4e00-\u9fa5]/.test(t)) return null;
  // 不是日期（2024-01-01 / 2024/01/01 / 2024年...）
  if (/^\d{4}\s*[-/年]/.test(t)) return null;
  // 必须含运算符（排除纯数字）
  if (!HAS_OP.test(t)) return null;
  // 行尾是运算符（表达式未写完）→ 不处理（% 结尾允许）
  if (/[+\-*/^xX×÷⋅·]\s*$/.test(t)) return null;

  const v = evaluate(t);
  if (v === null) return null;
  return { expr: t, result: v };
}

/* ============================================================
 * 可选 A：行尾实时预览装饰（只负责显示，不参与落笔）
 * 若环境不支持，自动降级为「无预览」，落笔功能不受影响
 * ============================================================ */
/* 计算整篇文档的行尾预览装饰（供初始化与更新复用） */
function buildDecorations(doc, makeWidget) {
  const decos = [];
  for (let n = 1; n <= doc.lines; n++) {
    const line = doc.line(n);
    const info = analyzeLine(line.text);
    if (!info) continue;
    const display = formatResult(info.result);
    if (display === null) continue;
    const pos = line.to;
    decos.push(makeWidget(display, n).range(pos, pos));
  }
  return Decoration.set(decos);
}

function tryRegisterDecorations(plugin) {
  if (!ViewPlugin || !Decoration || !WidgetType) {
    console.warn('[text-calc] 预览装饰缺少 API:', JSON.stringify({
      ViewPlugin: !!ViewPlugin, Decoration: !!Decoration, WidgetType: !!WidgetType
    }));
    return false;
  }
  try {
    class CalcResultWidget extends WidgetType {
      constructor(display, lineNumber) {
        super();
        this.display = display;
        this.lineNumber = lineNumber;
      }
      toDOM(view) {
        const span = document.createElement('span');
        span.className = 'text-calc-result';
        span.textContent = '= ' + this.display;
        span.addEventListener('click', (ev) => {
          ev.preventDefault();
          ev.stopPropagation();
          plugin.commitLine(view, this.lineNumber);
        });
        return span;
      }
    }
    const makeWidget = (display, n) => Decoration.widget({
      widget: new CalcResultWidget(display, n),
      side: 1
    });
    const viewPlugin = ViewPlugin.fromClass(class CalcView {
      constructor(view) {
        // 打开文件时立刻算一次，否则要等你输入后才出现
        this.decorations = buildDecorations(view.state.doc, makeWidget);
        this._view = view;
      }
      update(update) {
        // 文档变化、或滚动导致可见行变化时都重算
        if (update.docChanged || update.viewportChanged) {
          this.decorations = buildDecorations(update.state.doc, makeWidget);
        }
      }
    }, { decorations: v => v.decorations });
    plugin.registerEditorExtension(viewPlugin);
    return true;
  } catch (e) {
    console.warn('[text-calc] 装饰预览不可用（落笔与命令不受影响）:', e);
    return false;
  }
}

/* ============================================================
 * 可选 B：光标离开该行时自动落笔
 * 独立于装饰模块，装饰不可用时本功能依然生效
 * ============================================================ */
function tryRegisterLeaveWatcher(plugin) {
  if (!ViewPlugin) return false;
  try {
    const ext = ViewPlugin.fromClass(class LeaveWatcher {
      update(update) {
        if (!update.docChanged && !update.selectionSet) return;
        const doc = update.state.doc;
        const cur = doc.lineAt(update.state.selection.main.head).number;
        const last = plugin._leaveLine;
        const lastView = plugin._leaveView;
        // 切换文件/视图时重置，避免跨文件误写
        if (lastView && lastView !== update.view) { plugin._leaveLine = cur; plugin._leaveView = update.view; return; }
        plugin._leaveView = update.view;
        if (last && last !== cur && plugin.settings && plugin.settings.autoCommitOnLeave) {
          plugin.commitLine(update.view, last);
        }
        plugin._leaveLine = cur;
      }
    });
    plugin.registerEditorExtension(ext);
    return true;
  } catch (e) {
    console.warn('[text-calc] 离开行自动落笔不可用（快捷键仍可用）:', e);
    return false;
  }
}

/* ============================================================
 * 设置面板
 * ============================================================ */
function buildSettingsTab(plugin) {
  return class TextCalcSettingTab extends PluginSettingTab {
    constructor(app, pl) { super(app, pl); this.plugin = pl; }
    display() {
      const el = this.containerEl;
      el.empty();
      el.createEl('p', { text: '默认只预览、不自动改你的文字。需要落笔时：快捷键 / 点击行尾装饰 / 命令面板。' });

      new Setting(el)
        .setName('光标离开该行时自动写入')
        .setDesc('换行或把光标移到别处时，自动把刚编辑那行的结果写入。绝不会在你输入过程中打断。')
        .addToggle(t => t.setValue(this.plugin.settings.autoCommitOnLeave)
          .onChange(async v => { this.plugin.settings.autoCommitOnLeave = v; await this.plugin.saveSettings(); }));

      new Setting(el)
        .setName('延迟自动写入（毫秒）')
        .setDesc('停止输入指定毫秒后自动写入结果。填 0 表示关闭；建议 1000 以上，小于 300 会按 300 处理。')
        .addText(t => t.setValue(String(this.plugin.settings.autoCommitDelay))
          .onChange(async v => {
            const n = parseInt(v, 10);
            this.plugin.settings.autoCommitDelay = isNaN(n) || n < 0 ? 0 : n;
            await this.plugin.saveSettings();
          }));
    }
  };
}

/* ============================================================
 * 插件主体
 * ============================================================ */
module.exports = class TextCalcPlugin extends Plugin {
  async onload() {
    if (!Plugin) throw new Error('[text-calc] obsidian.Plugin 不可用');
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());

    // 两个能力分别注册、互不牵连
    this._decor = tryRegisterDecorations(this);      // 行尾预览装饰
    this._leave = tryRegisterLeaveWatcher(this);     // 光标离开该行自动落笔

    console.log('[text-calc] loaded v1.1.5 | 预览装饰:',
      this._decor ? '可用' : '不可用',
      '| 离开行自动落笔:', this._leave ? '可用' : '不可用(靠换行兜底)',
      '| 设置:', JSON.stringify(this.settings));

    // 预览装饰不可用时在界面上提示，方便定位原因
    if (!this._decor && Notice) {
      setTimeout(() => new Notice(
        '文本计算器：行尾预览装饰不可用（快捷键与自动落笔仍正常）。请按 Cmd/Ctrl+Opt+I 打开控制台查看 [text-calc] 开头的提示。',
        10000
      ), 1500);
    }

    // 延迟自动写入 + 换行兜底（不依赖 CodeMirror 扩展）
    this.registerEvent(this.app.workspace.on('editor-change', (editor) => {
      const delay = this.settings ? this.settings.autoCommitDelay : 0;

      // 延迟自动写入；下限 300ms，避免过小的值在输入中途乱写
      if (delay > 0) {
        clearTimeout(this._timer);
        this._timer = setTimeout(() => {
          const cur = editor.getCursor();
          const text = editor.getLine(cur.line);
          // 光标必须在行尾才算“这一行写完了”，
          // 避免在行中间回头修改时被插入结果
          if (cur.ch < text.trimEnd().length) return;
          this.commitEditorLine(editor, cur.line);
        }, Math.max(delay, 300));
      }

      // 兜底：换行导致光标行变化时，给刚离开的那行落笔
      // （扩展可用时由扩展处理，这里只在扩展不可用时生效，避免重复写入）
      if (this.settings && this.settings.autoCommitOnLeave && !this._leave) {
        const curLine = editor.getCursor().line;
        if (this._editLine != null && this._editLine !== curLine) {
          this.commitEditorLine(editor, this._editLine);
        }
        this._editLine = curLine;
      }
    }));

    // 命令 + 默认快捷键
    this.addCommand({
      id: 'commit-current-line',
      name: '写入当前行结果',
      hotkeys: [{ modifiers: ['Mod', 'Shift'], key: 'Enter' }],
      editorCallback: (editor) => { this.commitEditorLine(editor, editor.getCursor().line); }
    });

    this.addCommand({
      id: 'commit-all-visible',
      name: '写入所有可见行结果',
      hotkeys: [{ modifiers: ['Mod', 'Shift'], key: 'E' }],
      editorCallback: (editor) => { this.commitAll(editor); }
    });

    // 设置面板（失败不影响主功能）
    try {
      if (PluginSettingTab && Setting) this.addSettingTab(new (buildSettingsTab(this))(this.app, this));
    } catch (e) {
      console.warn('[text-calc] 设置面板注册失败:', e);
    }
  }

  onunload() { clearTimeout(this._timer); }

  async saveSettings() { await this.saveData(this.settings); }

  /* 写入单行：仅在行内仍无结果时写入 */
  commitEditorLine(editor, line) {
    try {
      if (line < 0 || line >= editor.lineCount()) return;
      const text = editor.getLine(line);
      const info = analyzeLine(text);
      if (!info) return;
      const display = formatResult(info.result);
      if (display === null) return;
      editor.setLine(line, text.trimEnd() + ' = ' + display);
    } catch (e) {
      console.warn('[text-calc] commit 失败:', e);
    }
  }

  /* 通过 CodeMirror 视图写入指定行（点击装饰 / 离开行自动落笔） */
  commitLine(view, lineNumber) {
    try {
      const lineObj = view.state.doc.line(lineNumber);
      const info = analyzeLine(lineObj.text);
      if (!info) return;
      const display = formatResult(info.result);
      if (display === null) return;
      view.dispatch({ changes: { from: lineObj.to, insert: ' = ' + display } });
    } catch (e) {
      console.warn('[text-calc] 点击写入失败:', e);
    }
  }

  /* 写入所有行 */
  commitAll(editor) {
    for (let i = 0; i < editor.lineCount(); i++) this.commitEditorLine(editor, i);
  }
};
