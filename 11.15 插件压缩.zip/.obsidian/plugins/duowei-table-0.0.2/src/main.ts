import {
  Modal,
  Notice,
  Plugin,
  normalizePath,
  setIcon,
  stringifyYaml,
  type TFile
} from "obsidian";
import { GridBasesView } from "./bases/GridBasesView";
import { importBaseToDuowei } from "./duowei/BaseImporter";
import { DUOWEI_HOVER_SOURCE, DuoweiTableView, type OperationLogItem } from "./duowei/DuoweiTableView";
import {
  DUOWEI_EXTENSION,
  DUOWEI_VIEW_TYPE,
  createBlankDuoweiDocument,
  parseDuoweiDocument,
  serializeDuoweiDocument
} from "./duowei/schema";
import { GRID_VIEW_TYPE } from "./model/config";
import {
  DEFAULT_SETTINGS,
  DUOWEI_PRO_URL,
  MultiTableSettingsTab,
  normalizeSettings,
  type MultiTableSettings
} from "./settings/SettingsTab";
import { RecordWriteQueue } from "./write/RecordWriteQueue";

interface RelatedTableMatch {
  tableFile: TFile;
  tableName: string;
  recordId: string;
  recordTitle: string;
  recordIndex: number;
}

export default class MultiTablePlugin extends Plugin {
  settings: MultiTableSettings = DEFAULT_SETTINGS;
  operationLog: OperationLogItem[] = [];
  private writeQueue!: RecordWriteQueue;

  async onload(): Promise<void> {
    await this.loadSettings();
    this.writeQueue = new RecordWriteQueue(this.app);

    const registered = this.registerBasesView(GRID_VIEW_TYPE, {
      name: "多维表格",
      icon: "table-properties",
      factory: (controller, containerEl) =>
        new GridBasesView(controller, containerEl, this.writeQueue, {
          showSaveStatus: () => this.settings.showSaveStatus
        })
    });

    if (!registered) {
      console.warn("[多维表格] Bases 核心插件未启用，自定义视图未注册。");
    }

    this.registerView(
      DUOWEI_VIEW_TYPE,
      (leaf) =>
        new DuoweiTableView(leaf, {
          getSettings: () => this.settings,
          getOperationLog: () => this.operationLog,
          appendOperationLog: (item) => void this.appendOperationLog(item),
          clearOperationLog: () => void this.clearOperationLog()
        })
    );
    this.registerExtensions([DUOWEI_EXTENSION], DUOWEI_VIEW_TYPE);

    // 让笔记链接/附件单元格支持 Ctrl/Cmd 悬停预览（可在「页面预览」设置里关掉修饰键要求）。
    this.registerHoverLinkSource(DUOWEI_HOVER_SOURCE, {
      display: "多维表格",
      defaultMod: true
    });

    this.addCommand({
      id: "create-blank-duowei-table",
      name: "创建空白多维表格",
      callback: () => void this.createBlankDuoweiTable()
    });

    this.addCommand({
      id: "import-current-base-to-duowei",
      name: "从当前 Base 创建独立多维表格",
      checkCallback: (checking) => {
        const file = this.app.workspace.getActiveFile();
        const canRun = file?.extension === "base";
        if (checking) return Boolean(canRun);
        if (!canRun || !file) {
          new Notice("请先打开一个 .base 文件。", 3000);
          return false;
        }
        void importBaseToDuowei(this.app, file);
        return true;
      }
    });

    this.addCommand({
      id: "find-related-duowei-tables-for-current-note",
      name: "查找当前笔记关联的多维表格",
      checkCallback: (checking) => {
        const file = this.app.workspace.getActiveFile();
        const canRun = file?.extension === "md";
        if (checking) return Boolean(canRun);
        if (!canRun || !file) {
          new Notice("请先打开一个 Markdown 笔记。", 3000);
          return false;
        }
        void this.findRelatedTablesForNote(file);
        return true;
      }
    });

    this.addCommand({
      id: "create-demo-multidimensional-table",
      name: "创建示例多维表格",
      callback: () => void this.createDemo()
    });

    this.addCommand({
      id: "open-duowei-pro-upgrade",
      name: "了解与升级到 Duowei Table Pro",
      callback: () => {
        window.open(DUOWEI_PRO_URL, "_blank", "noopener,noreferrer");
      }
    });

    this.addSettingTab(new MultiTableSettingsTab(this.app, this));
  }

  onunload(): void {
    this.writeQueue.dispose();
  }

  async loadSettings(): Promise<void> {
    const loaded = (await this.loadData()) as Partial<MultiTableSettings> & { operationLog?: unknown } | null;
    this.settings = normalizeSettings(loaded);
    this.operationLog = normalizeOperationLog(loaded?.operationLog, this.settings.operationLogRetention);
  }

  async saveSettings(): Promise<void> {
    await this.saveData({
      ...this.settings,
      operationLog: this.operationLog.slice(0, this.settings.operationLogRetention)
    });
  }

  async appendOperationLog(item: OperationLogItem): Promise<void> {
    this.operationLog = [item, ...this.operationLog].slice(0, this.settings.operationLogRetention);
    if (this.settings.operationLogPersistenceEnabled) await this.saveSettings();
  }

  async clearOperationLog(): Promise<void> {
    this.operationLog = [];
    await this.saveSettings();
  }

  private async createBlankDuoweiTable(): Promise<void> {
    const folder = "多维表格";
    if (!this.app.vault.getAbstractFileByPath(folder)) {
      await this.app.vault.createFolder(folder);
    }

    const baseName = "未命名多维表格";
    const path = await this.nextAvailablePath(folder, baseName, DUOWEI_EXTENSION);
    const document = createBlankDuoweiDocument(baseName);
    const file = await this.app.vault.create(path, serializeDuoweiDocument(document));
    await this.openFile(file);
    new Notice("空白多维表格已创建。", 3000);
  }

  private async findRelatedTablesForNote(note: TFile): Promise<void> {
    const matches: RelatedTableMatch[] = [];
    const normalizedNotePath = normalizePath(note.path);
    for (const file of this.app.vault.getFiles()) {
      if (file.extension !== DUOWEI_EXTENSION) continue;
      try {
        const data = await this.app.vault.read(file);
        const parsed = parseDuoweiDocument(data, file.basename);
        const titleField = parsed.document.fields[0];
        parsed.document.records.forEach((record, index) => {
          if (!record.notePath || normalizePath(record.notePath) !== normalizedNotePath) return;
          const rawTitle = titleField ? record.values[titleField.id] : undefined;
          matches.push({
            tableFile: file,
            tableName: parsed.document.name || file.basename,
            recordId: record.id,
            recordTitle: displayRelatedRecordTitle(rawTitle, index),
            recordIndex: index
          });
        });
      } catch (error) {
        console.error("[多维表格] 查找关联表格失败", file.path, error);
      }
    }
    new RelatedTablesModal(this, note, matches).open();
  }

  private async createDemo(): Promise<void> {
    const folder = "多维表格示例";
    const basePath = normalizePath(`${folder}/项目管理.base`);
    const existing = this.app.vault.getAbstractFileByPath(basePath);
    if (existing) {
      await this.openFile(existing as TFile);
      new Notice("示例多维表格已存在，已直接打开。", 3000);
      return;
    }

    if (!this.app.vault.getAbstractFileByPath(folder)) {
      await this.app.vault.createFolder(folder);
    }

    const records = [
      { name: "需求梳理", status: "进行中", owner: "小林", done: false, priority: 1, due_date: "2026-07-03" },
      { name: "交互原型", status: "待处理", owner: "小周", done: false, priority: 2, due_date: "2026-07-05" },
      { name: "技术验证", status: "已完成", owner: "小林", done: true, priority: 1, due_date: "2026-06-28" },
      { name: "移动端适配", status: "待处理", owner: "小陈", done: false, priority: 3, due_date: "2026-07-10" },
      { name: "发布测试", status: "待处理", owner: "小周", done: false, priority: 2, due_date: "2026-07-12" }
    ];

    for (const record of records) {
      const path = normalizePath(`${folder}/${record.name}.md`);
      const content = `---\n${stringifyYaml({
        type: "duowei-demo",
        status: record.status,
        owner: record.owner,
        done: record.done,
        priority: record.priority,
        due_date: record.due_date
      })}---\n\n# ${record.name}\n`;
      await this.app.vault.create(path, content);
    }

    const base = `filters:
  and:
    - 'file.ext == "md"'
    - 'type == "duowei-demo"'

properties:
  status:
    displayName: "状态"
  owner:
    displayName: "负责人"
  done:
    displayName: "完成"
  priority:
    displayName: "优先级"
  due_date:
    displayName: "截止日期"

views:
  - type: duowei-grid
    name: "项目总览"
    order:
      - file.name
      - status
      - owner
      - due_date
      - done
      - priority
    duowei:
      schemaVersion: 1
      density: default
      rowHeight: 32
      frozenColumns: 1
      fields:
        note.status:
          editor: select
          options:
            - id: todo
              label: "待处理"
              color: "var(--color-orange)"
            - id: doing
              label: "进行中"
              color: "var(--color-blue)"
            - id: done
              label: "已完成"
              color: "var(--color-green)"
        note.due_date:
          editor: date
      columns:
        file.name:
          width: 240
        note.status:
          width: 136
        note.due_date:
          width: 132
`;

    const file = await this.app.vault.create(basePath, base);
    await this.openFile(file);
    new Notice("示例多维表格已创建。", 3000);
  }

  private async openFile(file: TFile): Promise<void> {
    await this.app.workspace.getLeaf("tab").openFile(file);
  }

  private async nextAvailablePath(folder: string, baseName: string, extension: string): Promise<string> {
    let index = 1;
    while (true) {
      const suffix = index === 1 ? "" : ` ${index}`;
      const path = normalizePath(`${folder}/${baseName}${suffix}.${extension}`);
      if (!this.app.vault.getAbstractFileByPath(path)) return path;
      index += 1;
    }
  }
}

function normalizeOperationLog(raw: unknown, retention: number): OperationLogItem[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .filter((item): item is OperationLogItem => isOperationLogItem(item))
    .slice(0, retention);
}

function isOperationLogItem(value: unknown): value is OperationLogItem {
  if (typeof value !== "object" || value === null || Array.isArray(value)) return false;
  const item = value as Partial<OperationLogItem>;
  return (
    typeof item.id === "string" &&
    typeof item.at === "string" &&
    isOperationLogType(item.type) &&
    typeof item.label === "string" &&
    typeof item.detail === "string" &&
    (item.status === "ok" || item.status === "warning" || item.status === "error")
  );
}

function isOperationLogType(value: unknown): value is OperationLogItem["type"] {
  return (
    value === "edit" ||
    value === "undo" ||
    value === "redo" ||
    value === "sync" ||
    value === "conflict" ||
    value === "import" ||
    value === "export" ||
    value === "system"
  );
}

class RelatedTablesModal extends Modal {
  constructor(
    private readonly plugin: MultiTablePlugin,
    private readonly note: TFile,
    private readonly matches: RelatedTableMatch[]
  ) {
    super(plugin.app);
  }

  onOpen(): void {
    this.modalEl.addClass("mt-related-tables-modal");
    this.titleEl.empty();
    this.titleEl.createSpan({ text: "关联的多维表格" });
    this.contentEl.empty();
    this.contentEl.createDiv({ cls: "mt-related-tables__note", text: this.note.path });
    if (this.matches.length === 0) {
      this.contentEl.createDiv({ cls: "mt-panel__empty", text: "没有找到绑定到当前笔记的 .duowei 记录。" });
      return;
    }
    const list = this.contentEl.createDiv({ cls: "mt-related-tables__list" });
    for (const match of this.matches) {
      const row = list.createDiv({ cls: "mt-related-tables__item" });
      const icon = row.createSpan({ cls: "mt-related-tables__icon", attr: { "aria-hidden": "true" } });
      setIcon(icon, "table-properties");
      const text = row.createDiv({ cls: "mt-related-tables__text" });
      text.createDiv({ cls: "mt-related-tables__title", text: match.tableName });
      text.createDiv({ cls: "mt-related-tables__meta", text: `${match.recordIndex + 1} 行 · ${match.recordTitle} · ${match.tableFile.path}` });
      const open = row.createEl("button", {
        cls: "mt-dialog__button mt-dialog__button--primary",
        text: "打开",
        attr: { type: "button" }
      });
      open.addEventListener("click", () => void this.openMatch(match));
    }
  }

  onClose(): void {
    this.contentEl.empty();
  }

  private async openMatch(match: RelatedTableMatch): Promise<void> {
    this.close();
    await this.app.workspace.getLeaf("tab").openFile(match.tableFile);
    new Notice(`已打开 ${match.tableName}，关联记录在第 ${match.recordIndex + 1} 行。`, 4000);
  }
}

function displayRelatedRecordTitle(value: unknown, index: number): string {
  if (typeof value === "string" && value.trim()) return value.trim();
  if (typeof value === "number" || typeof value === "boolean") return String(value);
  if (Array.isArray(value)) {
    const joined = value.map((item) => String(item)).filter(Boolean).join(", ");
    if (joined) return joined;
  }
  return `${index + 1} 行`;
}
