import type { App, TFile } from "obsidian";

export class WriteConflictError extends Error {
  constructor(
    public readonly path: string,
    public readonly property: string,
    public readonly expected: unknown,
    public readonly actual: unknown
  ) {
    super(`记录已在外部修改：${path} · ${property}`);
    this.name = "WriteConflictError";
  }
}

export class RecordWriteQueue {
  private readonly chains = new Map<string, Promise<void>>();
  private pending = 0;
  private disposed = false;

  constructor(private readonly app: App) {}

  get pendingCount(): number {
    return this.pending;
  }

  enqueue(
    file: TFile,
    property: string,
    expectedValue: unknown,
    nextValue: unknown
  ): Promise<void> {
    if (this.disposed) return Promise.reject(new Error("写入队列已关闭"));

    const previous = this.chains.get(file.path) ?? Promise.resolve();
    this.pending += 1;

    const task = previous
      .catch(() => undefined)
      .then(() => this.write(file, property, expectedValue, nextValue));

    const tracked = task.finally(() => {
      this.pending -= 1;
      if (this.chains.get(file.path) === tracked) this.chains.delete(file.path);
    });

    this.chains.set(file.path, tracked);
    return tracked;
  }

  dispose(): void {
    this.disposed = true;
  }

  private async write(
    file: TFile,
    property: string,
    expectedValue: unknown,
    nextValue: unknown
  ): Promise<void> {
    await this.app.fileManager.processFrontMatter(file, (frontmatter: Record<string, unknown>) => {
      const actual = frontmatter[property];
      if (!equivalent(actual, expectedValue)) {
        throw new WriteConflictError(file.path, property, expectedValue, actual);
      }

      if (nextValue === undefined || nextValue === null || nextValue === "") {
        delete frontmatter[property];
      } else {
        frontmatter[property] = nextValue;
      }
    });
  }
}

function equivalent(left: unknown, right: unknown): boolean {
  if (left === right) return true;
  if (left === undefined && right === null) return true;
  if (left === null && right === undefined) return true;

  try {
    return JSON.stringify(left) === JSON.stringify(right);
  } catch {
    return false;
  }
}
