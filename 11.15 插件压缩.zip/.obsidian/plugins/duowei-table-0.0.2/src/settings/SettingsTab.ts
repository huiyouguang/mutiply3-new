import { PluginSettingTab, Setting, type App } from "obsidian";
import type MultiTablePlugin from "../main";

export const DUOWEI_PRO_URL = "https://peyote.info/plugins/duowei-table-pro/?source=community";

export interface MultiTableSettings {
  showSaveStatus: boolean;
  duoweiAutoBackupEnabled: boolean;
  duoweiAutoBackupIntervalMinutes: number;
  duoweiAutoBackupRetention: number;
  operationLogPersistenceEnabled: boolean;
  operationLogRetention: number;
}

export const DEFAULT_SETTINGS: MultiTableSettings = {
  showSaveStatus: true,
  duoweiAutoBackupEnabled: true,
  duoweiAutoBackupIntervalMinutes: 10,
  duoweiAutoBackupRetention: 12,
  operationLogPersistenceEnabled: true,
  operationLogRetention: 500
};

export function normalizeSettings(raw: Partial<MultiTableSettings> | null | undefined): MultiTableSettings {
  return {
    showSaveStatus: typeof raw?.showSaveStatus === "boolean" ? raw.showSaveStatus : DEFAULT_SETTINGS.showSaveStatus,
    duoweiAutoBackupEnabled:
      typeof raw?.duoweiAutoBackupEnabled === "boolean" ? raw.duoweiAutoBackupEnabled : DEFAULT_SETTINGS.duoweiAutoBackupEnabled,
    duoweiAutoBackupIntervalMinutes: clampInteger(
      raw?.duoweiAutoBackupIntervalMinutes,
      1,
      240,
      DEFAULT_SETTINGS.duoweiAutoBackupIntervalMinutes
    ),
    duoweiAutoBackupRetention: clampInteger(raw?.duoweiAutoBackupRetention, 1, 100, DEFAULT_SETTINGS.duoweiAutoBackupRetention),
    operationLogPersistenceEnabled:
      typeof raw?.operationLogPersistenceEnabled === "boolean"
        ? raw.operationLogPersistenceEnabled
        : DEFAULT_SETTINGS.operationLogPersistenceEnabled,
    operationLogRetention: clampInteger(raw?.operationLogRetention, 50, 2000, DEFAULT_SETTINGS.operationLogRetention)
  };
}

export class MultiTableSettingsTab extends PluginSettingTab {
  constructor(app: App, private readonly plugin: MultiTablePlugin) {
    super(app, plugin);
  }

  display(): void {
    this.containerEl.empty();
    this.containerEl.createEl("h2", { text: "多维表格" });
    this.containerEl.createEl("p", {
      text: "视图级设置保存在对应 .base 文件中，保证跨设备同步和插件重装后恢复。"
    });

    new Setting(this.containerEl)
      .setName("升级到 Duowei Table Pro")
      .setDesc("直接进入 Duowei Table Pro 专属页面，查看试用、月度、年度与买断方案；无需在官网重新选择产品。")
      .addButton((button) =>
        button
          .setButtonText("查看 Pro 与购买方案")
          .setCta()
          .onClick(() => {
            window.open(DUOWEI_PRO_URL, "_blank", "noopener,noreferrer");
          })
      );

    new Setting(this.containerEl)
      .setName("显示保存状态")
      .setDesc("在视图右上角显示正在保存、已保存和冲突状态。")
      .addToggle((toggle) =>
        toggle.setValue(this.plugin.settings.showSaveStatus).onChange(async (value) => {
          this.plugin.settings.showSaveStatus = value;
          await this.plugin.saveSettings();
        })
      );

    new Setting(this.containerEl)
      .setName("自动备份 .duowei 表格")
      .setDesc("保存覆盖旧版本前，自动保留一个可从“备份恢复”面板找回的快照。")
      .addToggle((toggle) =>
        toggle.setValue(this.plugin.settings.duoweiAutoBackupEnabled).onChange(async (value) => {
          this.plugin.settings.duoweiAutoBackupEnabled = value;
          await this.plugin.saveSettings();
        })
      );

    new Setting(this.containerEl)
      .setName("自动备份最小间隔")
      .setDesc("连续编辑时，至少间隔多少分钟才创建下一份自动备份。")
      .addText((text) => {
        text.inputEl.type = "number";
        text.inputEl.min = "1";
        text.inputEl.max = "240";
        text
          .setPlaceholder(String(DEFAULT_SETTINGS.duoweiAutoBackupIntervalMinutes))
          .setValue(String(this.plugin.settings.duoweiAutoBackupIntervalMinutes))
          .onChange(async (value) => {
            this.plugin.settings.duoweiAutoBackupIntervalMinutes = clampInteger(
              Number(value),
              1,
              240,
              DEFAULT_SETTINGS.duoweiAutoBackupIntervalMinutes
            );
            await this.plugin.saveSettings();
          });
      });

    new Setting(this.containerEl)
      .setName("每个表格保留自动备份数")
      .setDesc("超过数量后，只清理插件自动生成的旧自动备份，不清理冲突备份。")
      .addText((text) => {
        text.inputEl.type = "number";
        text.inputEl.min = "1";
        text.inputEl.max = "100";
        text
          .setPlaceholder(String(DEFAULT_SETTINGS.duoweiAutoBackupRetention))
          .setValue(String(this.plugin.settings.duoweiAutoBackupRetention))
          .onChange(async (value) => {
            this.plugin.settings.duoweiAutoBackupRetention = clampInteger(
              Number(value),
              1,
              100,
              DEFAULT_SETTINGS.duoweiAutoBackupRetention
            );
            await this.plugin.saveSettings();
          });
      });

    new Setting(this.containerEl)
      .setName("持久化操作日志")
      .setDesc("把最近操作记录保存到插件数据中，重启 Obsidian 后仍可查看；不会写入 .duowei 表格文件。")
      .addToggle((toggle) =>
        toggle.setValue(this.plugin.settings.operationLogPersistenceEnabled).onChange(async (value) => {
          this.plugin.settings.operationLogPersistenceEnabled = value;
          await this.plugin.saveSettings();
        })
      );

    new Setting(this.containerEl)
      .setName("保留操作日志条数")
      .setDesc("超过数量后自动丢弃最旧记录。")
      .addText((text) => {
        text.inputEl.type = "number";
        text.inputEl.min = "50";
        text.inputEl.max = "2000";
        text
          .setPlaceholder(String(DEFAULT_SETTINGS.operationLogRetention))
          .setValue(String(this.plugin.settings.operationLogRetention))
          .onChange(async (value) => {
            this.plugin.settings.operationLogRetention = clampInteger(Number(value), 50, 2000, DEFAULT_SETTINGS.operationLogRetention);
            await this.plugin.saveSettings();
          });
      });
  }
}

function clampInteger(value: unknown, min: number, max: number, fallback: number): number {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return fallback;
  return Math.min(max, Math.max(min, Math.floor(numeric)));
}
