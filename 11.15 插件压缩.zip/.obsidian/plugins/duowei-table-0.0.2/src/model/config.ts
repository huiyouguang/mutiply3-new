import type { BasesPropertyId, BasesViewConfig } from "obsidian";

export const GRID_VIEW_TYPE = "duowei-grid";
export const CONFIG_KEY = "duowei";

export type EditorKind = "text" | "number" | "boolean" | "select" | "date" | "textarea" | "readonly";

export interface SelectOption {
  id: string;
  label: string;
  color?: string;
}

export interface FieldViewConfig {
  editor?: EditorKind;
  options?: SelectOption[];
}

export interface ColumnViewConfig {
  width?: number;
  hidden?: boolean;
}

export interface DuoweiViewConfig {
  schemaVersion: 1;
  density: "compact" | "default" | "comfortable";
  rowHeight: number;
  frozenColumns: number;
  columnOrder: BasesPropertyId[];
  fields: Partial<Record<BasesPropertyId, FieldViewConfig>>;
  columns: Partial<Record<BasesPropertyId, ColumnViewConfig>>;
}

export const DEFAULT_VIEW_CONFIG: DuoweiViewConfig = {
  schemaVersion: 1,
  density: "default",
  rowHeight: 32,
  frozenColumns: 1,
  columnOrder: [],
  fields: {},
  columns: {}
};

export function readDuoweiConfig(config: BasesViewConfig): DuoweiViewConfig {
  const raw = config.get(CONFIG_KEY);
  if (!isRecord(raw)) return cloneDefaultConfig();

  const density = raw.density;
  const rowHeight = Number(raw.rowHeight);
  const frozenColumns = Number(raw.frozenColumns);

  return {
    schemaVersion: 1,
    density:
      density === "compact" || density === "comfortable" || density === "default"
        ? density
        : DEFAULT_VIEW_CONFIG.density,
    rowHeight: Number.isFinite(rowHeight) ? clamp(rowHeight, 28, 48) : DEFAULT_VIEW_CONFIG.rowHeight,
    frozenColumns: Number.isFinite(frozenColumns)
      ? Math.max(0, Math.floor(frozenColumns))
      : DEFAULT_VIEW_CONFIG.frozenColumns,
    columnOrder: Array.isArray(raw.columnOrder)
      ? raw.columnOrder.filter((value): value is BasesPropertyId => typeof value === "string")
      : [],
    fields: isRecord(raw.fields)
      ? (raw.fields as Partial<Record<BasesPropertyId, FieldViewConfig>>)
      : {},
    columns: isRecord(raw.columns)
      ? (raw.columns as Partial<Record<BasesPropertyId, ColumnViewConfig>>)
      : {}
  };
}

export function writeDuoweiConfig(config: BasesViewConfig, value: DuoweiViewConfig): void {
  config.set(CONFIG_KEY, value);
}

export function setDensity(
  config: DuoweiViewConfig,
  density: DuoweiViewConfig["density"]
): DuoweiViewConfig {
  const rowHeight = density === "compact" ? 28 : density === "comfortable" ? 40 : 32;
  return { ...config, density, rowHeight };
}

export function cycleDensity(config: DuoweiViewConfig): DuoweiViewConfig {
  if (config.density === "compact") {
    return { ...config, density: "default", rowHeight: 32 };
  }
  if (config.density === "default") {
    return { ...config, density: "comfortable", rowHeight: 40 };
  }
  return { ...config, density: "compact", rowHeight: 28 };
}

function cloneDefaultConfig(): DuoweiViewConfig {
  return {
    ...DEFAULT_VIEW_CONFIG,
    columnOrder: [],
    fields: {},
    columns: {}
  };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}
