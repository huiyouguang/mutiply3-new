import { Modal, setIcon, type App } from "obsidian";
import type { BasesPropertyId } from "obsidian";
import type { EditorKind } from "../model/config";
import { parseEditorValue } from "./ValueAdapter";

export interface RecordCardOption {
  label: string;
  color?: string;
}

export interface RecordCardField {
  id: BasesPropertyId;
  label: string;
  editor: EditorKind;
  editable: boolean;
  display: string;
  primitive: unknown;
  typeIcon: string;
  options?: RecordCardOption[];
}

export interface RecordCardOptions {
  title: string;
  subtitle?: string;
  fields: RecordCardField[];
  /** Commit a single field. Resolves once the write is persisted. */
  commit: (field: RecordCardField, nextValue: unknown) => Promise<void>;
  /** Open the underlying note in the workspace. */
  openNote?: () => void;
}

/**
 * Feishu-style "expand record" card: every field of one row laid out
 * vertically with an inline editor, committing through the same write queue
 * the grid uses.
 */
export class RecordCardModal extends Modal {
  private navigating = false;

  constructor(
    app: App,
    private readonly options: RecordCardOptions
  ) {
    super(app);
  }

  onOpen(): void {
    this.modalEl.addClass("mt-record-modal");
    this.titleEl.empty();
    this.titleEl.addClass("mt-record-card__title");
    const titleIcon = this.titleEl.createSpan({ cls: "mt-record-card__title-icon" });
    setIcon(titleIcon, "file-text");
    this.titleEl.createSpan({ cls: "mt-record-card__title-text", text: this.options.title });
    if (this.options.openNote) {
      const openBtn = this.titleEl.createEl("button", {
        cls: "clickable-icon mt-record-card__open",
        attr: { type: "button", "aria-label": "在新标签打开笔记", title: "打开笔记" }
      });
      setIcon(openBtn, "external-link");
      openBtn.addEventListener("click", () => {
        this.options.openNote?.();
        this.close();
      });
    }

    this.contentEl.empty();
    this.contentEl.addClass("mt-record-card");
    for (const field of this.options.fields) {
      this.renderField(field);
    }
  }

  onClose(): void {
    this.contentEl.empty();
  }

  private renderField(field: RecordCardField): void {
    const row = this.contentEl.createDiv({ cls: "mt-record-field" });
    const label = row.createDiv({ cls: "mt-record-field__label" });
    const icon = label.createSpan({ cls: "mt-record-field__icon" });
    setIcon(icon, field.typeIcon);
    label.createSpan({ cls: "mt-record-field__name", text: field.label });
    if (!field.editable) {
      const lock = label.createSpan({ cls: "mt-record-field__lock", attr: { "aria-label": "只读" } });
      setIcon(lock, "lock-keyhole");
    }

    const control = row.createDiv({ cls: "mt-record-field__control" });
    const error = row.createDiv({ cls: "mt-record-field__error" });
    this.renderControl(field, control, error);
  }

  private renderControl(field: RecordCardField, control: HTMLElement, error: HTMLElement): void {
    control.empty();
    error.setText("");

    if (!field.editable) {
      control.addClass("is-readonly");
      control.createSpan({
        cls: "mt-record-field__readonly",
        text: field.display || "—"
      });
      return;
    }
    control.removeClass("is-readonly");

    if (field.editor === "boolean") {
      const wrap = control.createEl("label", { cls: "mt-record-field__bool" });
      const input = wrap.createEl("input", { type: "checkbox", cls: "mt-checkbox" });
      input.checked = field.primitive === true;
      input.addEventListener("change", () => {
        void this.commit(field, input.checked, control, error);
      });
      wrap.createSpan({ text: input.checked ? "是" : "否" });
      return;
    }

    if (field.editor === "select") {
      const chips = control.createDiv({ cls: "mt-record-field__chips" });
      const current = field.display;
      const renderChip = (option: RecordCardOption) => {
        const chip = chips.createEl("button", {
          cls: "mt-select-chip mt-record-chip",
          text: option.label,
          attr: { type: "button" }
        });
        if (option.color) {
          chip.addClass("has-color");
          chip.style.setProperty("--mt-chip-color", option.color);
        }
        if (option.label === current) chip.addClass("is-active");
        chip.addEventListener("click", () => {
          const next = option.label === current ? undefined : option.label;
          void this.commit(field, next, control, error);
        });
      };
      for (const option of field.options ?? []) renderChip(option);
      if (!field.options || field.options.length === 0) {
        control.createSpan({ cls: "mt-record-field__readonly", text: "未配置选项" });
      } else if (current) {
        const clear = chips.createEl("button", {
          cls: "mt-record-chip mt-record-chip--clear",
          text: "清除",
          attr: { type: "button", "aria-label": "清除选择" }
        });
        clear.addEventListener("click", () => void this.commit(field, undefined, control, error));
      }
      return;
    }

    let input: HTMLInputElement | HTMLTextAreaElement;
    if (field.editor === "textarea") {
      input = control.createEl("textarea", { cls: "mt-record-field__input mt-record-field__input--area" });
      input.value = field.display;
    } else {
      input = control.createEl("input", {
        cls: "mt-record-field__input",
        type: field.editor === "number" ? "number" : field.editor === "date" ? "date" : "text"
      });
      input.value = field.editor === "date" ? dateInputValue(field.display) : field.display;
    }
    input.addEventListener("blur", () => this.commitText(field, input, control, error));
    input.addEventListener("keydown", (rawEvent) => {
      const event = rawEvent as KeyboardEvent;
      if (event.key === "Escape") {
        input.value = field.editor === "date" ? dateInputValue(field.display) : field.display;
        input.blur();
      } else if (event.key === "Enter" && (field.editor !== "textarea" || event.metaKey || event.ctrlKey)) {
        event.preventDefault();
        input.blur();
      }
    });
  }

  private commitText(
    field: RecordCardField,
    input: HTMLInputElement | HTMLTextAreaElement,
    control: HTMLElement,
    error: HTMLElement
  ): void {
    let nextValue: unknown;
    try {
      nextValue = parseEditorValue(field.editor, input.value, { options: field.options } as never);
    } catch (parseError) {
      error.setText(parseError instanceof Error ? parseError.message : "无效输入");
      return;
    }
    if (sameDisplay(field, nextValue)) return;
    void this.commit(field, nextValue, control, error, input);
  }

  private async commit(
    field: RecordCardField,
    nextValue: unknown,
    control: HTMLElement,
    error: HTMLElement,
    keepFocus?: HTMLElement
  ): Promise<void> {
    error.setText("");
    control.addClass("is-saving");
    try {
      await this.options.commit(field, nextValue);
      field.primitive = nextValue;
      field.display = displayForPrimitive(field.editor, nextValue);
      control.removeClass("is-saving");
      control.addClass("is-saved");
      this.modalEl.win.setTimeout(() => control.removeClass("is-saved"), 800);
      // Re-render non-text controls so chips / checkbox reflect the new state.
      if (field.editor === "select" || field.editor === "boolean") {
        this.renderControl(field, control, error);
      } else if (keepFocus instanceof HTMLElement) {
        keepFocus.focus();
      }
    } catch (commitError) {
      control.removeClass("is-saving");
      error.setText(commitError instanceof Error ? commitError.message : "保存失败");
    }
  }
}

function sameDisplay(field: RecordCardField, nextValue: unknown): boolean {
  return displayForPrimitive(field.editor, nextValue) === (field.display ?? "");
}

function displayForPrimitive(editor: EditorKind, value: unknown): string {
  if (value === undefined || value === null) return "";
  if (editor === "boolean") return value === true ? "是" : "否";
  if (Array.isArray(value)) return value.join(", ");
  return String(value);
}

function dateInputValue(display: string): string {
  const match = display.match(/^\d{4}-\d{2}-\d{2}/);
  return match?.[0] ?? "";
}
