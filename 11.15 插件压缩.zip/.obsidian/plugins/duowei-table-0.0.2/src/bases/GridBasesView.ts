import {
  BasesView,
  Menu,
  Notice,
  setIcon,
  type BasesEntry,
  type BasesPropertyId,
  type QueryController,
  type TFile
} from "obsidian";
import { computeVirtualWindow } from "../grid/virtualWindow";
import {
  DEFAULT_VIEW_CONFIG,
  setDensity,
  readDuoweiConfig,
  writeDuoweiConfig,
  type DuoweiViewConfig,
  type EditorKind,
  type FieldViewConfig
} from "../model/config";
import { adaptValue, parseEditorValue, propertyName, type AdaptedValue } from "./ValueAdapter";
import { WriteConflictError, type RecordWriteQueue } from "../write/RecordWriteQueue";
import { RecordCardModal, type RecordCardField } from "./RecordCardModal";

interface GridColumn {
  id: BasesPropertyId;
  label: string;
  width: number;
  fieldConfig?: FieldViewConfig;
}

type FilterOp = "contains" | "equals" | "notEquals" | "empty" | "notEmpty" | "gt" | "lt";

interface FilterRule {
  property: BasesPropertyId;
  op: FilterOp;
  value: string;
}

interface SortRule {
  property: BasesPropertyId;
  direction: "asc" | "desc";
}

interface ActiveCell {
  path: string;
  property: BasesPropertyId;
  rowIndex: number;
  columnIndex: number;
}

interface SelectionRange {
  anchorRow: number;
  anchorColumn: number;
  focusRow: number;
  focusColumn: number;
}

interface DragSelectionState {
  pointerId: number;
  anchorRow: number;
  anchorColumn: number;
  focusRow: number;
  focusColumn: number;
  lastClientX: number;
  lastClientY: number;
  autoScrollFrame: number;
}

interface ColumnDragState {
  pointerId: number;
  sourceIndex: number;
  targetIndex: number;
}

interface NormalizedSelectionRange {
  rowStart: number;
  rowEnd: number;
  columnStart: number;
  columnEnd: number;
}

interface OptimisticCellValue {
  primitive: unknown;
  display: string;
  editor: EditorKind;
}

interface CellTarget {
  entry: BasesEntry;
  column: GridColumn;
  adapted: AdaptedValue;
  state: OptimisticCellValue;
  rowIndex: number;
  columnIndex: number;
}

interface PasteTarget {
  cellTarget: CellTarget | null;
  raw: string;
}

export interface GridViewRuntimeOptions {
  showSaveStatus: () => boolean;
}

export class GridBasesView extends BasesView {
  readonly type = "duowei-grid";

  private readonly hostLeafEl: HTMLElement | null;
  private readonly rootEl: HTMLDivElement;
  private readonly commandBarEl: HTMLDivElement;
  private readonly scrollerEl: HTMLDivElement;
  private readonly headerEl: HTMLDivElement;
  private readonly bodyEl: HTMLDivElement;
  private readonly footerEl: HTMLDivElement;
  private readonly countEl: HTMLSpanElement;
  private readonly statusEl: HTMLSpanElement;
  private readonly densityButtonEl: HTMLButtonElement;
  private readonly filterButtonEl: HTMLButtonElement;
  private readonly sortButtonEl: HTMLButtonElement;
  private readonly searchInputEl: HTMLInputElement;
  private readonly searchWrapEl: HTMLDivElement;
  private readonly addRowEl: HTMLDivElement;

  private allEntries: BasesEntry[] = [];
  private entries: BasesEntry[] = [];
  private quickSearch = "";
  private filters: FilterRule[] = [];
  private sorts: SortRule[] = [];
  private allColumnProperties: BasesPropertyId[] = [];
  private columns: GridColumn[] = [];
  private viewConfig: DuoweiViewConfig;
  private activeCell: ActiveCell | null = null;
  private selectionRange: SelectionRange | null = null;
  private dragSelection: DragSelectionState | null = null;
  private columnDrag: ColumnDragState | null = null;
  private suppressNextHeaderClick = false;
  private readonly optimisticValues = new Map<string, OptimisticCellValue>();
  private renderFrame = 0;
  private lastWindowKey = "";

  constructor(
    controller: QueryController,
    parentEl: HTMLElement,
    private readonly writeQueue: RecordWriteQueue,
    private readonly runtimeOptions: GridViewRuntimeOptions = { showSaveStatus: () => true }
  ) {
    super(controller);
    // Bases injects `config` after the view factory returns. It is safe to
    // read the real configuration in onDataUpdated(), not in the constructor.
    this.viewConfig = {
      ...DEFAULT_VIEW_CONFIG,
      fields: {},
      columns: {}
    };

    this.hostLeafEl = parentEl.closest(".workspace-leaf-content");
    this.hostLeafEl?.addClass("mt-table-app-host");
    this.register(() => this.hostLeafEl?.removeClass("mt-table-app-host"));

    this.rootEl = parentEl.createDiv({ cls: "mt-view mt-view--table-app" });
    this.commandBarEl = this.rootEl.createDiv({ cls: "mt-command-bar" });

    const tools = this.commandBarEl.createDiv({ cls: "mt-command-bar__group mt-command-bar__group--tools" });
    this.createToolButton(tools, "columns-3", "字段", (event) =>
      this.openTableColumnsMenu(event.currentTarget as HTMLElement)
    );
    this.filterButtonEl = this.createToolButton(tools, "list-filter", "筛选", (event) =>
      this.openFilterPanel(event.currentTarget as HTMLElement)
    );
    this.sortButtonEl = this.createToolButton(tools, "arrow-up-down", "排序", (event) =>
      this.openSortPanel(event.currentTarget as HTMLElement)
    );
    this.densityButtonEl = this.createToolButton(tools, "rows-3", "行高", (event) =>
      this.openDensityMenu(event.currentTarget as HTMLElement)
    );

    const end = this.commandBarEl.createDiv({ cls: "mt-command-bar__group mt-command-bar__group--end" });
    this.searchWrapEl = end.createDiv({ cls: "mt-command-bar__search is-collapsed" });
    const searchToggle = this.searchWrapEl.createEl("button", {
      cls: "clickable-icon mt-command-button mt-command-button--icon mt-search-toggle",
      attr: { type: "button", "aria-label": "搜索", title: "搜索" }
    });
    setIcon(searchToggle.createSpan({ cls: "mt-command-button__icon", attr: { "aria-hidden": "true" } }), "search");
    this.searchInputEl = this.searchWrapEl.createEl("input", {
      cls: "mt-command-search",
      type: "search",
      attr: { placeholder: "搜索当前表格", "aria-label": "搜索当前表格" }
    });
    searchToggle.addEventListener("click", () => this.toggleSearch());
    this.searchInputEl.addEventListener("input", () => {
      this.quickSearch = this.searchInputEl.value.trim().toLowerCase();
      this.recomputeEntries();
    });
    this.searchInputEl.addEventListener("blur", () => {
      if (!this.searchInputEl.value.trim()) this.searchWrapEl.addClass("is-collapsed");
    });
    this.searchInputEl.addEventListener("keydown", (event) => {
      if ((event as KeyboardEvent).key === "Escape") {
        this.searchInputEl.value = "";
        this.quickSearch = "";
        this.recomputeEntries();
        this.searchWrapEl.addClass("is-collapsed");
        this.scrollerEl.focus();
      }
    });

    const overflow = end.createEl("button", {
      cls: "clickable-icon mt-command-button mt-command-button--icon",
      attr: { type: "button", "aria-label": "更多操作", title: "更多操作" }
    });
    setIcon(overflow.createSpan({ cls: "mt-command-button__icon", attr: { "aria-hidden": "true" } }), "more-horizontal");
    overflow.addEventListener("click", (event) => this.openOverflowMenu(event.currentTarget as HTMLElement));

    this.scrollerEl = this.rootEl.createDiv({ cls: "mt-grid-scroller" });
    this.scrollerEl.tabIndex = 0;
    this.scrollerEl.setAttr("role", "grid");
    this.scrollerEl.setAttr("aria-label", "多维表格");
    this.headerEl = this.scrollerEl.createDiv({ cls: "mt-grid-header", attr: { role: "row" } });
    this.bodyEl = this.scrollerEl.createDiv({ cls: "mt-grid-body" });

    this.addRowEl = this.scrollerEl.createDiv({
      cls: "mt-grid-add-row",
      attr: { role: "button", tabindex: "0", "aria-label": "新增记录" }
    });
    const addInner = this.addRowEl.createDiv({ cls: "mt-grid-add-row__inner" });
    setIcon(addInner.createSpan({ cls: "mt-grid-add-row__icon", attr: { "aria-hidden": "true" } }), "plus");
    addInner.createSpan({ cls: "mt-grid-add-row__label", text: "新增记录" });
    const triggerAdd = () => void this.createFileForView("新记录");
    this.addRowEl.addEventListener("click", triggerAdd);
    this.addRowEl.addEventListener("keydown", (event) => {
      const key = (event as KeyboardEvent).key;
      if (key === "Enter" || key === " ") {
        event.preventDefault();
        triggerAdd();
      }
    });

    this.scrollerEl.addEventListener("contextmenu", (event) => this.openCellContextMenu(event));

    this.footerEl = this.rootEl.createDiv({ cls: "mt-grid-footer" });
    this.footerEl.createSpan({
      cls: "mt-grid-footer__hint",
      text: "Enter 下移 · Tab 右移 · Shift+方向键选区 · Ctrl+C/V 复制粘贴 · 右键更多操作"
    });
    const footerEnd = this.footerEl.createDiv({ cls: "mt-grid-footer__end" });
    this.countEl = footerEnd.createSpan({ cls: "mt-command-bar__count" });
    this.statusEl = footerEnd.createSpan({ cls: "mt-save-status", text: "已同步" });

    this.registerDomEvent(this.scrollerEl, "scroll", () => this.scheduleRows());
    this.registerDomEvent(this.scrollerEl, "keydown", (event) => this.handleGridKeydown(event));
    this.registerDomEvent(this.scrollerEl, "copy", (event) => this.handleCopy(event));
    this.registerDomEvent(this.scrollerEl, "paste", (event) => {
      void this.handlePaste(event);
    });

    const observer = new ResizeObserver(() => this.scheduleRows(true));
    observer.observe(this.scrollerEl);
    this.register(() => observer.disconnect());
    this.register(() => {
      if (this.renderFrame) this.rootEl.win.cancelAnimationFrame(this.renderFrame);
      this.stopDragSelection();
    });

    this.updateDensityLabel();
    this.applyRuntimeSettings();
  }

  onDataUpdated(): void {
    this.viewConfig = readDuoweiConfig(this.config);
    this.allEntries = this.data.data;
    const order = this.config.getOrder();
    this.allColumnProperties = this.applyColumnOrder(order.length > 0 ? order : this.data.properties);
    const properties = this.allColumnProperties.filter((property) => !this.viewConfig.columns[property]?.hidden);
    this.columns = properties.map((property, index) => ({
      id: property,
      label: this.getPropertyLabel(property),
      width: this.getColumnWidth(property, index),
      fieldConfig: this.viewConfig.fields[property]
    }));
    this.pruneObsoleteRules();
    this.recomputeEntries(false);
    this.syncActiveCellIndexes();
    this.reconcileOptimisticValues();

    this.updateCountLabel();
    this.updateToolBadges();
    this.scrollerEl.setAttr("aria-rowcount", String(this.entries.length));
    this.scrollerEl.setAttr("aria-colcount", String(this.columns.length));
    this.updateDensityLabel();
    this.applyRuntimeSettings();
    this.renderHeader();
    this.refreshLayout(true);
  }

  private refreshLayout(force = false): void {
    const totalWidth = this.totalWidth();
    this.headerEl.style.width = `${totalWidth}px`;
    this.bodyEl.style.width = `${totalWidth}px`;
    this.bodyEl.style.height = `${this.entries.length * this.viewConfig.rowHeight}px`;
    this.addRowEl.style.width = `${totalWidth}px`;
    this.rootEl.style.setProperty("--mt-row-height", `${this.viewConfig.rowHeight}px`);
    if (force) this.lastWindowKey = "";
    this.scheduleRows(force);
  }

  private renderHeader(): void {
    this.headerEl.empty();
    this.headerEl.style.gridTemplateColumns = this.gridTemplate();

    this.headerEl.createDiv({
      cls: "mt-grid-header__index",
      text: "#",
      attr: { role: "columnheader", "aria-label": "行号" }
    });

    this.columns.forEach((column, columnIndex) => {
      const header = this.headerEl.createDiv({
        cls: "mt-grid-header__cell",
        attr: {
          role: "columnheader",
          "aria-colindex": String(columnIndex + 1),
          "data-column": String(columnIndex),
          title: column.id
        }
      });
      if (this.isFrozenColumn(columnIndex)) {
        header.addClass("is-frozen");
        header.style.left = `${this.frozenColumnLeft(columnIndex)}px`;
      }
      if (this.isColumnSelected(columnIndex)) header.addClass("is-selected");
      const typeIcon = header.createSpan({ cls: "mt-grid-header__type-icon", attr: { "aria-hidden": "true" } });
      setIcon(typeIcon, this.fieldTypeIcon(column));
      header.createSpan({ cls: "mt-grid-header__label", text: column.label });
      if (!this.isEditableProperty(column.id)) {
        const marker = header.createSpan({ cls: "mt-grid-header__readonly", attr: { "aria-label": "只读" } });
        setIcon(marker, column.id.startsWith("formula.") ? "function-square" : "lock-keyhole");
      }
      const menuButton = header.createEl("button", {
        cls: "clickable-icon mt-column-menu-button",
        attr: { type: "button", "aria-label": `${column.label} 列操作`, title: "列操作" }
      });
      setIcon(menuButton, "more-horizontal");
      menuButton.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        this.openColumnMenu(menuButton, column);
      });
      const resize = header.createDiv({ cls: "mt-column-resize", attr: { "aria-hidden": "true" } });
      resize.addEventListener("pointerdown", (event) => this.beginResize(event, column));
      header.addEventListener("pointerdown", (event) => {
        if (event.target === resize || menuButton.contains(event.target as Node)) return;
        this.beginColumnDrag(event, columnIndex);
      });
      header.addEventListener("pointerenter", (event) => this.updateColumnDragTarget(event, columnIndex));
      header.addEventListener("click", (event) => {
        if (event.target === resize || menuButton.contains(event.target as Node)) return;
        if (this.suppressNextHeaderClick) {
          this.suppressNextHeaderClick = false;
          return;
        }
        this.selectColumn(columnIndex, event.shiftKey);
      });
    });
  }

  private fieldTypeIcon(column: GridColumn): string {
    if (column.id === "file.name") return "file-text";
    if (column.id.startsWith("formula.")) return "function-square";
    switch (column.fieldConfig?.editor) {
      case "number":
        return "hash";
      case "boolean":
        return "check-square";
      case "date":
        return "calendar";
      case "select":
        return "chevron-down-circle";
      case "readonly":
        return "lock-keyhole";
      default:
        return "type";
    }
  }

  private openSelectPopover(
    cell: HTMLElement,
    file: TFile,
    column: GridColumn,
    previousValue: unknown,
    display: string,
    moveAfterCommit: "down" | "right" | "left" | "none"
  ): void {
    const options = column.fieldConfig?.options ?? [];
    const popover = this.rootEl.doc.body.createDiv({ cls: "mt-select-popover" });
    const searchWrap = popover.createDiv({ cls: "mt-select-popover__search" });
    const searchInput = searchWrap.createEl("input", {
      cls: "mt-select-popover__input",
      type: "text",
      attr: { placeholder: "搜索选项", "aria-label": "搜索选项" }
    });
    const list = popover.createDiv({ cls: "mt-select-popover__list" });

    let closed = false;
    const close = (commit: boolean, label?: string) => {
      if (closed) return;
      closed = true;
      this.rootEl.doc.removeEventListener("pointerdown", onOutside, true);
      this.rootEl.win.removeEventListener("resize", onReposition);
      this.scrollerEl.removeEventListener("scroll", onReposition);
      popover.remove();
      cell.removeClass("is-editing");
      if (commit) {
        void this.commit(cell, file, column, previousValue, label || undefined, "select").then(() => {
          this.moveAfterCommit(cell, moveAfterCommit);
        }).catch((error) => {
          cell.addClass("is-error");
          this.setStatus(errorMessage(error), "error");
        });
      } else {
        this.focusRenderedActiveCell();
      }
    };

    const renderOptions = (query: string) => {
      list.empty();
      const normalized = query.trim().toLowerCase();
      const clearRow = list.createDiv({ cls: "mt-select-popover__option mt-select-popover__option--clear" });
      clearRow.createSpan({ cls: "mt-select-popover__option-label", text: "清除内容" });
      if (!display) {
        const check = clearRow.createSpan({ cls: "mt-select-popover__check", attr: { "aria-hidden": "true" } });
        setIcon(check, "check");
      }
      clearRow.addEventListener("click", () => close(true, undefined));
      let shown = 0;
      for (const option of options) {
        if (normalized && !option.label.toLowerCase().includes(normalized)) continue;
        shown += 1;
        const row = list.createDiv({ cls: "mt-select-popover__option" });
        const chip = row.createSpan({ cls: "mt-select-chip", text: option.label });
        if (option.color) {
          chip.addClass("has-color");
          chip.style.setProperty("--mt-chip-color", option.color);
        }
        if (option.label === display) {
          const check = row.createSpan({ cls: "mt-select-popover__check", attr: { "aria-hidden": "true" } });
          setIcon(check, "check");
        }
        row.addEventListener("click", () => close(true, option.label));
      }
      if (shown === 0 && normalized) {
        list.createDiv({ cls: "mt-select-popover__empty", text: "无匹配选项" });
      }
    };

    const reposition = () => {
      const rect = cell.getBoundingClientRect();
      const width = Math.max(rect.width, 200);
      const maxHeight = 280;
      const spaceBelow = this.rootEl.win.innerHeight - rect.bottom;
      const openUp = spaceBelow < maxHeight && rect.top > spaceBelow;
      popover.style.width = `${width}px`;
      popover.style.left = `${Math.min(rect.left, this.rootEl.win.innerWidth - width - 8)}px`;
      if (openUp) {
        popover.style.top = "";
        popover.style.bottom = `${this.rootEl.win.innerHeight - rect.top + 4}px`;
      } else {
        popover.style.bottom = "";
        popover.style.top = `${rect.bottom + 4}px`;
      }
    };
    const onReposition = () => reposition();
    const onOutside = (event: PointerEvent) => {
      if (!popover.contains(event.target as Node)) close(false);
    };

    searchInput.addEventListener("input", () => renderOptions(searchInput.value));
    searchInput.addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        event.preventDefault();
        close(false);
      }
    });
    popover.addEventListener("pointerdown", (event) => event.stopPropagation());

    cell.addClass("is-editing");
    renderOptions("");
    reposition();
    this.rootEl.doc.addEventListener("pointerdown", onOutside, true);
    this.rootEl.win.addEventListener("resize", onReposition);
    this.scrollerEl.addEventListener("scroll", onReposition);
    searchInput.focus();
  }

  private openRecordCard(rowIndex: number): void {
    const entry = this.entries[rowIndex];
    if (!entry) return;
    const fields: RecordCardField[] = this.allColumnProperties.map((property) => {
      const fieldConfig = this.viewConfig.fields[property];
      const adapted = adaptValue(property, entry.getValue(property), fieldConfig);
      const state = this.getCellState(entry.file.path, property, adapted);
      return {
        id: property,
        label: this.getPropertyLabel(property),
        editor: state.editor,
        editable: adapted.editable,
        display: state.display,
        primitive: state.primitive,
        typeIcon: this.fieldTypeIcon({ id: property, label: "", width: 0, fieldConfig }),
        options: fieldConfig?.options
      };
    });

    const modal = new RecordCardModal(this.app, {
      title: entry.file.basename,
      fields,
      commit: async (field, nextValue) => {
        const column: GridColumn = {
          id: field.id,
          label: field.label,
          width: 0,
          fieldConfig: this.viewConfig.fields[field.id]
        };
        const cell = this.cellElementFor(entry.file.path, field.id);
        await this.commit(cell, entry.file, column, field.primitive, nextValue, field.editor);
        this.scheduleRows(true);
      },
      openNote: () => {
        void this.app.workspace.getLeaf("tab").openFile(entry.file);
      }
    });
    modal.open();
  }

  private scheduleRows(force = false): void {
    if (force) this.lastWindowKey = "";
    if (this.renderFrame) return;
    this.renderFrame = this.rootEl.win.requestAnimationFrame(() => {
      this.renderFrame = 0;
      this.renderRows();
    });
  }

  private renderRows(): void {
    if (this.entries.length === 0 || this.columns.length === 0) {
      this.lastWindowKey = "empty";
      this.bodyEl.empty();
      const empty = this.bodyEl.createDiv({ cls: "mt-empty-state" });
      const icon = empty.createDiv({ cls: "mt-empty-state__icon" });
      setIcon(icon, "table-properties");
      empty.createDiv({ cls: "mt-empty-state__title", text: "没有可显示的记录" });
      empty.createDiv({ cls: "mt-empty-state__hint", text: "调整 Bases 筛选条件或添加显示属性。" });
      return;
    }

    const headerHeight = this.headerEl.getBoundingClientRect().height || 34;
    const virtual = computeVirtualWindow({
      scrollTop: Math.max(0, this.scrollerEl.scrollTop - headerHeight),
      viewportHeight: Math.max(0, this.scrollerEl.clientHeight - headerHeight),
      rowHeight: this.viewConfig.rowHeight,
      count: this.entries.length,
      overscan: 8
    });
    const windowKey = `${virtual.start}:${virtual.end}:${this.columns.length}:${this.viewConfig.rowHeight}`;
    if (windowKey === this.lastWindowKey) return;
    this.lastWindowKey = windowKey;

    this.bodyEl.empty();
    this.bodyEl.style.height = `${this.entries.length * this.viewConfig.rowHeight}px`;
    this.bodyEl.style.width = `${this.totalWidth()}px`;

    for (let rowIndex = virtual.start; rowIndex < virtual.end; rowIndex += 1) {
      const entry = this.entries[rowIndex];
      if (!entry) continue;
      this.renderRow(entry, rowIndex);
    }
  }

  private renderRow(entry: BasesEntry, rowIndex: number): void {
    const row = this.bodyEl.createDiv({
      cls: "mt-grid-row",
      attr: { role: "row", "aria-rowindex": String(rowIndex + 1) }
    });
    row.style.top = `${rowIndex * this.viewConfig.rowHeight}px`;
    row.style.height = `${this.viewConfig.rowHeight}px`;
    row.style.gridTemplateColumns = this.gridTemplate();

    const rowIndexEl = row.createDiv({
      cls: "mt-grid-row__index",
      attr: { role: "rowheader", "data-row": String(rowIndex) }
    });
    const selected = this.isRowSelected(rowIndex);
    if (selected) rowIndexEl.addClass("is-selected");
    rowIndexEl.createSpan({ cls: "mt-grid-row__number", text: String(rowIndex + 1) });
    const rowActions = rowIndexEl.createDiv({ cls: "mt-grid-row__actions" });
    const checkbox = rowActions.createEl("input", {
      cls: "mt-row-checkbox",
      type: "checkbox",
      attr: { "aria-label": `选择第 ${rowIndex + 1} 行` }
    });
    checkbox.checked = selected;
    checkbox.addEventListener("click", (event) => event.stopPropagation());
    checkbox.addEventListener("change", (event) =>
      this.selectRow(rowIndex, (event as MouseEvent).shiftKey)
    );
    const expandBtn = rowActions.createEl("button", {
      cls: "clickable-icon mt-row-expand",
      attr: { type: "button", "aria-label": "展开记录", title: "展开记录" }
    });
    setIcon(expandBtn, "maximize-2");
    expandBtn.addEventListener("click", (event) => {
      event.stopPropagation();
      this.openRecordCard(rowIndex);
    });
    rowIndexEl.addEventListener("click", (event) => {
      if (event.target === checkbox || expandBtn.contains(event.target as Node)) return;
      this.selectRow(rowIndex, event.shiftKey);
    });

    this.columns.forEach((column, columnIndex) => {
      const value = entry.getValue(column.id);
      const adapted = adaptValue(column.id, value, column.fieldConfig);
      const cellState = this.getCellState(entry.file.path, column.id, adapted);
      const cell = row.createDiv({
        cls: "mt-grid-cell",
        attr: {
          role: "gridcell",
          "aria-colindex": String(columnIndex + 1),
          "aria-readonly": String(!adapted.editable),
          "data-path": entry.file.path,
          "data-property": column.id,
          "data-row": String(rowIndex),
          "data-column": String(columnIndex)
        }
      });
      cell.tabIndex = this.isActive(entry.file.path, column.id) ? 0 : -1;
      if (this.isActive(entry.file.path, column.id)) cell.addClass("is-active");
      if (this.isCellSelected(rowIndex, columnIndex)) cell.addClass("is-selected");
      this.updateSelectionEdgeClasses(cell, rowIndex, columnIndex);
      if (!adapted.editable) cell.addClass("is-readonly");
      if (this.isFrozenColumn(columnIndex)) {
        cell.addClass("is-frozen");
        cell.style.left = `${this.frozenColumnLeft(columnIndex)}px`;
      }

      this.renderCellValue(cell, entry.file, column, cellState.primitive, cellState.display, cellState.editor, adapted.editable);

      cell.addEventListener("pointerdown", (event) =>
        this.beginCellPointerSelection(event, cell, entry.file.path, column.id, rowIndex, columnIndex)
      );
      cell.addEventListener("pointerenter", (event) => this.extendDragSelection(rowIndex, columnIndex, event));
      cell.addEventListener("dblclick", (event) => {
        event.preventDefault();
        if (adapted.editable) {
          const current = this.getCellState(entry.file.path, column.id, adapted);
          this.beginEdit(cell, entry.file, column, current.primitive, current.display, current.editor);
        }
      });
    });
  }

  private renderCellValue(
    cell: HTMLElement,
    file: TFile,
    column: GridColumn,
    primitive: unknown,
    display: string,
    editor: EditorKind,
    editable: boolean
  ): void {
    cell.removeClass("is-editing");
    cell.empty();
    if (editor === "boolean") {
      const input = cell.createEl("input", {
        cls: "mt-checkbox",
        type: "checkbox",
        attr: { "aria-label": column.label }
      });
      input.checked = primitive === true;
      input.disabled = !editable;
      if (editable) {
        input.addEventListener("click", (event) => event.stopPropagation());
        input.addEventListener("change", () => {
          void this.commit(cell, file, column, primitive, input.checked, "boolean");
        });
      }
      return;
    }

    if (editor === "select" && display) {
      const chip = cell.createSpan({ cls: "mt-select-chip", text: display });
      const option = column.fieldConfig?.options?.find((candidate) => candidate.label === display);
      if (option?.color) {
        chip.addClass("has-color");
        chip.style.setProperty("--mt-chip-color", option.color);
      }
      return;
    }

    if (column.id === "file.name") {
      const fileEl = cell.createSpan({ cls: "mt-grid-cell__file" });
      const icon = fileEl.createSpan({ cls: "mt-grid-cell__file-icon", attr: { "aria-hidden": "true" } });
      setIcon(icon, "file-text");
      fileEl.createSpan({ cls: "mt-grid-cell__value mt-grid-cell__file-link", text: display });
      cell.title = file.path;
      return;
    }

    cell.createSpan({ cls: "mt-grid-cell__value", text: display });
    cell.title = display;
  }

  private beginEdit(
    cell: HTMLElement,
    file: TFile,
    column: GridColumn,
    previousValue: unknown,
    display: string,
    editor: EditorKind,
    options: { initialText?: string; moveAfterCommit?: "down" | "right" | "left" | "none" } = {}
  ): void {
    if (cell.hasClass("is-editing")) return;

    if (editor === "select") {
      this.openSelectPopover(cell, file, column, previousValue, display, options.moveAfterCommit ?? "none");
      return;
    }

    cell.addClass("is-editing");
    cell.empty();

    let input: HTMLInputElement | HTMLTextAreaElement;
    if (editor === "textarea") {
      input = cell.createEl("textarea", {
        cls: "mt-cell-editor mt-cell-editor--textarea",
        attr: { "aria-label": `编辑${column.label}` }
      });
      input.value = options.initialText ?? display;
    } else {
      input = cell.createEl("input", {
        cls: "mt-cell-editor",
        type: editor === "number" ? "number" : editor === "date" ? "date" : "text",
        value: options.initialText ?? (editor === "date" ? dateInputValue(display) : display),
        attr: { "aria-label": `编辑${column.label}` }
      });
      if (column.id === "file.name") {
        input.addClass("mt-cell-editor--file-name");
        const icon = cell.createSpan({ cls: "mt-cell-editor__file-icon", attr: { "aria-hidden": "true" } });
        setIcon(icon, "file-text");
      }
    }
    let settled = false;
    const settle = (commit: boolean, moveAfterCommit: "down" | "right" | "left" | "none" = options.moveAfterCommit ?? "none") => {
      if (settled) return;
      settled = true;
      if (!commit) {
        cell.removeClass("is-error", "is-conflict");
        this.renderCellValue(cell, file, column, previousValue, display, editor, true);
        return;
      }
      try {
        const nextValue = parseEditorValue(editor, input.value, column.fieldConfig);
        void this.commit(cell, file, column, previousValue, nextValue, editor).then(() => {
          this.moveAfterCommit(cell, moveAfterCommit);
        }).catch((error) => {
          settled = false;
          cell.addClass("is-error");
          this.setStatus(errorMessage(error), "error");
          if (input.isConnected) {
            input.focus();
            input.select();
          }
        });
      } catch (error) {
        settled = false;
        cell.addClass("is-error");
        this.setStatus(errorMessage(error), "error");
        input.focus();
        input.select();
      }
    };
    input.addEventListener("blur", () => settle(true));
    input.addEventListener("keydown", (event) => {
      const keyEvent = event as KeyboardEvent;
      if (keyEvent.key === "Escape") {
        keyEvent.preventDefault();
        settle(false);
      } else if (keyEvent.key === "Tab") {
        keyEvent.preventDefault();
        settle(true, keyEvent.shiftKey ? "left" : "right");
      } else if (keyEvent.key === "Enter" && (editor !== "textarea" || keyEvent.metaKey || keyEvent.ctrlKey)) {
        keyEvent.preventDefault();
        settle(true, "down");
      }
    });
    input.focus();
    input.select();
  }

  private async commit(
    cell: HTMLElement | null,
    file: TFile,
    column: GridColumn,
    previousValue: unknown,
    nextValue: unknown,
    editor: EditorKind
  ): Promise<void> {
    if (column.id === "file.name") {
      await this.commitFileName(cell, file, column, previousValue, nextValue, editor);
      return;
    }

    const name = propertyName(column.id);
    if (!name) return;

    cell?.removeClass("is-editing", "is-error", "is-conflict");
    cell?.addClass("is-saving");
    this.setStatus(`正在保存 · ${this.writeQueue.pendingCount + 1}`, "saving");
    this.setOptimisticValue(file.path, column.id, nextValue, editor);
    if (cell) {
      this.renderCellValue(
        cell,
        file,
        column,
        nextValue,
        displayForPrimitive(editor, nextValue),
        editor,
        true
      );
    }

    try {
      await this.writeQueue.enqueue(file, name, previousValue, nextValue);
      cell?.removeClass("is-saving");
      cell?.addClass("is-saved");
      this.setStatus(this.writeQueue.pendingCount > 0 ? `正在保存 · ${this.writeQueue.pendingCount}` : "已保存", "saved");
      if (cell) this.rootEl.win.setTimeout(() => cell.removeClass("is-saved"), 900);
    } catch (error) {
      this.optimisticValues.delete(cellKey(file.path, column.id));
      cell?.removeClass("is-saving");
      cell?.addClass(error instanceof WriteConflictError ? "is-conflict" : "is-error");
      if (cell) {
        this.renderCellValue(
          cell,
          file,
          column,
          previousValue,
          displayForPrimitive(editor, previousValue),
          editor,
          true
        );
      }
      const message = errorMessage(error);
      this.setStatus(message, error instanceof WriteConflictError ? "conflict" : "error");
      new Notice(message, 5000);
    }
  }

  private async commitFileName(
    cell: HTMLElement | null,
    file: TFile,
    column: GridColumn,
    previousValue: unknown,
    nextValue: unknown,
    editor: EditorKind
  ): Promise<void> {
    const previousPath = file.path;
    const nextBaseName = String(nextValue ?? "").trim();
    const previousBaseName = String(previousValue ?? file.basename);
    if (!nextBaseName) {
      this.setStatus("文件名不能为空", "error");
      cell?.addClass("is-error");
      throw new Error("文件名不能为空");
    }
    if (/[\\/:*?"<>|]/.test(nextBaseName)) {
      this.setStatus("文件名包含非法字符", "error");
      cell?.addClass("is-error");
      throw new Error("文件名包含非法字符");
    }
    if (nextBaseName === previousBaseName) {
      cell?.removeClass("is-editing", "is-error", "is-conflict", "is-saving");
      if (cell) this.renderCellValue(cell, file, column, previousBaseName, previousBaseName, editor, true);
      cell?.addClass("is-saved");
      if (cell) this.rootEl.win.setTimeout(() => cell.removeClass("is-saved"), 900);
      this.setStatus("已保存", "saved");
      return;
    }

    const nextPath = file.parent
      ? `${file.parent.path === "/" ? "" : `${file.parent.path}/`}${nextBaseName}.${file.extension}`
      : `${nextBaseName}.${file.extension}`;
    const existing = this.app.vault.getAbstractFileByPath(nextPath);
    if (existing && existing !== file) {
      this.setStatus("目标文件名已存在", "error");
      cell?.addClass("is-error");
      throw new Error("目标文件名已存在");
    }

    cell?.removeClass("is-editing", "is-error", "is-conflict");
    cell?.addClass("is-saving");
    this.setStatus("正在重命名文件", "saving");
    this.optimisticValues.delete(cellKey(file.path, column.id));
    this.setOptimisticValue(file.path, column.id, nextBaseName, editor);
    if (cell) this.renderCellValue(cell, file, column, nextBaseName, nextBaseName, editor, true);

    try {
      await this.app.vault.rename(file, nextPath);
      this.optimisticValues.delete(cellKey(previousPath, column.id));
      this.optimisticValues.delete(cellKey(file.path, column.id));
      if (this.activeCell?.path === previousPath) this.activeCell = { ...this.activeCell, path: nextPath };
      if (cell) cell.dataset.path = nextPath;
      cell?.removeClass("is-saving");
      cell?.addClass("is-saved");
      this.setStatus("已重命名", "saved");
      if (cell) this.rootEl.win.setTimeout(() => cell.removeClass("is-saved"), 900);
    } catch (error) {
      this.optimisticValues.delete(cellKey(file.path, column.id));
      cell?.removeClass("is-saving");
      cell?.addClass("is-error");
      if (cell) this.renderCellValue(cell, file, column, previousValue, previousBaseName, editor, true);
      const message = errorMessage(error);
      this.setStatus(message, "error");
      new Notice(message, 5000);
      throw error instanceof Error ? error : new Error(message);
    }
  }

  private activateCell(
    cell: HTMLElement,
    path: string,
    property: BasesPropertyId,
    rowIndex: number,
    columnIndex: number,
    extendSelection = false
  ): void {
    const anchorRow = extendSelection
      ? this.selectionRange?.anchorRow ?? this.activeCell?.rowIndex ?? rowIndex
      : rowIndex;
    const anchorColumn = extendSelection
      ? this.selectionRange?.anchorColumn ?? this.activeCell?.columnIndex ?? columnIndex
      : columnIndex;

    this.activeCell = { path, property, rowIndex, columnIndex };
    this.selectionRange = {
      anchorRow,
      anchorColumn,
      focusRow: rowIndex,
      focusColumn: columnIndex
    };
    this.updateRenderedSelectionState();
    cell.focus({ preventScroll: true });
  }

  private beginCellPointerSelection(
    event: PointerEvent,
    cell: HTMLElement,
    path: string,
    property: BasesPropertyId,
    rowIndex: number,
    columnIndex: number
  ): void {
    if (event.button !== 0) return;
    if (isEditorElement(event.target)) return;

    event.preventDefault();
    this.stopDragSelection();
    const anchorRow = event.shiftKey
      ? this.selectionRange?.anchorRow ?? this.activeCell?.rowIndex ?? rowIndex
      : rowIndex;
    const anchorColumn = event.shiftKey
      ? this.selectionRange?.anchorColumn ?? this.activeCell?.columnIndex ?? columnIndex
      : columnIndex;

    this.activeCell = { path, property, rowIndex, columnIndex };
    this.selectionRange = {
      anchorRow,
      anchorColumn,
      focusRow: rowIndex,
      focusColumn: columnIndex
    };
    this.dragSelection = {
      pointerId: event.pointerId,
      anchorRow,
      anchorColumn,
      focusRow: rowIndex,
      focusColumn: columnIndex,
      lastClientX: event.clientX,
      lastClientY: event.clientY,
      autoScrollFrame: 0
    };

    this.scrollerEl.addClass("is-drag-selecting");
    cell.setPointerCapture(event.pointerId);
    cell.focus({ preventScroll: true });
    this.updateRenderedSelectionState();
    this.setStatus("拖动选择区域", "saved");

    const onPointerMove = (moveEvent: PointerEvent) => this.updateDragSelectionFromPoint(moveEvent);
    const onPointerEnd = (endEvent: PointerEvent) => {
      if (endEvent.pointerId !== this.dragSelection?.pointerId) return;
      cell.removeEventListener("pointermove", onPointerMove);
      cell.removeEventListener("pointerup", onPointerEnd);
      cell.removeEventListener("pointercancel", onPointerEnd);
      if (cell.hasPointerCapture(endEvent.pointerId)) cell.releasePointerCapture(endEvent.pointerId);
      this.finishDragSelection();
    };
    cell.addEventListener("pointermove", onPointerMove);
    cell.addEventListener("pointerup", onPointerEnd);
    cell.addEventListener("pointercancel", onPointerEnd);
    this.scheduleDragAutoScroll();
  }

  private extendDragSelection(rowIndex: number, columnIndex: number, event: PointerEvent): void {
    if (!this.dragSelection || event.pointerId !== this.dragSelection.pointerId) return;
    this.dragSelection.lastClientX = event.clientX;
    this.dragSelection.lastClientY = event.clientY;
    this.setDragFocus(rowIndex, columnIndex);
  }

  private updateDragSelectionFromPoint(event: PointerEvent): void {
    if (!this.dragSelection || event.pointerId !== this.dragSelection.pointerId) return;
    this.dragSelection.lastClientX = event.clientX;
    this.dragSelection.lastClientY = event.clientY;
    const target = this.cellPositionFromPoint(event.clientX, event.clientY);
    if (target) this.setDragFocus(target.rowIndex, target.columnIndex);
  }

  private setDragFocus(rowIndex: number, columnIndex: number): void {
    if (!this.dragSelection) return;
    const safeRow = clamp(rowIndex, 0, this.entries.length - 1);
    const safeColumn = clamp(columnIndex, 0, this.columns.length - 1);
    if (this.dragSelection.focusRow === safeRow && this.dragSelection.focusColumn === safeColumn) return;

    this.dragSelection.focusRow = safeRow;
    this.dragSelection.focusColumn = safeColumn;
    const entry = this.entries[safeRow];
    const column = this.columns[safeColumn];
    if (entry && column) {
      this.activeCell = { path: entry.file.path, property: column.id, rowIndex: safeRow, columnIndex: safeColumn };
    }
    this.selectionRange = {
      anchorRow: this.dragSelection.anchorRow,
      anchorColumn: this.dragSelection.anchorColumn,
      focusRow: safeRow,
      focusColumn: safeColumn
    };
    this.updateRenderedSelectionState();
  }

  private scheduleDragAutoScroll(): void {
    if (!this.dragSelection || this.dragSelection.autoScrollFrame) return;
    this.dragSelection.autoScrollFrame = this.rootEl.win.requestAnimationFrame(() => {
      if (!this.dragSelection) return;
      this.dragSelection.autoScrollFrame = 0;
      this.updateDragAutoScroll();
      this.scheduleDragAutoScroll();
    });
  }

  private updateDragAutoScroll(): void {
    if (!this.dragSelection) return;
    const rect = this.scrollerEl.getBoundingClientRect();
    const edgeSize = 36;
    const maxStep = 24;
    let deltaX = 0;
    let deltaY = 0;

    if (this.dragSelection.lastClientX < rect.left + edgeSize) {
      deltaX = -Math.ceil(((rect.left + edgeSize - this.dragSelection.lastClientX) / edgeSize) * maxStep);
    } else if (this.dragSelection.lastClientX > rect.right - edgeSize) {
      deltaX = Math.ceil(((this.dragSelection.lastClientX - (rect.right - edgeSize)) / edgeSize) * maxStep);
    }

    if (this.dragSelection.lastClientY < rect.top + edgeSize) {
      deltaY = -Math.ceil(((rect.top + edgeSize - this.dragSelection.lastClientY) / edgeSize) * maxStep);
    } else if (this.dragSelection.lastClientY > rect.bottom - edgeSize) {
      deltaY = Math.ceil(((this.dragSelection.lastClientY - (rect.bottom - edgeSize)) / edgeSize) * maxStep);
    }

    if (deltaX !== 0) this.scrollerEl.scrollLeft += deltaX;
    if (deltaY !== 0) this.scrollerEl.scrollTop += deltaY;

    if (deltaX !== 0 || deltaY !== 0) {
      const target = this.cellPositionFromPoint(
        this.dragSelection.lastClientX,
        this.dragSelection.lastClientY
      );
      if (target) this.setDragFocus(target.rowIndex, target.columnIndex);
    }
  }

  private finishDragSelection(): void {
    const range = this.normalizedSelectionRange();
    const selected = range ? rangeCellCount(range) : 0;
    this.stopDragSelection();
    if (selected > 1) this.setStatus(`已选择 ${selected} 个单元格`, "saved");
  }

  private stopDragSelection(): void {
    if (!this.dragSelection) return;
    if (this.dragSelection.autoScrollFrame) {
      this.rootEl.win.cancelAnimationFrame(this.dragSelection.autoScrollFrame);
    }
    this.dragSelection = null;
    this.scrollerEl.removeClass("is-drag-selecting");
  }

  private cellPositionFromPoint(clientX: number, clientY: number): { rowIndex: number; columnIndex: number } | null {
    const target = this.rootEl.doc.elementFromPoint(clientX, clientY);
    const cell = target instanceof HTMLElement ? target.closest(".mt-grid-cell") : null;
    if (cell instanceof HTMLElement && this.rootEl.contains(cell)) {
      const rowIndex = Number(cell.dataset.row);
      const columnIndex = Number(cell.dataset.column);
      if (Number.isFinite(rowIndex) && Number.isFinite(columnIndex)) return { rowIndex, columnIndex };
    }

    const rowIndex = this.rowIndexFromClientY(clientY);
    const columnIndex = this.columnIndexFromClientX(clientX);
    if (rowIndex === null || columnIndex === null) return null;
    return { rowIndex, columnIndex };
  }

  private handleCopy(event: ClipboardEvent): void {
    if (isEditorElement(event.target)) return;

    const range = this.normalizedSelectionRange();
    if (!range) return;

    event.clipboardData?.setData("text/plain", this.selectionToTsv(range));
    event.preventDefault();
    const rows = range.rowEnd - range.rowStart + 1;
    const columns = range.columnEnd - range.columnStart + 1;
    this.setStatus(`已复制 ${rows * columns} 个单元格`, "saved");
  }

  private async handlePaste(event: ClipboardEvent): Promise<void> {
    if (isEditorElement(event.target)) return;

    const active = this.activeTarget();
    const text = event.clipboardData?.getData("text/plain") ?? "";
    if (!active || text === "") return;

    event.preventDefault();
    const matrix = parseClipboardTable(text);
    const targets = this.pasteTargets(active, matrix);
    if (targets.length > 1000) {
      const message = "单次粘贴最多支持 1000 个单元格";
      this.setStatus(message, "error");
      new Notice(message, 4000);
      return;
    }
    let pasted = 0;
    let skipped = 0;
    const failures: string[] = [];
    const writes: Promise<void>[] = [];

    for (const target of targets) {
      if (!target.cellTarget) {
        skipped += 1;
        continue;
      }
      if (!target.cellTarget.adapted.editable) {
        skipped += 1;
        continue;
      }

      try {
        const nextValue = parseEditorValue(
          target.cellTarget.state.editor,
          target.raw,
          target.cellTarget.column.fieldConfig
        );
        const cell = this.cellElementFor(target.cellTarget.entry.file.path, target.cellTarget.column.id);
        writes.push(
          this.commit(
            cell,
            target.cellTarget.entry.file,
            target.cellTarget.column,
            target.cellTarget.state.primitive,
            nextValue,
            target.cellTarget.state.editor
          )
        );
        pasted += 1;
      } catch (error) {
        failures.push(`${target.cellTarget.column.label}: ${errorMessage(error)}`);
      }
    }

    if (writes.length > 0) {
      await Promise.allSettled(writes);
      const lastTarget = lastCellTarget(targets);
      if (lastTarget) this.focusCell(lastTarget.rowIndex, lastTarget.columnIndex, true);
    }

    if (failures.length > 0) {
      const message = `粘贴完成：${pasted} 个成功，${failures.length} 个失败`;
      this.setStatus(message, "error");
      new Notice(`${message}\n${failures.slice(0, 3).join("\n")}`, 6000);
    } else {
      const suffix = skipped > 0 ? `，跳过 ${skipped} 个只读/越界单元格` : "";
      this.setStatus(`已粘贴 ${pasted} 个单元格${suffix}`, "saved");
    }
  }

  private handleGridKeydown(event: KeyboardEvent): void {
    if (!(event.target instanceof HTMLElement) || !event.target.hasClass("mt-grid-cell")) return;
    if (event.target.hasClass("is-editing")) return;
    const row = Number(event.target.dataset.row);
    const column = Number(event.target.dataset.column);
    const target = this.cellTargetAt(row, column);
    let nextRow = row;
    let nextColumn = column;

    if ((event.key === "Enter" || event.key === "F2") && target?.adapted.editable) {
      event.preventDefault();
      this.beginEdit(
        event.target,
        target.entry.file,
        target.column,
        target.state.primitive,
        target.state.display,
        target.state.editor
      );
      return;
    }

    if (event.key === "Tab") {
      event.preventDefault();
      this.focusAdjacentCell(event.target, event.shiftKey ? -1 : 1);
      return;
    }

    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "a") {
      event.preventDefault();
      this.selectAllCells();
      return;
    }

    if (event.key === "Delete" || event.key === "Backspace") {
      event.preventDefault();
      void this.clearSelectedCells();
      return;
    }

    if (event.key === " " && target?.adapted.editable && target.state.editor === "boolean") {
      event.preventDefault();
      void this.commit(
        event.target,
        target.entry.file,
        target.column,
        target.state.primitive,
        target.state.primitive !== true,
        "boolean"
      );
      return;
    }

    if (isPrintableEditKey(event) && target?.adapted.editable && target.state.editor !== "boolean") {
      event.preventDefault();
      this.beginEdit(
        event.target,
        target.entry.file,
        target.column,
        target.state.primitive,
        target.state.display,
        target.state.editor,
        { initialText: event.key }
      );
      return;
    }

    if (event.key === "ArrowUp") nextRow -= 1;
    else if (event.key === "ArrowDown") nextRow += 1;
    else if (event.key === "ArrowLeft") nextColumn -= 1;
    else if (event.key === "ArrowRight") nextColumn += 1;
    else return;

    event.preventDefault();
    this.focusCell(nextRow, nextColumn, event.shiftKey);
  }

  private focusCell(rowIndex: number, columnIndex: number, extendSelection = false): void {
    const safeRow = Math.max(0, Math.min(this.entries.length - 1, rowIndex));
    const safeColumn = Math.max(0, Math.min(this.columns.length - 1, columnIndex));
    const entry = this.entries[safeRow];
    const column = this.columns[safeColumn];
    if (!entry || !column) return;

    const anchorRow = extendSelection
      ? this.selectionRange?.anchorRow ?? this.activeCell?.rowIndex ?? safeRow
      : safeRow;
    const anchorColumn = extendSelection
      ? this.selectionRange?.anchorColumn ?? this.activeCell?.columnIndex ?? safeColumn
      : safeColumn;
    this.activeCell = { path: entry.file.path, property: column.id, rowIndex: safeRow, columnIndex: safeColumn };
    this.selectionRange = {
      anchorRow,
      anchorColumn,
      focusRow: safeRow,
      focusColumn: safeColumn
    };
    const rowTop = safeRow * this.viewConfig.rowHeight;
    const rowBottom = rowTop + this.viewConfig.rowHeight;
    const visibleTop = this.scrollerEl.scrollTop;
    const visibleBottom = visibleTop + this.scrollerEl.clientHeight;
    if (rowTop < visibleTop) this.scrollerEl.scrollTop = rowTop;
    if (rowBottom > visibleBottom) this.scrollerEl.scrollTop = rowBottom - this.scrollerEl.clientHeight + 40;
    this.lastWindowKey = "";
    this.scheduleRows(true);
    this.rootEl.win.requestAnimationFrame(() => {
      const selector = `.mt-grid-cell[data-path="${cssEscape(entry.file.path)}"][data-property="${cssEscape(column.id)}"]`;
      const cell = this.rootEl.querySelector(selector) as HTMLElement | null;
      if (cell) this.activateCell(cell, entry.file.path, column.id, safeRow, safeColumn, extendSelection);
    });
  }

  private focusAdjacentCell(cell: HTMLElement, direction: -1 | 1): void {
    const row = Number(cell.dataset.row);
    const column = Number(cell.dataset.column);
    if (!Number.isFinite(row) || !Number.isFinite(column)) return;

    let nextRow = row;
    let nextColumn = column + direction;
    if (nextColumn >= this.columns.length) {
      nextColumn = 0;
      nextRow += 1;
    } else if (nextColumn < 0) {
      nextColumn = this.columns.length - 1;
      nextRow -= 1;
    }
    this.focusCell(nextRow, nextColumn);
  }

  private moveAfterCommit(cell: HTMLElement, direction: "down" | "right" | "left" | "none"): void {
    if (direction === "none") return;
    if (direction === "right") {
      this.focusAdjacentCell(cell, 1);
      return;
    }
    if (direction === "left") {
      this.focusAdjacentCell(cell, -1);
      return;
    }

    const row = Number(cell.dataset.row);
    const column = Number(cell.dataset.column);
    if (Number.isFinite(row) && Number.isFinite(column)) this.focusCell(row + 1, column);
  }

  private activeTarget(): CellTarget | null {
    if (!this.activeCell) return null;
    return this.cellTargetAt(this.activeCell.rowIndex, this.activeCell.columnIndex);
  }

  private normalizedSelectionRange(): NormalizedSelectionRange | null {
    if (this.entries.length === 0 || this.columns.length === 0) return null;
    const range =
      this.selectionRange ??
      (this.activeCell
        ? {
            anchorRow: this.activeCell.rowIndex,
            anchorColumn: this.activeCell.columnIndex,
            focusRow: this.activeCell.rowIndex,
            focusColumn: this.activeCell.columnIndex
          }
        : null);
    if (!range) return null;

    const rowStart = clamp(Math.min(range.anchorRow, range.focusRow), 0, this.entries.length - 1);
    const rowEnd = clamp(Math.max(range.anchorRow, range.focusRow), 0, this.entries.length - 1);
    const columnStart = clamp(Math.min(range.anchorColumn, range.focusColumn), 0, this.columns.length - 1);
    const columnEnd = clamp(Math.max(range.anchorColumn, range.focusColumn), 0, this.columns.length - 1);
    return { rowStart, rowEnd, columnStart, columnEnd };
  }

  private isCellSelected(rowIndex: number, columnIndex: number): boolean {
    const range = this.normalizedSelectionRange();
    if (!range) return false;
    return (
      rowIndex >= range.rowStart &&
      rowIndex <= range.rowEnd &&
      columnIndex >= range.columnStart &&
      columnIndex <= range.columnEnd
    );
  }

  private updateSelectionEdgeClasses(cell: HTMLElement, rowIndex: number, columnIndex: number): void {
    const range = this.normalizedSelectionRange();
    const selected =
      !!range &&
      rowIndex >= range.rowStart &&
      rowIndex <= range.rowEnd &&
      columnIndex >= range.columnStart &&
      columnIndex <= range.columnEnd;

    cell.classList.toggle("is-selection-top", selected && rowIndex === range?.rowStart);
    cell.classList.toggle("is-selection-bottom", selected && rowIndex === range?.rowEnd);
    cell.classList.toggle("is-selection-left", selected && columnIndex === range?.columnStart);
    cell.classList.toggle("is-selection-right", selected && columnIndex === range?.columnEnd);
  }

  private isRowSelected(rowIndex: number): boolean {
    const range = this.normalizedSelectionRange();
    if (!range) return false;
    return (
      rowIndex >= range.rowStart &&
      rowIndex <= range.rowEnd &&
      range.columnStart === 0 &&
      range.columnEnd === this.columns.length - 1
    );
  }

  private isColumnSelected(columnIndex: number): boolean {
    const range = this.normalizedSelectionRange();
    if (!range) return false;
    return (
      columnIndex >= range.columnStart &&
      columnIndex <= range.columnEnd &&
      range.rowStart === 0 &&
      range.rowEnd === this.entries.length - 1
    );
  }

  private updateRenderedSelectionState(): void {
    this.rootEl.querySelectorAll(".mt-grid-cell").forEach((element) => {
      const cell = element as HTMLElement;
      const rowIndex = Number(cell.dataset.row);
      const columnIndex = Number(cell.dataset.column);
      const active =
        this.activeCell?.rowIndex === rowIndex && this.activeCell?.columnIndex === columnIndex;
      cell.classList.toggle("is-active", active);
      cell.classList.toggle("is-selected", this.isCellSelected(rowIndex, columnIndex));
      this.updateSelectionEdgeClasses(cell, rowIndex, columnIndex);
      cell.tabIndex = active ? 0 : -1;
    });
    this.rootEl.querySelectorAll(".mt-grid-row__index").forEach((element) => {
      const rowIndex = Number((element as HTMLElement).dataset.row);
      element.classList.toggle("is-selected", this.isRowSelected(rowIndex));
    });
    this.rootEl.querySelectorAll(".mt-grid-header__cell").forEach((element) => {
      const columnIndex = Number((element as HTMLElement).dataset.column);
      element.classList.toggle("is-selected", this.isColumnSelected(columnIndex));
    });
  }

  private selectionToTsv(range: NormalizedSelectionRange): string {
    const rows: string[] = [];
    for (let rowIndex = range.rowStart; rowIndex <= range.rowEnd; rowIndex += 1) {
      const cells: string[] = [];
      for (let columnIndex = range.columnStart; columnIndex <= range.columnEnd; columnIndex += 1) {
        cells.push(this.cellTargetAt(rowIndex, columnIndex)?.state.display ?? "");
      }
      rows.push(cells.join("\t"));
    }
    return rows.join("\n");
  }

  private pasteTargets(active: CellTarget, matrix: string[][]): PasteTarget[] {
    const range = this.normalizedSelectionRange();
    const isSingleCellPaste = matrix.length === 1 && (matrix[0]?.length ?? 0) === 1;
    if (isSingleCellPaste && range && rangeCellCount(range) > 1) {
      const raw = matrix[0]?.[0] ?? "";
      const targets: PasteTarget[] = [];
      for (let rowIndex = range.rowStart; rowIndex <= range.rowEnd; rowIndex += 1) {
        for (let columnIndex = range.columnStart; columnIndex <= range.columnEnd; columnIndex += 1) {
          targets.push({ cellTarget: this.cellTargetAt(rowIndex, columnIndex), raw });
        }
      }
      return targets;
    }

    const targets: PasteTarget[] = [];
    matrix.forEach((row, rowOffset) => {
      row.forEach((raw, columnOffset) => {
        targets.push({
          cellTarget: this.cellTargetAt(active.rowIndex + rowOffset, active.columnIndex + columnOffset),
          raw
        });
      });
    });
    return targets;
  }

  private selectAllCells(): void {
    if (!this.activeCell || this.entries.length === 0 || this.columns.length === 0) return;
    this.selectionRange = {
      anchorRow: 0,
      anchorColumn: 0,
      focusRow: this.entries.length - 1,
      focusColumn: this.columns.length - 1
    };
    this.updateRenderedSelectionState();
    this.setStatus(`已选择 ${this.entries.length * this.columns.length} 个单元格`, "saved");
  }

  private rowIndexFromClientY(clientY: number): number | null {
    if (this.entries.length === 0) return null;
    const scrollerRect = this.scrollerEl.getBoundingClientRect();
    const headerHeight = this.headerEl.getBoundingClientRect().height || 34;
    const y = clientY - scrollerRect.top + this.scrollerEl.scrollTop - headerHeight;
    return clamp(Math.floor(Math.max(0, y) / this.viewConfig.rowHeight), 0, this.entries.length - 1);
  }

  private columnIndexFromClientX(clientX: number): number | null {
    if (this.columns.length === 0) return null;
    const scrollerRect = this.scrollerEl.getBoundingClientRect();
    const rowIndexWidth = 40;
    const frozenCount = Math.min(this.viewConfig.frozenColumns, this.columns.length);
    let frozenLeft = scrollerRect.left + rowIndexWidth;
    for (let columnIndex = 0; columnIndex < frozenCount; columnIndex += 1) {
      const width = this.columns[columnIndex]?.width ?? 0;
      if (clientX >= frozenLeft && clientX < frozenLeft + width) return columnIndex;
      frozenLeft += width;
    }

    let x = clientX - scrollerRect.left + this.scrollerEl.scrollLeft - 40;
    if (x < 0) return 0;

    for (let columnIndex = 0; columnIndex < this.columns.length; columnIndex += 1) {
      const width = this.columns[columnIndex]?.width ?? 0;
      if (x < width) return columnIndex;
      x -= width;
    }
    return this.columns.length - 1;
  }

  private selectRow(rowIndex: number, extendSelection = false): void {
    if (this.entries.length === 0 || this.columns.length === 0) return;
    const safeRow = clamp(rowIndex, 0, this.entries.length - 1);
    const anchorRow = extendSelection
      ? this.selectionRange?.anchorRow ?? this.activeCell?.rowIndex ?? safeRow
      : safeRow;
    const entry = this.entries[safeRow];
    const column = this.columns[0];
    if (!entry || !column) return;

    this.activeCell = { path: entry.file.path, property: column.id, rowIndex: safeRow, columnIndex: 0 };
    this.selectionRange = {
      anchorRow,
      anchorColumn: 0,
      focusRow: safeRow,
      focusColumn: this.columns.length - 1
    };
    this.updateRenderedSelectionState();
    this.focusRenderedActiveCell();
  }

  private selectColumn(columnIndex: number, extendSelection = false): void {
    if (this.entries.length === 0 || this.columns.length === 0) return;
    const safeColumn = clamp(columnIndex, 0, this.columns.length - 1);
    const anchorColumn = extendSelection
      ? this.selectionRange?.anchorColumn ?? this.activeCell?.columnIndex ?? safeColumn
      : safeColumn;
    const entry = this.entries[0];
    const column = this.columns[safeColumn];
    if (!entry || !column) return;

    this.activeCell = { path: entry.file.path, property: column.id, rowIndex: 0, columnIndex: safeColumn };
    this.selectionRange = {
      anchorRow: 0,
      anchorColumn,
      focusRow: this.entries.length - 1,
      focusColumn: safeColumn
    };
    this.updateRenderedSelectionState();
    this.focusRenderedActiveCell();
  }

  private focusRenderedActiveCell(): void {
    if (!this.activeCell) return;
    const cell = this.cellElementFor(this.activeCell.path, this.activeCell.property);
    if (cell) cell.focus({ preventScroll: true });
  }

  private cellTargetAt(rowIndex: number, columnIndex: number): CellTarget | null {
    if (rowIndex < 0 || columnIndex < 0) return null;
    const entry = this.entries[rowIndex];
    const column = this.columns[columnIndex];
    if (!entry || !column) return null;

    const adapted = adaptValue(column.id, entry.getValue(column.id), column.fieldConfig);
    return {
      entry,
      column,
      adapted,
      state: this.getCellState(entry.file.path, column.id, adapted),
      rowIndex,
      columnIndex
    };
  }

  private cellElementFor(path: string, property: BasesPropertyId): HTMLElement | null {
    const selector = `.mt-grid-cell[data-path="${cssEscape(path)}"][data-property="${cssEscape(property)}"]`;
    return this.rootEl.querySelector(selector) as HTMLElement | null;
  }

  private copySelectionToClipboard(): void {
    const range = this.normalizedSelectionRange();
    if (!range) {
      this.setStatus("没有选中的单元格", "error");
      return;
    }
    const text = this.selectionToTsv(range);
    void navigator.clipboard.writeText(text).then(() => {
      this.setStatus(`已复制 ${rangeCellCount(range)} 个单元格`, "saved");
    }).catch(() => {
      this.setStatus("复制失败，请使用 Ctrl+C", "error");
    });
  }

  private async clearSelectedCells(): Promise<void> {
    const range = this.normalizedSelectionRange();
    if (!range) return;
    const cellCount = rangeCellCount(range);
    if (cellCount > 1000) {
      const message = "单次清空最多支持 1000 个单元格";
      this.setStatus(message, "error");
      new Notice(message, 4000);
      return;
    }

    let cleared = 0;
    let skipped = 0;
    const writes: Promise<void>[] = [];
    for (let rowIndex = range.rowStart; rowIndex <= range.rowEnd; rowIndex += 1) {
      for (let columnIndex = range.columnStart; columnIndex <= range.columnEnd; columnIndex += 1) {
        const target = this.cellTargetAt(rowIndex, columnIndex);
        if (!target) {
          skipped += 1;
          continue;
        }
        if (!target.adapted.editable) {
          skipped += 1;
          continue;
        }
        const cell = this.cellElementFor(target.entry.file.path, target.column.id);
        writes.push(
          this.commit(
            cell,
            target.entry.file,
            target.column,
            target.state.primitive,
            undefined,
            target.state.editor
          )
        );
        cleared += 1;
      }
    }

    if (writes.length > 0) await Promise.allSettled(writes);
    const suffix = skipped > 0 ? `，跳过 ${skipped} 个只读/越界单元格` : "";
    this.setStatus(`已清空 ${cleared} 个单元格${suffix}`, "saved");
  }

  private openColumnMenu(anchor: HTMLElement, column: GridColumn): void {
    const menu = new Menu();
    menu.addItem((item) => {
      item.setTitle("自动调整列宽").setIcon("scan-text").onClick(() => this.autoFitColumn(column));
    });
    menu.addItem((item) => {
      item.setTitle("隐藏列").setIcon("eye-off").onClick(() => this.hideColumn(column.id));
    });
    if (this.hiddenProperties().length > 0) {
      menu.addItem((item) => {
        item.setTitle("显示所有列").setIcon("eye").onClick(() => this.showAllColumns());
      });
    }
    const rect = anchor.getBoundingClientRect();
    menu.showAtPosition({ x: rect.left, y: rect.bottom });
  }

  private openTableColumnsMenu(anchor: HTMLElement): void {
    const menu = new Menu();
    menu.addItem((item) => {
      item.setTitle("显示所有列").setIcon("eye").onClick(() => this.showAllColumns());
      item.setDisabled(this.hiddenProperties().length === 0);
    });
    menu.addItem((item) => {
      item.setTitle("自动调整所有列宽").setIcon("scan-text").onClick(() => this.autoFitAllColumns());
      item.setDisabled(this.columns.length === 0);
    });
    if (this.columns.length > 0) {
      menu.addSeparator();
      for (const column of this.columns) {
        menu.addItem((item) => {
          item.setTitle(`隐藏：${column.label}`).setIcon("eye-off").onClick(() => this.hideColumn(column.id));
        });
      }
    }
    const rect = anchor.getBoundingClientRect();
    menu.showAtPosition({ x: rect.left, y: rect.bottom });
  }

  private hideColumn(property: BasesPropertyId): void {
    this.viewConfig = {
      ...this.viewConfig,
      columns: {
        ...this.viewConfig.columns,
        [property]: { ...(this.viewConfig.columns[property] ?? {}), hidden: true }
      }
    };
    writeDuoweiConfig(this.config, this.viewConfig);
    this.columns = this.columns.filter((column) => column.id !== property);
    if (this.activeCell?.property === property) {
      this.activeCell = null;
      this.selectionRange = null;
    }
    this.renderHeader();
    this.refreshLayout(true);
    this.setStatus("已隐藏列", "saved");
  }

  private showAllColumns(): void {
    const columns = { ...this.viewConfig.columns };
    for (const property of Object.keys(columns) as BasesPropertyId[]) {
      columns[property] = { ...(columns[property] ?? {}), hidden: false };
    }
    this.viewConfig = { ...this.viewConfig, columns };
    writeDuoweiConfig(this.config, this.viewConfig);
    this.columns = this.allColumnProperties.map((property, index) => ({
      id: property,
      label: this.getPropertyLabel(property),
      width: this.getColumnWidth(property, index),
      fieldConfig: this.viewConfig.fields[property]
    }));
    this.renderHeader();
    this.refreshLayout(true);
    this.setStatus("已显示所有列", "saved");
  }

  private hiddenProperties(): BasesPropertyId[] {
    return this.allColumnProperties.filter((property) => this.viewConfig.columns[property]?.hidden === true);
  }

  private autoFitColumn(column: GridColumn): void {
    this.setAutoFitColumnWidth(column);
    this.viewConfig = {
      ...this.viewConfig,
      columns: {
        ...this.viewConfig.columns,
        [column.id]: { ...(this.viewConfig.columns[column.id] ?? {}), width: column.width }
      }
    };
    writeDuoweiConfig(this.config, this.viewConfig);
    this.renderHeader();
    this.refreshLayout(true);
    this.setStatus("已自动调整列宽", "saved");
  }

  private autoFitAllColumns(): void {
    if (this.columns.length === 0) return;
    for (const column of this.columns) {
      this.setAutoFitColumnWidth(column);
    }
    const columns = { ...this.viewConfig.columns };
    for (const column of this.columns) {
      columns[column.id] = { ...(columns[column.id] ?? {}), width: Math.round(column.width) };
    }
    this.viewConfig = { ...this.viewConfig, columns };
    writeDuoweiConfig(this.config, this.viewConfig);
    this.renderHeader();
    this.refreshLayout(true);
    this.setStatus("已自动调整所有列宽", "saved");
  }

  private setAutoFitColumnWidth(column: GridColumn): void {
    const sampleCount = Math.min(this.entries.length, 80);
    let maxLength = Math.max(displayWidth(column.label), 4);
    for (let rowIndex = 0; rowIndex < sampleCount; rowIndex += 1) {
      const entry = this.entries[rowIndex];
      if (!entry) continue;
      const adapted = adaptValue(column.id, entry.getValue(column.id), column.fieldConfig);
      maxLength = Math.max(maxLength, displayWidth(adapted.display));
    }
    column.width = Math.max(72, Math.min(420, Math.round(maxLength * 8 + 34)));
  }

  private beginColumnDrag(event: PointerEvent, sourceIndex: number): void {
    if (event.button !== 0) return;
    const header = event.currentTarget;
    if (!(header instanceof HTMLElement)) return;
    event.preventDefault();
    this.columnDrag = { pointerId: event.pointerId, sourceIndex, targetIndex: sourceIndex };
    this.suppressNextHeaderClick = false;
    this.headerEl.addClass("is-column-dragging");
    header.setPointerCapture(event.pointerId);

    const onPointerMove = (moveEvent: PointerEvent) => this.updateColumnDragFromPoint(moveEvent);
    const onPointerEnd = (endEvent: PointerEvent) => {
      if (endEvent.pointerId !== this.columnDrag?.pointerId) return;
      header.removeEventListener("pointermove", onPointerMove);
      header.removeEventListener("pointerup", onPointerEnd);
      header.removeEventListener("pointercancel", onPointerEnd);
      if (header.hasPointerCapture(endEvent.pointerId)) header.releasePointerCapture(endEvent.pointerId);
      this.finishColumnDrag();
    };
    header.addEventListener("pointermove", onPointerMove);
    header.addEventListener("pointerup", onPointerEnd);
    header.addEventListener("pointercancel", onPointerEnd);
  }

  private updateColumnDragTarget(event: PointerEvent, targetIndex: number): void {
    if (!this.columnDrag || event.pointerId !== this.columnDrag.pointerId) return;
    this.setColumnDragTarget(targetIndex);
  }

  private updateColumnDragFromPoint(event: PointerEvent): void {
    if (!this.columnDrag || event.pointerId !== this.columnDrag.pointerId) return;
    const targetIndex = this.columnIndexFromClientX(event.clientX);
    if (targetIndex !== null) this.setColumnDragTarget(targetIndex);
  }

  private setColumnDragTarget(targetIndex: number): void {
    if (!this.columnDrag) return;
    const safeTarget = clamp(targetIndex, 0, this.columns.length - 1);
    if (this.columnDrag.targetIndex === safeTarget) return;
    this.columnDrag.targetIndex = safeTarget;
    this.rootEl.querySelectorAll(".mt-grid-header__cell").forEach((element) => {
      const header = element as HTMLElement;
      const columnIndex = Number(header.dataset.column);
      header.classList.toggle("is-drop-target", columnIndex === safeTarget);
    });
  }

  private finishColumnDrag(): void {
    const drag = this.columnDrag;
    this.columnDrag = null;
    this.headerEl.removeClass("is-column-dragging");
    this.rootEl.querySelectorAll(".mt-grid-header__cell.is-drop-target").forEach((element) => {
      element.removeClass("is-drop-target");
    });
    if (!drag || drag.sourceIndex === drag.targetIndex) return;
    this.suppressNextHeaderClick = true;

    const visibleOrder = this.columns.map((column) => column.id);
    const moved = visibleOrder.splice(drag.sourceIndex, 1)[0];
    if (!moved) return;
    visibleOrder.splice(drag.targetIndex, 0, moved);
    this.persistVisibleColumnOrder(visibleOrder);
    this.columns = this.applyColumnOrder(this.columns.map((column) => column.id)).map((property, index) => ({
      id: property,
      label: this.getPropertyLabel(property),
      width: this.getColumnWidth(property, index),
      fieldConfig: this.viewConfig.fields[property]
    }));
    this.renderHeader();
    this.refreshLayout(true);
    this.setStatus("已调整列顺序", "saved");
  }

  private beginResize(event: PointerEvent, column: GridColumn): void {
    event.preventDefault();
    event.stopPropagation();
    const startX = event.clientX;
    const startWidth = column.width;
    const doc = this.rootEl.doc;

    const move = (moveEvent: PointerEvent) => {
      column.width = Math.max(72, Math.min(640, startWidth + moveEvent.clientX - startX));
      this.renderHeader();
      this.refreshLayout(true);
    };
    const end = () => {
      doc.removeEventListener("pointermove", move);
      doc.removeEventListener("pointerup", end);
      this.viewConfig = {
        ...this.viewConfig,
        columns: {
          ...this.viewConfig.columns,
          [column.id]: { ...(this.viewConfig.columns[column.id] ?? {}), width: Math.round(column.width) }
        }
      };
      writeDuoweiConfig(this.config, this.viewConfig);
    };
    doc.addEventListener("pointermove", move);
    doc.addEventListener("pointerup", end, { once: true });
  }

  private createToolButton(
    parent: HTMLElement,
    icon: string,
    label: string,
    onClick: (event: MouseEvent) => void
  ): HTMLButtonElement {
    const button = parent.createEl("button", {
      cls: "clickable-icon mt-command-button mt-tool-button",
      attr: { type: "button", "aria-label": label, title: label }
    });
    setIcon(button.createSpan({ cls: "mt-command-button__icon", attr: { "aria-hidden": "true" } }), icon);
    button.createSpan({ cls: "mt-command-button__label", text: label });
    const badge = button.createSpan({ cls: "mt-command-button__badge is-hidden" });
    badge.setText("");
    setIcon(button.createSpan({ cls: "mt-command-button__caret", attr: { "aria-hidden": "true" } }), "chevron-down");
    button.addEventListener("click", onClick);
    return button;
  }

  private setToolBadge(button: HTMLButtonElement, count: number): void {
    const badge = button.querySelector(".mt-command-button__badge") as HTMLElement | null;
    button.classList.toggle("is-active", count > 0);
    if (!badge) return;
    badge.classList.toggle("is-hidden", count === 0);
    badge.setText(count > 0 ? String(count) : "");
  }

  private updateToolBadges(): void {
    this.setToolBadge(this.filterButtonEl, this.filters.length);
    this.setToolBadge(this.sortButtonEl, this.sorts.length);
  }

  private toggleSearch(): void {
    const collapsed = this.searchWrapEl.hasClass("is-collapsed");
    if (collapsed) {
      this.searchWrapEl.removeClass("is-collapsed");
      this.searchInputEl.focus();
    } else if (!this.searchInputEl.value.trim()) {
      this.searchWrapEl.addClass("is-collapsed");
    } else {
      this.searchInputEl.focus();
    }
  }

  private updateDensityLabel(): void {
    const labels = { compact: "紧凑", default: "标准", comfortable: "舒适" } as const;
    const label = `行密度：${labels[this.viewConfig.density]}`;
    this.densityButtonEl.setAttr("aria-label", label);
    this.densityButtonEl.setAttr("title", label);
  }

  private recomputeEntries(refresh = true): void {
    let result = this.allEntries;

    if (this.filters.length > 0) {
      result = result.filter((entry) => this.filters.every((rule) => this.matchesFilter(entry, rule)));
    }

    const query = this.quickSearch;
    if (query) {
      result = result.filter((entry) => {
        if (entry.file.basename.toLowerCase().includes(query) || entry.file.path.toLowerCase().includes(query)) {
          return true;
        }
        return this.columns.some((column) => {
          const adapted = adaptValue(column.id, entry.getValue(column.id), column.fieldConfig);
          return adapted.display.toLowerCase().includes(query);
        });
      });
    }

    if (this.sorts.length > 0) {
      result = [...result].sort((left, right) => this.compareForSort(left, right));
    }

    this.entries = result;

    if (!refresh) return;
    this.syncActiveCellIndexes();
    this.updateCountLabel();
    this.scrollerEl.scrollTop = 0;
    this.refreshLayout(true);
  }

  private displayFor(entry: BasesEntry, property: BasesPropertyId): { display: string; primitive: unknown } {
    const fieldConfig = this.viewConfig.fields[property];
    const adapted = adaptValue(property, entry.getValue(property), fieldConfig);
    const state = this.getCellState(entry.file.path, property, adapted);
    return { display: state.display ?? "", primitive: state.primitive };
  }

  private matchesFilter(entry: BasesEntry, rule: FilterRule): boolean {
    const { display, primitive } = this.displayFor(entry, rule.property);
    const haystack = display.toLowerCase();
    const needle = rule.value.trim().toLowerCase();
    switch (rule.op) {
      case "empty":
        return display.trim() === "";
      case "notEmpty":
        return display.trim() !== "";
      case "contains":
        return needle === "" || haystack.includes(needle);
      case "equals":
        return haystack === needle;
      case "notEquals":
        return haystack !== needle;
      case "gt":
        return Number(primitive) > Number(rule.value);
      case "lt":
        return Number(primitive) < Number(rule.value);
      default:
        return true;
    }
  }

  private compareForSort(left: BasesEntry, right: BasesEntry): number {
    for (const rule of this.sorts) {
      const a = this.displayFor(left, rule.property);
      const b = this.displayFor(right, rule.property);
      let cmp: number;
      const numA = Number(a.primitive);
      const numB = Number(b.primitive);
      if (a.primitive !== undefined && b.primitive !== undefined && Number.isFinite(numA) && Number.isFinite(numB)) {
        cmp = numA - numB;
      } else {
        const sa = a.display;
        const sb = b.display;
        if (sa === "" && sb !== "") cmp = 1;
        else if (sb === "" && sa !== "") cmp = -1;
        else cmp = sa.localeCompare(sb, "zh-Hans-CN");
      }
      if (cmp !== 0) return rule.direction === "desc" ? -cmp : cmp;
    }
    return 0;
  }

  private pruneObsoleteRules(): void {
    const known = new Set(this.allColumnProperties);
    this.filters = this.filters.filter((rule) => known.has(rule.property));
    this.sorts = this.sorts.filter((rule) => known.has(rule.property));
  }

  private filterableColumns(): GridColumn[] {
    return this.columns;
  }

  private openDensityMenu(anchor: HTMLElement): void {
    const menu = new Menu();
    const options: { value: DuoweiViewConfig["density"]; label: string }[] = [
      { value: "compact", label: "紧凑" },
      { value: "default", label: "标准" },
      { value: "comfortable", label: "舒适" }
    ];
    for (const option of options) {
      menu.addItem((item) => {
        item.setTitle(option.label).setChecked(this.viewConfig.density === option.value);
        item.onClick(() => {
          this.viewConfig = setDensity(this.viewConfig, option.value);
          writeDuoweiConfig(this.config, this.viewConfig);
          this.updateDensityLabel();
          this.refreshLayout(true);
        });
      });
    }
    const rect = anchor.getBoundingClientRect();
    menu.showAtPosition({ x: rect.left, y: rect.bottom + 4 });
  }

  private openOverflowMenu(anchor: HTMLElement): void {
    const menu = new Menu();
    const hasSelection = this.normalizedSelectionRange() !== null;
    menu.addItem((item) => {
      item.setTitle("复制选区").setIcon("copy").setDisabled(!hasSelection);
      item.onClick(() => this.copySelectionToClipboard());
    });
    menu.addItem((item) => {
      item.setTitle("清空选区").setIcon("eraser").setDisabled(!hasSelection);
      item.onClick(() => void this.clearSelectedCells());
    });
    menu.addSeparator();
    menu.addItem((item) => {
      item.setTitle("自动调整所有列宽").setIcon("scan-text").setDisabled(this.columns.length === 0);
      item.onClick(() => this.autoFitAllColumns());
    });
    menu.addItem((item) => {
      item.setTitle("显示所有列").setIcon("eye").setDisabled(this.hiddenProperties().length === 0);
      item.onClick(() => this.showAllColumns());
    });
    if (this.filters.length > 0 || this.sorts.length > 0) {
      menu.addSeparator();
      menu.addItem((item) => {
        item.setTitle("清除筛选与排序").setIcon("filter-x");
        item.onClick(() => {
          this.filters = [];
          this.sorts = [];
          this.updateToolBadges();
          this.recomputeEntries();
        });
      });
    }
    const rect = anchor.getBoundingClientRect();
    menu.showAtPosition({ x: rect.right, y: rect.bottom + 4 });
  }

  private openCellContextMenu(event: MouseEvent): void {
    const target = (event.target as HTMLElement)?.closest(".mt-grid-cell") as HTMLElement | null;
    if (!target) return;
    event.preventDefault();
    const rowIndex = Number(target.dataset.row);
    const columnIndex = Number(target.dataset.column);
    if (Number.isFinite(rowIndex) && Number.isFinite(columnIndex) && !this.isCellSelected(rowIndex, columnIndex)) {
      const cellTarget = this.cellTargetAt(rowIndex, columnIndex);
      if (cellTarget) {
        this.activateCell(target, cellTarget.entry.file.path, cellTarget.column.id, rowIndex, columnIndex);
      }
    }
    const entry = this.entries[rowIndex];
    const hasSelection = this.normalizedSelectionRange() !== null;
    const menu = new Menu();
    menu.addItem((item) => {
      item.setTitle("展开记录").setIcon("maximize-2").setDisabled(!entry);
      item.onClick(() => this.openRecordCard(rowIndex));
    });
    menu.addSeparator();
    menu.addItem((item) => {
      item.setTitle("复制").setIcon("copy").setDisabled(!hasSelection);
      item.onClick(() => this.copySelectionToClipboard());
    });
    menu.addItem((item) => {
      item.setTitle("清空内容").setIcon("eraser").setDisabled(!hasSelection);
      item.onClick(() => void this.clearSelectedCells());
    });
    menu.addSeparator();
    menu.addItem((item) => {
      item.setTitle("删除记录").setIcon("trash-2").setWarning(true).setDisabled(!entry);
      item.onClick(() => {
        if (entry) void this.deleteRecord(entry);
      });
    });
    menu.showAtMouseEvent(event);
  }

  private async deleteRecord(entry: BasesEntry): Promise<void> {
    try {
      await this.app.fileManager.trashFile(entry.file);
      this.setStatus("已删除记录", "saved");
    } catch (error) {
      const message = errorMessage(error);
      this.setStatus(message, "error");
      new Notice(message, 4000);
    }
  }

  private openFilterPanel(anchor: HTMLElement): void {
    const columns = this.filterableColumns();
    const draft: FilterRule[] = this.filters.map((rule) => ({ ...rule }));
    const opLabels: Record<FilterOp, string> = {
      contains: "包含",
      equals: "等于",
      notEquals: "不等于",
      empty: "为空",
      notEmpty: "不为空",
      gt: "大于",
      lt: "小于"
    };

    const apply = () => {
      this.filters = draft.filter((rule) => rule.property);
      this.updateToolBadges();
      this.recomputeEntries();
    };

    const panel = this.createPanel(anchor, "筛选");
    const list = panel.body.createDiv({ cls: "mt-panel__list" });

    const renderList = () => {
      list.empty();
      if (draft.length === 0) {
        list.createDiv({ cls: "mt-panel__empty", text: "暂无筛选条件" });
      }
      draft.forEach((rule, index) => {
        const row = list.createDiv({ cls: "mt-panel__rule" });
        row.createSpan({ cls: "mt-panel__rule-prefix", text: index === 0 ? "当" : "且" });
        const propSelect = row.createEl("select", { cls: "mt-panel__select" });
        for (const column of columns) {
          const option = propSelect.createEl("option", { value: column.id, text: column.label });
          if (column.id === rule.property) option.selected = true;
        }
        propSelect.addEventListener("change", () => {
          rule.property = propSelect.value as BasesPropertyId;
          apply();
        });
        const opSelect = row.createEl("select", { cls: "mt-panel__select mt-panel__select--op" });
        (Object.keys(opLabels) as FilterOp[]).forEach((op) => {
          const option = opSelect.createEl("option", { value: op, text: opLabels[op] });
          if (op === rule.op) option.selected = true;
        });
        opSelect.addEventListener("change", () => {
          rule.op = opSelect.value as FilterOp;
          renderList();
          apply();
        });
        if (rule.op !== "empty" && rule.op !== "notEmpty") {
          const input = row.createEl("input", { cls: "mt-panel__input", type: "text", value: rule.value });
          input.placeholder = "值";
          input.addEventListener("input", () => {
            rule.value = input.value;
            apply();
          });
        }
        const remove = row.createEl("button", {
          cls: "clickable-icon mt-panel__remove",
          attr: { type: "button", "aria-label": "删除条件" }
        });
        setIcon(remove, "x");
        remove.addEventListener("click", () => {
          draft.splice(index, 1);
          renderList();
          apply();
        });
      });
    };

    const addBtn = panel.footer.createEl("button", { cls: "mt-panel__add", attr: { type: "button" } });
    setIcon(addBtn.createSpan({ cls: "mt-panel__add-icon" }), "plus");
    addBtn.createSpan({ text: "添加条件" });
    addBtn.addEventListener("click", () => {
      const first = columns[0];
      if (!first) return;
      draft.push({ property: first.id, op: "contains", value: "" });
      renderList();
    });

    renderList();
  }

  private openSortPanel(anchor: HTMLElement): void {
    const columns = this.filterableColumns();
    const draft: SortRule[] = this.sorts.map((rule) => ({ ...rule }));

    const apply = () => {
      this.sorts = draft.filter((rule) => rule.property);
      this.updateToolBadges();
      this.recomputeEntries();
    };

    const panel = this.createPanel(anchor, "排序");
    const list = panel.body.createDiv({ cls: "mt-panel__list" });

    const renderList = () => {
      list.empty();
      if (draft.length === 0) {
        list.createDiv({ cls: "mt-panel__empty", text: "暂无排序规则" });
      }
      draft.forEach((rule, index) => {
        const row = list.createDiv({ cls: "mt-panel__rule" });
        const propSelect = row.createEl("select", { cls: "mt-panel__select" });
        for (const column of columns) {
          const option = propSelect.createEl("option", { value: column.id, text: column.label });
          if (column.id === rule.property) option.selected = true;
        }
        propSelect.addEventListener("change", () => {
          rule.property = propSelect.value as BasesPropertyId;
          apply();
        });
        const dirSelect = row.createEl("select", { cls: "mt-panel__select mt-panel__select--op" });
        const asc = dirSelect.createEl("option", { value: "asc", text: "升序" });
        const desc = dirSelect.createEl("option", { value: "desc", text: "降序" });
        if (rule.direction === "asc") asc.selected = true;
        else desc.selected = true;
        dirSelect.addEventListener("change", () => {
          rule.direction = dirSelect.value as "asc" | "desc";
          apply();
        });
        const remove = row.createEl("button", {
          cls: "clickable-icon mt-panel__remove",
          attr: { type: "button", "aria-label": "删除排序" }
        });
        setIcon(remove, "x");
        remove.addEventListener("click", () => {
          draft.splice(index, 1);
          renderList();
          apply();
        });
      });
    };

    const addBtn = panel.footer.createEl("button", { cls: "mt-panel__add", attr: { type: "button" } });
    setIcon(addBtn.createSpan({ cls: "mt-panel__add-icon" }), "plus");
    addBtn.createSpan({ text: "添加排序" });
    addBtn.addEventListener("click", () => {
      const used = new Set(draft.map((rule) => rule.property));
      const next = columns.find((column) => !used.has(column.id)) ?? columns[0];
      if (!next) return;
      draft.push({ property: next.id, direction: "asc" });
      renderList();
    });

    renderList();
  }

  private createPanel(
    anchor: HTMLElement,
    title: string
  ): { root: HTMLElement; body: HTMLElement; footer: HTMLElement } {
    const root = this.rootEl.doc.body.createDiv({ cls: "mt-panel" });
    const header = root.createDiv({ cls: "mt-panel__header" });
    header.createSpan({ cls: "mt-panel__title", text: title });
    const body = root.createDiv({ cls: "mt-panel__body" });
    const footer = root.createDiv({ cls: "mt-panel__footer" });

    const rect = anchor.getBoundingClientRect();
    root.style.top = `${rect.bottom + 6}px`;
    root.style.left = `${Math.min(rect.left, this.rootEl.win.innerWidth - 360)}px`;

    let closed = false;
    const close = () => {
      if (closed) return;
      closed = true;
      this.rootEl.doc.removeEventListener("pointerdown", onOutside, true);
      root.remove();
    };
    const onOutside = (event: PointerEvent) => {
      if (!root.contains(event.target as Node)) close();
    };
    root.addEventListener("pointerdown", (event) => event.stopPropagation());
    this.rootEl.win.setTimeout(() => this.rootEl.doc.addEventListener("pointerdown", onOutside, true), 0);
    return { root, body, footer };
  }

  private updateCountLabel(): void {
    const visibleCount = this.entries.length.toLocaleString();
    const totalCount = this.allEntries.length.toLocaleString();
    this.countEl.setText(this.quickSearch ? `${visibleCount} / ${totalCount} 条记录` : `${visibleCount} 条记录`);
  }

  private setStatus(message: string, state: "saving" | "saved" | "error" | "conflict"): void {
    this.statusEl.setText(message);
    this.statusEl.dataset.state = state;
  }

  private applyRuntimeSettings(): void {
    const showSaveStatus = this.runtimeOptions.showSaveStatus();
    this.statusEl.classList.toggle("is-hidden", !showSaveStatus);
    this.statusEl.setAttr("aria-hidden", String(!showSaveStatus));
  }

  private syncActiveCellIndexes(): void {
    if (!this.activeCell) return;
    const rowIndex = this.entries.findIndex((entry) => entry.file.path === this.activeCell?.path);
    const columnIndex = this.columns.findIndex((column) => column.id === this.activeCell?.property);
    if (rowIndex < 0 || columnIndex < 0) {
      this.activeCell = null;
      this.selectionRange = null;
      return;
    }

    const rowDelta = rowIndex - this.activeCell.rowIndex;
    const columnDelta = columnIndex - this.activeCell.columnIndex;
    this.activeCell = {
      ...this.activeCell,
      rowIndex,
      columnIndex
    };
    if (this.selectionRange) {
      this.selectionRange = {
        anchorRow: this.selectionRange.anchorRow + rowDelta,
        anchorColumn: this.selectionRange.anchorColumn + columnDelta,
        focusRow: this.selectionRange.focusRow + rowDelta,
        focusColumn: this.selectionRange.focusColumn + columnDelta
      };
    }
  }

  private getCellState(path: string, property: BasesPropertyId, fallback: AdaptedValue): OptimisticCellValue {
    return (
      this.optimisticValues.get(cellKey(path, property)) ?? {
        primitive: fallback.primitive,
        display: fallback.display,
        editor: fallback.editor
      }
    );
  }

  private setOptimisticValue(path: string, property: BasesPropertyId, primitive: unknown, editor: EditorKind): void {
    this.optimisticValues.set(cellKey(path, property), {
      primitive,
      display: displayForPrimitive(editor, primitive),
      editor
    });
  }

  private reconcileOptimisticValues(): void {
    if (this.optimisticValues.size === 0) return;

    const visibleKeys = new Set<string>();
    for (const entry of this.entries) {
      for (const column of this.columns) {
        const key = cellKey(entry.file.path, column.id);
        visibleKeys.add(key);
        const optimistic = this.optimisticValues.get(key);
        if (!optimistic) continue;

        const adapted = adaptValue(column.id, entry.getValue(column.id), column.fieldConfig);
        if (sameValue(adapted.primitive, optimistic.primitive)) {
          this.optimisticValues.delete(key);
        }
      }
    }

    for (const key of this.optimisticValues.keys()) {
      if (!visibleKeys.has(key)) this.optimisticValues.delete(key);
    }
  }

  private getColumnWidth(property: BasesPropertyId, index: number): number {
    const configured = Number(this.viewConfig.columns[property]?.width);
    if (Number.isFinite(configured)) return Math.max(72, Math.min(640, configured));
    if (property === "file.name" || index === 0) return 240;
    return 180;
  }

  private applyColumnOrder(properties: BasesPropertyId[]): BasesPropertyId[] {
    const propertiesSet = new Set(properties);
    const ordered = this.viewConfig.columnOrder.filter((property) => propertiesSet.has(property));
    const orderedSet = new Set(ordered);
    return [...ordered, ...properties.filter((property) => !orderedSet.has(property))];
  }

  private persistVisibleColumnOrder(visibleOrder: BasesPropertyId[]): void {
    const visibleSet = new Set(this.columns.map((column) => column.id));
    const hiddenAndMissing = this.allColumnProperties.filter((property) => !visibleSet.has(property));
    this.viewConfig = {
      ...this.viewConfig,
      columnOrder: [...visibleOrder, ...hiddenAndMissing]
    };
    this.allColumnProperties = this.applyColumnOrder(this.allColumnProperties);
    writeDuoweiConfig(this.config, this.viewConfig);
  }

  private getPropertyLabel(property: BasesPropertyId): string {
    const direct = this.config.getDisplayName(property);
    const noteName = propertyName(property);
    if (!noteName) return direct;

    const withoutPrefix = this.config.getDisplayName(noteName as BasesPropertyId);
    return withoutPrefix === noteName && direct ? direct : withoutPrefix;
  }

  private isFrozenColumn(columnIndex: number): boolean {
    return columnIndex < Math.min(this.viewConfig.frozenColumns, this.columns.length);
  }

  private frozenColumnLeft(columnIndex: number): number {
    let left = 40;
    for (let index = 0; index < columnIndex; index += 1) {
      left += this.columns[index]?.width ?? 0;
    }
    return left;
  }

  private gridTemplate(): string {
    return `40px ${this.columns.map((column) => `${column.width}px`).join(" ")}`;
  }

  private totalWidth(): number {
    return 40 + this.columns.reduce((sum, column) => sum + column.width, 0);
  }

  private isActive(path: string, property: BasesPropertyId): boolean {
    return this.activeCell?.path === path && this.activeCell.property === property;
  }

  private isEditableProperty(property: BasesPropertyId): boolean {
    return property.startsWith("note.") || property === "file.name";
  }
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : "写入失败";
}

function displayForPrimitive(editor: EditorKind, value: unknown): string {
  if (value === undefined || value === null) return "";
  if (editor === "boolean") return value === true ? "是" : "否";
  if (Array.isArray(value)) return value.join(", ");
  return String(value);
}

function cellKey(path: string, property: BasesPropertyId): string {
  return `${path}\u0000${property}`;
}

function sameValue(left: unknown, right: unknown): boolean {
  if (left === right) return true;
  if ((left === undefined && right === null) || (left === null && right === undefined)) return true;
  try {
    return JSON.stringify(left) === JSON.stringify(right);
  } catch {
    return false;
  }
}

function parseClipboardTable(text: string): string[][] {
  const normalized = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  const trimmed = normalized.endsWith("\n") ? normalized.slice(0, -1) : normalized;
  return trimmed.split("\n").map((row) => row.split("\t"));
}

function isEditorElement(target: EventTarget | null): boolean {
  return target instanceof HTMLElement && Boolean(target.closest("input, textarea, select, .mt-cell-editor"));
}

function isPrintableEditKey(event: KeyboardEvent): boolean {
  if (event.isComposing) return false;
  if (event.ctrlKey || event.metaKey || event.altKey) return false;
  return event.key.length === 1 && event.key !== " ";
}

function dateInputValue(display: string): string {
  const match = display.match(/^\d{4}-\d{2}-\d{2}/);
  return match?.[0] ?? "";
}

function cssEscape(value: string): string {
  return CSS.escape(value);
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

function rangeCellCount(range: NormalizedSelectionRange): number {
  return (range.rowEnd - range.rowStart + 1) * (range.columnEnd - range.columnStart + 1);
}

function lastCellTarget(targets: PasteTarget[]): CellTarget | null {
  for (let index = targets.length - 1; index >= 0; index -= 1) {
    const target = targets[index]?.cellTarget;
    if (target) return target;
  }
  return null;
}

function displayWidth(value: string): number {
  let width = 0;
  for (const char of value) {
    width += char.charCodeAt(0) > 255 ? 2 : 1;
  }
  return width;
}
