import {
  BooleanValue,
  DateValue,
  ListValue,
  NullValue,
  NumberValue,
  type BasesPropertyId,
  type Value
} from "obsidian";
import type { EditorKind, FieldViewConfig } from "../model/config";

export interface AdaptedValue {
  primitive: unknown;
  display: string;
  editor: EditorKind;
  editable: boolean;
}

export function adaptValue(
  propertyId: BasesPropertyId,
  value: Value | null,
  fieldConfig?: FieldViewConfig
): AdaptedValue {
  const noteProperty = propertyId.startsWith("note.");
  const editableFileName = propertyId === "file.name";
  const configuredEditor = fieldConfig?.editor;

  if (!value || value instanceof NullValue) {
    return {
      primitive: undefined,
      display: "",
      editor: configuredEditor ?? "text",
      editable: (noteProperty || editableFileName) && configuredEditor !== "readonly"
    };
  }

  if (value instanceof BooleanValue) {
    const primitive = value.isTruthy();
    return {
      primitive,
      display: primitive ? "是" : "否",
      editor: configuredEditor ?? "boolean",
      editable: noteProperty && configuredEditor !== "readonly"
    };
  }

  if (value instanceof NumberValue) {
    const primitive = Number(value.toString());
    return {
      primitive,
      display: value.toString(),
      editor: configuredEditor ?? "number",
      editable: noteProperty && configuredEditor !== "readonly"
    };
  }

  if (value instanceof DateValue) {
    const display = value.toString();
    return {
      primitive: display,
      display,
      editor: configuredEditor ?? "date",
      editable: noteProperty && configuredEditor !== "readonly"
    };
  }

  if (value instanceof ListValue) {
    const items: string[] = [];
    for (let index = 0; index < value.length(); index += 1) {
      items.push(value.get(index).toString());
    }
    return {
      primitive: items,
      display: items.join(", "),
      editor: "readonly",
      editable: false
    };
  }

  return {
    primitive: value.toString(),
    display: value.toString(),
    editor: editableFileName ? "text" : configuredEditor ?? "text",
    editable: (noteProperty || editableFileName) && configuredEditor !== "readonly"
  };
}

export function parseEditorValue(editor: EditorKind, raw: string, fieldConfig?: FieldViewConfig): unknown {
  if (editor === "number") {
    if (raw.trim() === "") return undefined;
    const value = Number(raw);
    if (!Number.isFinite(value)) throw new Error("请输入有效数字");
    return value;
  }
  if (editor === "boolean") {
    const value = raw.trim().toLowerCase();
    if (value === "") return undefined;
    if (["true", "yes", "y", "1", "是", "对", "已完成"].includes(value)) return true;
    if (["false", "no", "n", "0", "否", "错", "未完成"].includes(value)) return false;
    throw new Error("请输入布尔值：是/否");
  }
  if (editor === "select") {
    const value = raw.trim();
    if (value === "") return undefined;
    const options = fieldConfig?.options ?? [];
    if (options.length > 0 && !options.some((option) => option.label === value)) {
      throw new Error(`不在可选项中：${value}`);
    }
    return value;
  }
  if (editor === "date") {
    const value = raw.trim();
    if (value === "") return undefined;
    if (!DateValue.parseFromString(value)) throw new Error("请输入有效日期");
    return value;
  }
  if (editor === "readonly") {
    throw new Error("该字段只读");
  }
  return raw === "" ? undefined : raw;
}

export function propertyName(propertyId: BasesPropertyId): string | null {
  if (!propertyId.startsWith("note.")) return null;
  return propertyId.slice("note.".length);
}
