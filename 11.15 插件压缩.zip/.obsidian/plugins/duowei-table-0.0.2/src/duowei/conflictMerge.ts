import { cloneDuoweiDocument, touchDuoweiDocument, type DuoweiDocument, type DuoweiField, type DuoweiRecord } from "./schema";

export type ConflictSide = "disk" | "local";

export const MAX_MERGEABLE_CELL_CONFLICTS = 200;

export interface CellConflictItem {
  key: string;
  recordId: string;
  fieldId: string;
  fieldName: string;
  diskValue: unknown;
  localValue: unknown;
}

export type RecordConflictKind = "diskOnly" | "localOnly";

export interface RecordConflictItem {
  key: string;
  recordId: string;
  kind: RecordConflictKind;
}

export interface ConflictDiffResult {
  cellConflicts: CellConflictItem[];
  recordConflicts: RecordConflictItem[];
  truncated: boolean;
}

export interface ConflictResolutions {
  cells: Map<string, ConflictSide>;
  records: Map<string, ConflictSide>;
}

export function computeCellConflicts(diskDocument: DuoweiDocument, localDocument: DuoweiDocument): ConflictDiffResult {
  const diskFieldsById = new Map(diskDocument.fields.map((field) => [field.id, field]));
  const localFieldsById = new Map(localDocument.fields.map((field) => [field.id, field]));
  const diskRecordsById = new Map(diskDocument.records.map((record) => [record.id, record]));
  const localRecordsById = new Map(localDocument.records.map((record) => [record.id, record]));

  const cellConflicts: CellConflictItem[] = [];
  const recordConflicts: RecordConflictItem[] = [];

  for (const [recordId, localRecord] of localRecordsById) {
    const diskRecord = diskRecordsById.get(recordId);
    if (!diskRecord) {
      recordConflicts.push({ key: recordId, recordId, kind: "localOnly" });
      continue;
    }
    const fieldIds = new Set([...Object.keys(diskRecord.values), ...Object.keys(localRecord.values)]);
    for (const fieldId of fieldIds) {
      const field = localFieldsById.get(fieldId) ?? diskFieldsById.get(fieldId);
      if (!field) continue;
      const diskValue = diskRecord.values[fieldId] ?? null;
      const localValue = localRecord.values[fieldId] ?? null;
      if (JSON.stringify(diskValue) === JSON.stringify(localValue)) continue;
      cellConflicts.push({
        key: `${recordId}:${fieldId}`,
        recordId,
        fieldId,
        fieldName: field.name,
        diskValue,
        localValue
      });
      if (cellConflicts.length > MAX_MERGEABLE_CELL_CONFLICTS) {
        return { cellConflicts, recordConflicts, truncated: true };
      }
    }
  }
  for (const recordId of diskRecordsById.keys()) {
    if (!localRecordsById.has(recordId)) recordConflicts.push({ key: recordId, recordId, kind: "diskOnly" });
  }
  return { cellConflicts, recordConflicts, truncated: false };
}

export function applyConflictResolutions(
  diskDocument: DuoweiDocument,
  localDocument: DuoweiDocument,
  resolutions: ConflictResolutions
): DuoweiDocument {
  const merged = cloneDuoweiDocument(localDocument);
  const diskRecordsById = new Map(diskDocument.records.map((record) => [record.id, record]));
  const mergedRecordsById = new Map(merged.records.map((record) => [record.id, record]));

  for (const [key, side] of resolutions.cells) {
    if (side !== "disk") continue;
    const separator = key.indexOf(":");
    if (separator < 0) continue;
    const recordId = key.slice(0, separator);
    const fieldId = key.slice(separator + 1);
    const record = mergedRecordsById.get(recordId);
    const diskRecord = diskRecordsById.get(recordId);
    if (!record || !diskRecord) continue;
    record.values[fieldId] = diskRecord.values[fieldId];
  }

  for (const [recordId, side] of resolutions.records) {
    if (side !== "disk") continue;
    const diskRecord = diskRecordsById.get(recordId);
    if (diskRecord && !mergedRecordsById.has(recordId)) {
      const restored: DuoweiRecord = JSON.parse(JSON.stringify(diskRecord)) as DuoweiRecord;
      merged.records.push(restored);
      mergedRecordsById.set(recordId, restored);
    } else if (!diskRecord && mergedRecordsById.has(recordId)) {
      merged.records = merged.records.filter((record) => record.id !== recordId);
      mergedRecordsById.delete(recordId);
    }
  }

  touchDuoweiDocument(merged);
  return merged;
}

export function conflictValueLabel(value: unknown, field: DuoweiField | undefined): string {
  if (value === undefined || value === null || value === "") return "（空）";
  if (field?.type === "checkbox") return value === true ? "是" : "否";
  if ((field?.type === "singleSelect" || field?.type === "multiSelect") && field.options) {
    const items = Array.isArray(value) ? value : [value];
    const labels = items
      .map((item) => field.options?.find((option) => option.id === item || option.name === item)?.name ?? String(item))
      .filter(Boolean);
    return labels.join(", ") || "（空）";
  }
  if (Array.isArray(value)) return value.map((item) => String(item)).join(", ") || "（空）";
  return String(value);
}

export function conflictRecordLabel(record: DuoweiRecord, fields: DuoweiField[], fallbackIndex: number): string {
  const titleField = fields[0];
  const raw = titleField ? record.values[titleField.id] : undefined;
  const label = titleField ? conflictValueLabel(raw, titleField) : "";
  return label && label !== "（空）" ? label : `记录 ${fallbackIndex + 1}`;
}
