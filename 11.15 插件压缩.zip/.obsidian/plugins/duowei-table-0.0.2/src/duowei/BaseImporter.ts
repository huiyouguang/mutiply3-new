import {
  Notice,
  parseYaml,
  type App,
  type TFile
} from "obsidian";
import {
  createDefaultGalleryView,
  createDefaultGridView,
  createDefaultKanbanView,
  createDuoweiField,
  createDuoweiRecord,
  createId,
  nextOptionColor,
  serializeDuoweiDocument,
  type DuoweiDocument,
  type DuoweiField,
  type DuoweiFieldType
} from "./schema";

interface BaseImportSpec {
  name: string;
  /** 显式列顺序：view.order + duowei.columnOrder + duowei.columns。 */
  order: string[];
  /** order 只有标题列时的兜底候选：base 里声明过的所有属性。 */
  fallbackKeys: string[];
  displayNames: Record<string, string>;
  fieldHints: Record<string, { editor?: string; options?: Array<{ label: string; color?: string }> }>;
  columnWidths: Record<string, number>;
  filters: string[];
}

interface ImportedRecordSource {
  file: TFile;
  frontmatter: Record<string, unknown>;
}

export async function importBaseToDuowei(app: App, baseFile: TFile): Promise<TFile | null> {
  const raw = await app.vault.read(baseFile);
  const spec = parseBaseImportSpec(raw, baseFile.basename);
  const sources = app.vault
    .getMarkdownFiles()
    .map((file) => ({ file, frontmatter: (app.metadataCache.getFileCache(file)?.frontmatter ?? {}) as Record<string, unknown> }))
    .filter((source) => matchesBaseFilters(source, spec.filters));

  if (sources.length === 0) {
    new Notice("没有找到符合当前 .base 筛选条件的 Markdown 记录。", 4000);
    return null;
  }

  const document = createDocumentFromBase(spec, sources, baseFile.basename);
  const folder = "多维表格";
  if (!app.vault.getAbstractFileByPath(folder)) {
    await app.vault.createFolder(folder);
  }
  const path = await nextAvailablePath(app, folder, `${baseFile.basename} 导入`, "duowei");
  const file = await app.vault.create(path, serializeDuoweiDocument(document));
  await app.workspace.getLeaf("tab").openFile(file);
  new Notice(`已从 .base 导入 ${sources.length} 条记录、${document.fields.length} 个字段。`, 4000);
  return file;
}

function parseBaseImportSpec(raw: string, fallbackName: string): BaseImportSpec {
  const parsed = parseYaml(raw) as unknown;
  const root = isRecord(parsed) ? parsed : {};
  const properties = isRecord(root.properties) ? root.properties : {};
  const displayNames: Record<string, string> = {};
  for (const [key, value] of Object.entries(properties)) {
    const normalizedKey = normalizeBasePropertyKey(key);
    displayNames[normalizedKey] =
      isRecord(value) && typeof value.displayName === "string" ? value.displayName : normalizedKey;
  }

  const views = Array.isArray(root.views) ? root.views.filter(isRecord) : [];
  const firstView = views.find((view) => Array.isArray(view.order)) ?? views[0] ?? {};
  const viewOrder = stringArray(firstView.order);

  const duowei = isRecord(firstView.duowei) ? firstView.duowei : {};
  const duoweiFields = isRecord(duowei.fields) ? duowei.fields : {};
  const duoweiColumns = isRecord(duowei.columns) ? duowei.columns : {};
  const duoweiColumnOrder = stringArray(duowei.columnOrder);

  const fieldHints: BaseImportSpec["fieldHints"] = {};
  for (const [key, value] of Object.entries(duoweiFields)) {
    if (!isRecord(value)) continue;
    fieldHints[normalizeBasePropertyKey(key)] = {
      editor: typeof value.editor === "string" ? value.editor : undefined,
      options: Array.isArray(value.options)
        ? value.options
            .filter(isRecord)
            .map((option) => ({
              label: typeof option.label === "string" ? option.label : String(option.id ?? ""),
              color: typeof option.color === "string" ? option.color : undefined
            }))
            .filter((option) => option.label)
        : undefined
    };
  }

  const columnKeys: string[] = [];
  const columnWidths: Record<string, number> = {};
  for (const [key, value] of Object.entries(duoweiColumns)) {
    const normalizedKey = normalizeBasePropertyKey(key);
    if (isRecord(value) && value.hidden === true) continue;
    columnKeys.push(normalizedKey);
    const width = isRecord(value) ? Number(value.width) : Number.NaN;
    if (Number.isFinite(width)) columnWidths[normalizedKey] = Math.max(72, Math.min(640, Math.round(width)));
  }

  return {
    name: typeof firstView.name === "string" && firstView.name.trim() ? firstView.name : fallbackName,
    order: mergeBaseKeys([...viewOrder, ...duoweiColumnOrder, ...columnKeys]),
    fallbackKeys: mergeBaseKeys([
      "file.name",
      ...Object.keys(displayNames),
      ...Object.keys(fieldHints),
      ...columnKeys
    ]),
    displayNames,
    fieldHints,
    columnWidths,
    filters: [...flattenBaseFilters(root.filters), ...flattenBaseFilters(firstView.filters)]
  };
}

function createDocumentFromBase(spec: BaseImportSpec, sources: ImportedRecordSource[], fallbackName: string): DuoweiDocument {
  const now = new Date().toISOString();
  const fieldKeys = resolveFieldKeys(spec, sources);
  const fields = fieldKeys.map((key) => createFieldFromBaseKey(key, spec, sources));
  const keyToField = new Map(fieldKeys.map((key, index) => [key, fields[index]]));
  const records = sources.map((source) => {
    const values: Record<string, unknown> = {};
    for (const key of fieldKeys) {
      const field = keyToField.get(key);
      if (!field) continue;
      values[field.id] = valueForBaseKey(source, key, field);
    }
    const record = createDuoweiRecord(fields, values);
    record.notePath = source.file.path;
    record.createdAt = now;
    record.updatedAt = now;
    return record;
  });
  const grid = createDefaultGridView(fields);
  grid.name = spec.name || "表格";
  return {
    schemaVersion: 1,
    id: createId("tbl"),
    name: fallbackName,
    fields,
    records,
    views: [grid, createDefaultKanbanView(fields), createDefaultGalleryView(fields)],
    activeViewId: grid.id,
    meta: { createdAt: now, updatedAt: now }
  };
}

/**
 * 决定导入哪些列。`.base` 常常只在 view.order 里写了 file.name，
 * 此时退回到 base 声明过的属性 + 实际 frontmatter 推断，避免只导入一列标题。
 */
function resolveFieldKeys(spec: BaseImportSpec, sources: ImportedRecordSource[]): string[] {
  const explicitKeys = spec.order.length > 0 ? spec.order : spec.fallbackKeys;
  const hasDataColumn = explicitKeys.some((key) => !isTitleLikeKey(key));
  const keys = hasDataColumn
    ? explicitKeys
    : [...explicitKeys, ...spec.fallbackKeys, ...inferKeysFromSources(sources)];
  const resolved = mergeBaseKeys(keys);
  return resolved.length > 0 ? resolved : ["file.name"];
}

function createFieldFromBaseKey(key: string, spec: BaseImportSpec, sources: ImportedRecordSource[]): DuoweiField {
  const hint = spec.fieldHints[key];
  const type = fieldTypeFromKey(key, hint?.editor, sources.map((source) => rawValueForBaseKey(source, key)));
  const label = fieldLabelForBaseKey(key, spec);
  const field = createDuoweiField(type, label, spec.columnWidths[key] ?? (isTitleLikeKey(key) ? 240 : undefined));
  if (isFrontmatterBaseKey(key)) {
    field.syncKey = key;
  }
  if (type === "singleSelect" || type === "multiSelect") {
    field.options = [];
    const hintedOptions: Array<{ label: string; color?: string }> = hint?.options ?? [];
    const labels: Array<{ label: string; color?: string }> = hintedOptions.length > 0
      ? hintedOptions
      : [...new Set(sources.flatMap((source) => selectLabelsFromRaw(rawValueForBaseKey(source, key))))]
          .slice(0, 40)
          .map((value) => ({ label: value, color: undefined }));
    for (const option of labels) {
      field.options.push({
        id: createId("opt"),
        name: option.label,
        color: option.color ?? nextOptionColor(field.options)
      });
    }
  }
  return field;
}

function fieldLabelForBaseKey(key: string, spec: BaseImportSpec): string {
  const configured = spec.displayNames[key];
  if (configured) return configured;
  switch (key) {
    case "file.name":
    case "file.basename":
      return "标题";
    case "file.path":
      return "路径";
    case "file.ext":
    case "file.extension":
      return "扩展名";
    case "file.folder":
      return "文件夹";
    case "file.size":
      return "大小";
    case "file.ctime":
      return "创建时间";
    case "file.mtime":
      return "修改时间";
    case "file.tags":
      return "标签";
    default:
      return key;
  }
}

function selectLabelsFromRaw(raw: unknown): string[] {
  if (raw === undefined || raw === null) return [];
  if (Array.isArray(raw)) return raw.flatMap(selectLabelsFromRaw);
  return String(raw)
    .split(/[,，\n]/)
    .map((item) => item.trim().replace(/^#/, ""))
    .filter(Boolean);
}

function valueForBaseKey(source: ImportedRecordSource, key: string, field: DuoweiField): unknown {
  const raw = rawValueForBaseKey(source, key);
  if (raw === undefined || raw === null || raw === "") return field.type === "checkbox" ? false : undefined;
  if (field.type === "noteLink") return source.file.basename;
  if (field.type === "singleSelect") {
    const label = String(raw);
    const option = field.options?.find((item) => item.name === label || item.id === label);
    return option?.id ?? label;
  }
  if (field.type === "multiSelect") {
    const options = field.options ?? [];
    const values = selectLabelsFromRaw(raw)
      .map((label) => options.find((item) => item.name === label || item.id === label)?.id ?? label)
      .filter(Boolean);
    return values.length > 0 ? values : undefined;
  }
  if (field.type === "checkbox") return raw === true || String(raw).toLowerCase() === "true" || String(raw) === "是";
  if (field.type === "number") {
    const value = Number(raw);
    return Number.isFinite(value) ? value : undefined;
  }
  // Basic 只有「日期」没有「日期时间」，统一截到 yyyy-MM-dd，保证值对字段类型合法。
  if (field.type === "date") {
    const match = /^(\d{4}-\d{2}-\d{2})/.exec(String(raw));
    return match?.[1];
  }
  return raw;
}

function rawValueForBaseKey(source: ImportedRecordSource, key: string): unknown {
  if (key === "file.name" || key === "file.basename") return source.file.basename;
  if (key === "file.path") return source.file.path;
  if (key === "file.ext" || key === "file.extension") return source.file.extension;
  if (key === "file.folder") return source.file.parent?.path ?? "/";
  if (key === "file.size") return source.file.stat.size;
  if (key === "file.ctime") return new Date(source.file.stat.ctime).toISOString();
  if (key === "file.mtime") return new Date(source.file.stat.mtime).toISOString();
  if (key === "file.tags") return selectLabelsFromRaw(source.frontmatter.tags);
  return source.frontmatter[key];
}

function fieldTypeFromKey(key: string, editor: string | undefined, values: unknown[]): DuoweiFieldType {
  // 标题列指向来源笔记，用笔记链接字段，单元格可直接点开对应笔记。
  if (isTitleLikeKey(key)) return "noteLink";
  return fieldTypeFromHintOrValues(editor, values);
}

function fieldTypeFromHintOrValues(editor: string | undefined, values: unknown[]): DuoweiFieldType {
  if (editor === "number") return "number";
  if (editor === "boolean") return "checkbox";
  if (editor === "date") return "date";
  if (editor === "select") return "singleSelect";
  if (editor === "multiSelect" || editor === "multi-select") return "multiSelect";
  const nonEmpty = values.filter((value) => value !== undefined && value !== null && value !== "");
  if (nonEmpty.length === 0) return "text";
  if (nonEmpty.some((value) => Array.isArray(value))) return "multiSelect";
  if (nonEmpty.every((value) => typeof value === "boolean")) return "checkbox";
  if (nonEmpty.every((value) => Number.isFinite(Number(value)))) return "number";
  if (nonEmpty.every((value) => typeof value === "string" && /^\d{4}-\d{2}-\d{2}/.test(value))) return "date";
  if (nonEmpty.every((value) => typeof value === "string" && /^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(value))) return "email";
  const unique = new Set(nonEmpty.map((value) => String(value)));
  if (unique.size <= Math.min(40, Math.max(3, Math.ceil(nonEmpty.length * 0.6)))) return "singleSelect";
  return "text";
}

function matchesBaseFilters(source: ImportedRecordSource, filters: string[]): boolean {
  return filters.every((filter) => matchesFilterExpression(source, filter));
}

function matchesFilterExpression(source: ImportedRecordSource, filter: string): boolean {
  const trimmed = filter.trim();
  if (trimmed === "" || trimmed === 'file.ext == "md"' || trimmed === "file.ext == 'md'") return true;
  const folderMatch = trimmed.match(/^file\.inFolder\(["'](.+)["']\)$/);
  if (folderMatch?.[1]) return source.file.path.startsWith(`${folderMatch[1].replace(/\/$/, "")}/`);
  const equality = trimmed.match(/^(?:note\.)?([A-Za-z0-9_-]+)\s*==\s*["'](.+)["']$/);
  if (equality?.[1]) return String(source.frontmatter[equality[1]] ?? "") === equality[2];
  return true;
}

function flattenBaseFilters(value: unknown): string[] {
  if (typeof value === "string") return [value];
  if (Array.isArray(value)) return value.flatMap(flattenBaseFilters);
  if (!isRecord(value)) return [];
  return Object.values(value).flatMap(flattenBaseFilters);
}

function stringArray(value: unknown): string[] {
  return Array.isArray(value) ? value.filter((item): item is string => typeof item === "string") : [];
}

/** 归一化、去重并丢弃 Basic 不支持的 formula.* 列。 */
function mergeBaseKeys(keys: string[]): string[] {
  const normalized: string[] = [];
  const seen = new Set<string>();
  for (const item of keys.map(normalizeBasePropertyKey)) {
    if (!item || item.startsWith("formula.")) continue;
    if (seen.has(item)) continue;
    seen.add(item);
    normalized.push(item);
  }
  return normalized;
}

function normalizeBasePropertyKey(key: string): string {
  return key.startsWith("note.") ? key.slice("note.".length) : key;
}

function isTitleLikeKey(key: string): boolean {
  return key === "file.name" || key === "file.basename";
}

function isFrontmatterBaseKey(key: string): boolean {
  return !key.startsWith("file.") && !key.startsWith("formula.");
}

function inferKeysFromSources(sources: ImportedRecordSource[]): string[] {
  const keys = new Set<string>(["file.name"]);
  for (const source of sources) {
    for (const key of Object.keys(source.frontmatter)) keys.add(key);
  }
  return [...keys];
}

async function nextAvailablePath(app: App, folder: string, baseName: string, extension: string): Promise<string> {
  let index = 1;
  while (true) {
    const suffix = index === 1 ? "" : ` ${index}`;
    const path = `${folder}/${baseName}${suffix}.${extension}`;
    if (!app.vault.getAbstractFileByPath(path)) return path;
    index += 1;
  }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
