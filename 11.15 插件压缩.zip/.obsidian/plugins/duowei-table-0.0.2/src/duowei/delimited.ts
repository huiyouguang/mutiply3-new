export type DelimitedKind = "csv" | "tsv";

export function parseDelimited(text: string, kind: DelimitedKind): string[][] {
  const delimiter = kind === "tsv" ? "\t" : ",";
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = "";
  let quoted = false;

  for (let index = 0; index < text.length; index += 1) {
    const char = text[index] ?? "";
    const next = text[index + 1] ?? "";

    if (quoted) {
      if (char === '"' && next === '"') {
        cell += '"';
        index += 1;
      } else if (char === '"') {
        quoted = false;
      } else {
        cell += char;
      }
      continue;
    }

    if (char === '"') {
      quoted = true;
      continue;
    }
    if (char === delimiter) {
      row.push(cell);
      cell = "";
      continue;
    }
    if (char === "\n") {
      row.push(cell);
      rows.push(row);
      row = [];
      cell = "";
      continue;
    }
    if (char === "\r") {
      if (next === "\n") continue;
      row.push(cell);
      rows.push(row);
      row = [];
      cell = "";
      continue;
    }
    cell += char;
  }

  row.push(cell);
  if (row.some((value) => value !== "") || rows.length === 0) rows.push(row);
  return trimTrailingEmptyRows(rows);
}

export function detectDelimitedKind(name: string): DelimitedKind {
  return name.toLowerCase().endsWith(".tsv") ? "tsv" : "csv";
}

function trimTrailingEmptyRows(rows: string[][]): string[][] {
  let end = rows.length;
  while (end > 0 && rows[end - 1]?.every((value) => value === "")) end -= 1;
  return rows.slice(0, end);
}
