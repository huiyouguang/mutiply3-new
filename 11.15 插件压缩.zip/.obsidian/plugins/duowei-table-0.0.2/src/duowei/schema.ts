export const DUOWEI_EXTENSION = "duowei";
export const DUOWEI_VIEW_TYPE = "duowei-table";

/**
 * Basic 版支持的字段类型。Pro 独有类型（长文本、日期时间、链接、关联记录、查找、
 * 汇总、公式等）会在打开时触发保护性只读，绝不改写原文件。
 */
export const BASIC_FIELD_TYPES = [
  "text",
  "number",
  "checkbox",
  "date",
  "singleSelect",
  "multiSelect",
  "email",
  "noteLink",
  "attachment"
] as const;

export type DuoweiFieldType = typeof BASIC_FIELD_TYPES[number];

/** Basic 版支持的视图类型。日历 / 时间线为 Pro 独有。 */
export const BASIC_VIEW_TYPES = ["grid", "kanban", "gallery"] as const;

export type DuoweiViewType = typeof BASIC_VIEW_TYPES[number];

export interface DuoweiSelectOption {
  id: string;
  name: string;
  color?: string;
}

export interface DuoweiField {
  id: string;
  name: string;
  type: DuoweiFieldType;
  required?: boolean;
  width?: number;
  syncKey?: string;
  options?: DuoweiSelectOption[];
}

export interface DuoweiRecord {
  id: string;
  values: Record<string, unknown>;
  notePath?: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface DuoweiSortRule {
  fieldId: string;
  direction: "asc" | "desc";
}

export interface DuoweiFilterRule {
  fieldId: string;
  op: "contains" | "equals" | "empty" | "notEmpty";
  value: string;
}

export interface DuoweiBaseViewConfig {
  id: string;
  name: string;
  type: DuoweiViewType;
  fieldOrder: string[];
  hiddenFields: string[];
  sorts: DuoweiSortRule[];
  filters: DuoweiFilterRule[];
}

export interface DuoweiGridViewConfig extends DuoweiBaseViewConfig {
  type: "grid";
  rowHeight: "compact" | "default" | "comfortable";
  frozenFieldCount: number;
}

export interface DuoweiKanbanViewConfig extends DuoweiBaseViewConfig {
  type: "kanban";
  groupFieldId: string | null;
  titleFieldId: string | null;
  cardFieldIds: string[];
}

export interface DuoweiGalleryViewConfig extends DuoweiBaseViewConfig {
  type: "gallery";
  coverFieldId: string | null;
  titleFieldId: string | null;
  cardFieldIds: string[];
}

export type DuoweiViewConfig =
  | DuoweiGridViewConfig
  | DuoweiKanbanViewConfig
  | DuoweiGalleryViewConfig;

export interface DuoweiDocument {
  schemaVersion: 1;
  id: string;
  name: string;
  fields: DuoweiField[];
  records: DuoweiRecord[];
  views: DuoweiViewConfig[];
  activeViewId?: string;
  meta: {
    createdAt: string;
    updatedAt: string;
  };
}

export interface ParsedDuoweiDocument {
  document: DuoweiDocument;
  repaired: boolean;
  error?: string;
  /** 文件包含 Basic 不支持的内容时为 true：仅可查看、不可编辑、绝不改写原文件。 */
  readOnly: boolean;
  /** readOnly 为 true 时说明触发原因，用于向用户展示。 */
  readOnlyReason?: string;
}

const DEFAULT_SELECT_COLORS = [
  "var(--color-blue)",
  "var(--color-green)",
  "var(--color-orange)",
  "var(--color-purple)",
  "var(--color-red)",
  "var(--color-cyan)"
];

/** 允许出现在共享协议里的键；多余键一律触发保护性只读，保证绝不静默丢弃 Pro 数据。 */
const ALLOWED_DOCUMENT_KEYS = ["schemaVersion", "id", "name", "fields", "records", "views", "activeViewId", "meta"];
const ALLOWED_META_KEYS = ["createdAt", "updatedAt"];
const ALLOWED_FIELD_KEYS = ["id", "name", "type", "required", "width", "syncKey", "options"];
const ALLOWED_OPTION_KEYS = ["id", "name", "color"];
const ALLOWED_RECORD_KEYS = ["id", "values", "notePath", "createdAt", "updatedAt"];
const ALLOWED_BASE_VIEW_KEYS = ["id", "name", "type", "fieldOrder", "hiddenFields", "sorts", "filters"];
const ALLOWED_VIEW_KEYS: Record<DuoweiViewType, string[]> = {
  grid: [...ALLOWED_BASE_VIEW_KEYS, "rowHeight", "frozenFieldCount"],
  kanban: [...ALLOWED_BASE_VIEW_KEYS, "groupFieldId", "titleFieldId", "cardFieldIds"],
  gallery: [...ALLOWED_BASE_VIEW_KEYS, "coverFieldId", "titleFieldId", "cardFieldIds"]
};

export function createBlankDuoweiDocument(name = "未命名多维表格"): DuoweiDocument {
  const now = new Date().toISOString();
  const titleField = createDuoweiField("text", "标题", 240);
  const statusField = createDuoweiField("singleSelect", "状态", 140);
  statusField.options = [
    { id: createId("opt"), name: "待处理", color: "var(--color-orange)" },
    { id: createId("opt"), name: "进行中", color: "var(--color-blue)" },
    { id: createId("opt"), name: "已完成", color: "var(--color-green)" }
  ];
  const doneField = createDuoweiField("checkbox", "完成", 96);
  const fields = [titleField, statusField, doneField];
  const firstStatus = statusField.options[0]?.id;
  const records = [
    createDuoweiRecord(fields, {
      [titleField.id]: "第一条记录",
      [statusField.id]: firstStatus,
      [doneField.id]: false
    })
  ];

  return {
    schemaVersion: 1,
    id: createId("tbl"),
    name,
    fields,
    records,
    views: [
      createDefaultGridView(fields),
      createDefaultKanbanView(fields),
      createDefaultGalleryView(fields)
    ],
    activeViewId: undefined,
    meta: {
      createdAt: now,
      updatedAt: now
    }
  };
}

export function createDuoweiField(
  type: DuoweiFieldType = "text",
  name = "字段",
  width = defaultFieldWidth(type)
): DuoweiField {
  return {
    id: createId("fld"),
    name,
    type,
    width
  };
}

export function createDuoweiRecord(
  fields: DuoweiField[],
  values: Record<string, unknown> = {}
): DuoweiRecord {
  const now = new Date().toISOString();
  const normalized: Record<string, unknown> = {};
  for (const field of fields) {
    if (Object.prototype.hasOwnProperty.call(values, field.id)) {
      normalized[field.id] = values[field.id];
    } else if (field.type === "checkbox") {
      normalized[field.id] = false;
    }
  }

  return {
    id: createId("rec"),
    values: normalized,
    notePath: null,
    createdAt: now,
    updatedAt: now
  };
}

export function createDefaultGridView(fields: DuoweiField[]): DuoweiGridViewConfig {
  return {
    id: createId("view"),
    name: "表格",
    type: "grid",
    fieldOrder: fields.map((field) => field.id),
    hiddenFields: [],
    sorts: [],
    filters: [],
    rowHeight: "default",
    frozenFieldCount: 1
  };
}

export function createDefaultKanbanView(fields: DuoweiField[]): DuoweiKanbanViewConfig {
  const groupField = fields.find((field) => field.type === "singleSelect" || field.type === "checkbox") ?? fields[0];
  const titleField = fields[0] ?? null;
  return {
    id: createId("view"),
    name: "看板",
    type: "kanban",
    fieldOrder: fields.map((field) => field.id),
    hiddenFields: [],
    sorts: [],
    filters: [],
    groupFieldId: groupField?.id ?? null,
    titleFieldId: titleField?.id ?? null,
    cardFieldIds: fields.slice(1, 4).map((field) => field.id)
  };
}

export function createDefaultGalleryView(fields: DuoweiField[]): DuoweiGalleryViewConfig {
  const coverField =
    fields.find((field) => field.type === "attachment" || field.type === "noteLink") ?? null;
  const titleField = fields[0] ?? null;
  const hidden = new Set([coverField?.id, titleField?.id].filter((fieldId): fieldId is string => Boolean(fieldId)));
  return {
    id: createId("view"),
    name: "画廊",
    type: "gallery",
    fieldOrder: fields.map((field) => field.id),
    hiddenFields: [],
    sorts: [],
    filters: [],
    coverFieldId: coverField?.id ?? null,
    titleFieldId: titleField?.id ?? null,
    cardFieldIds: fields.filter((field) => !hidden.has(field.id)).slice(0, 4).map((field) => field.id)
  };
}

export function parseDuoweiDocument(data: string, fallbackName = "未命名多维表格"): ParsedDuoweiDocument {
  if (!data.trim()) {
    return { document: createBlankDuoweiDocument(fallbackName), repaired: true, readOnly: false };
  }

  let raw: unknown;
  try {
    raw = JSON.parse(data) as unknown;
  } catch (error) {
    return {
      document: createBlankDuoweiDocument(fallbackName),
      repaired: false,
      readOnly: true,
      readOnlyReason: `无法解析文件内容：${error instanceof Error ? error.message : "非法 JSON"}`
    };
  }

  // 共享协议严格校验：只要包含 Basic 不支持的内容就锁定为只读，绝不改写。
  let readOnlyReason: string | undefined;
  try {
    validateSharedDocument(raw);
  } catch (error) {
    readOnlyReason = error instanceof Error ? error.message : "文件包含 Basic 不支持的内容";
  }

  // 无论是否只读，都用宽松解析生成一份可展示的模型（只读时仅用于查看，不会落盘）。
  const parsed = normalizeDuoweiDocument(raw, fallbackName);
  if (readOnlyReason) {
    return { document: parsed.document, repaired: false, readOnly: true, readOnlyReason };
  }
  return { document: parsed.document, repaired: parsed.repaired, error: parsed.error, readOnly: false };
}

export function serializeDuoweiDocument(document: DuoweiDocument): string {
  return `${JSON.stringify(document, null, 2)}\n`;
}

export function cloneDuoweiDocument(document: DuoweiDocument): DuoweiDocument {
  return JSON.parse(JSON.stringify(document)) as DuoweiDocument;
}

export function touchDuoweiDocument(document: DuoweiDocument): void {
  document.meta.updatedAt = new Date().toISOString();
}

export function createId(prefix: string): string {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 9)}`;
}

export function defaultFieldWidth(type: DuoweiFieldType): number {
  switch (type) {
    case "checkbox":
      return 96;
    case "number":
    case "date":
      return 128;
    case "singleSelect":
    case "multiSelect":
      return 150;
    case "attachment":
    case "noteLink":
      return 180;
    default:
      return 180;
  }
}

export function nextOptionColor(options: DuoweiSelectOption[] | undefined): string {
  const count = options?.length ?? 0;
  return DEFAULT_SELECT_COLORS[count % DEFAULT_SELECT_COLORS.length] ?? "var(--interactive-accent)";
}

/* -------------------------------------------------------------------------- */
/* 共享协议严格校验：命中任何 Basic 不支持的内容即抛错 → 触发保护性只读              */
/* -------------------------------------------------------------------------- */

function validateSharedDocument(raw: unknown): void {
  if (!isRecord(raw)) throw new Error("文件内容不是合法的表格对象");
  assertAllowedKeys(raw, ALLOWED_DOCUMENT_KEYS, "文件");
  if (raw.schemaVersion !== 1) throw new Error("Basic 暂不支持此文件版本");
  if (!Array.isArray(raw.fields) || !Array.isArray(raw.records) || !Array.isArray(raw.views)) {
    throw new Error("文件缺少 fields、records 或 views，无法按共享协议安全打开");
  }

  const fieldIds = new Set<string>();
  for (const field of raw.fields) {
    if (!isRecord(field) || typeof field.name !== "string" || typeof field.type !== "string") {
      throw new Error("存在无效的字段定义");
    }
    assertAllowedKeys(field, ALLOWED_FIELD_KEYS, `字段“${field.name}”`);
    if (!(BASIC_FIELD_TYPES as readonly string[]).includes(field.type)) {
      throw new Error(`字段“${field.name}”是 Basic 不支持的字段类型，文件已进入保护性只读模式`);
    }
    if (field.options !== undefined && field.type !== "singleSelect" && field.type !== "multiSelect") {
      throw new Error(`字段“${field.name}”包含不适用的选项配置`);
    }
    if (Array.isArray(field.options)) {
      for (const option of field.options) {
        if (!isRecord(option)) throw new Error(`字段“${field.name}”存在无效选项`);
        assertAllowedKeys(option, ALLOWED_OPTION_KEYS, `字段“${field.name}”的选项`);
      }
    }
    if (typeof field.id === "string") fieldIds.add(field.id);
  }

  for (const record of raw.records) {
    if (!isRecord(record)) throw new Error("存在无效记录");
    assertAllowedKeys(record, ALLOWED_RECORD_KEYS, "记录");
  }

  for (const view of raw.views) {
    if (!isRecord(view) || typeof view.type !== "string" || typeof view.name !== "string") {
      throw new Error("存在无效视图");
    }
    if (!(BASIC_VIEW_TYPES as readonly string[]).includes(view.type)) {
      throw new Error(`视图“${view.name}”是 Basic 不支持的视图，文件已进入保护性只读模式`);
    }
    assertAllowedKeys(view, ALLOWED_VIEW_KEYS[view.type as DuoweiViewType], `视图“${view.name}”`);
    if (Array.isArray(view.sorts) && view.sorts.length > 1) {
      throw new Error(`视图“${view.name}”包含多字段排序，Basic 将保护性只读`);
    }
  }

  if (raw.meta !== undefined) {
    if (!isRecord(raw.meta)) throw new Error("文件元数据无效");
    assertAllowedKeys(raw.meta, ALLOWED_META_KEYS, "文件元数据");
  }
}

function assertAllowedKeys(value: Record<string, unknown>, allowed: string[], label: string): void {
  const allowedSet = new Set(allowed);
  const unsupported = Object.keys(value).filter((key) => !allowedSet.has(key));
  if (unsupported.length) {
    throw new Error(`${label}包含 Basic 不支持的配置（${unsupported.join("、")}），文件已进入保护性只读模式`);
  }
}

/* -------------------------------------------------------------------------- */
/* 宽松解析：用于生成可展示模型（Basic 自己写出的文件走这里；只读文件仅用于查看）      */
/* -------------------------------------------------------------------------- */

function normalizeDuoweiDocument(raw: unknown, fallbackName: string): { document: DuoweiDocument; repaired: boolean; error?: string } {
  if (!isRecord(raw)) {
    return { document: createBlankDuoweiDocument(fallbackName), repaired: true, error: "文件内容不是对象" };
  }

  const now = new Date().toISOString();
  const fields = normalizeFields(raw.fields);
  const records = normalizeRecords(raw.records, fields);
  const views = normalizeViews(raw.views, fields);
  const metaRaw = isRecord(raw.meta) ? raw.meta : {};
  const createdAt = typeof metaRaw.createdAt === "string" ? metaRaw.createdAt : now;
  const updatedAt = typeof metaRaw.updatedAt === "string" ? metaRaw.updatedAt : now;

  const document: DuoweiDocument = {
    schemaVersion: 1,
    id: typeof raw.id === "string" ? raw.id : createId("tbl"),
    name: typeof raw.name === "string" && raw.name.trim() ? raw.name : fallbackName,
    fields,
    records,
    views,
    activeViewId: typeof raw.activeViewId === "string" ? raw.activeViewId : undefined,
    meta: { createdAt, updatedAt }
  };

  return {
    document,
    repaired: raw.schemaVersion !== 1 || !Array.isArray(raw.fields) || !Array.isArray(raw.records) || !Array.isArray(raw.views)
  };
}

function normalizeFields(raw: unknown): DuoweiField[] {
  if (!Array.isArray(raw)) return [createDuoweiField("text", "标题", 240)];

  const fields: DuoweiField[] = [];
  const seen = new Set<string>();
  for (const item of raw) {
    if (!isRecord(item)) continue;
    const id = typeof item.id === "string" && item.id ? item.id : createId("fld");
    if (seen.has(id)) continue;
    seen.add(id);
    const type = normalizeFieldType(item.type);
    const width = Number(item.width);
    const field: DuoweiField = {
      id,
      name: typeof item.name === "string" && item.name.trim() ? item.name : "字段",
      type,
      required: item.required === true,
      width: Number.isFinite(width) ? clamp(width, 72, 640) : defaultFieldWidth(type)
    };
    if (typeof item.syncKey === "string" && item.syncKey.trim()) {
      field.syncKey = item.syncKey.trim();
    }
    if ((type === "singleSelect" || type === "multiSelect") && Array.isArray(item.options)) {
      field.options = normalizeOptions(item.options);
    }
    fields.push(field);
  }

  return fields.length > 0 ? fields : [createDuoweiField("text", "标题", 240)];
}

function normalizeOptions(raw: unknown[]): DuoweiSelectOption[] {
  const options: DuoweiSelectOption[] = [];
  const seen = new Set<string>();
  for (const item of raw) {
    if (!isRecord(item)) continue;
    const id = typeof item.id === "string" && item.id ? item.id : createId("opt");
    if (seen.has(id)) continue;
    seen.add(id);
    options.push({
      id,
      name: typeof item.name === "string" && item.name.trim() ? item.name : "选项",
      color: typeof item.color === "string" ? item.color : undefined
    });
  }
  return options;
}

function normalizeRecords(raw: unknown, fields: DuoweiField[]): DuoweiRecord[] {
  void fields;
  if (!Array.isArray(raw)) return [];

  const records: DuoweiRecord[] = [];
  const seen = new Set<string>();
  for (const item of raw) {
    if (!isRecord(item)) continue;
    const id = typeof item.id === "string" && item.id ? item.id : createId("rec");
    if (seen.has(id)) continue;
    seen.add(id);
    const now = new Date().toISOString();
    records.push({
      id,
      values: isRecord(item.values) ? { ...item.values } : {},
      notePath: typeof item.notePath === "string" ? item.notePath : null,
      createdAt: typeof item.createdAt === "string" ? item.createdAt : now,
      updatedAt: typeof item.updatedAt === "string" ? item.updatedAt : now
    });
  }
  return records;
}

function normalizeViews(raw: unknown, fields: DuoweiField[]): DuoweiViewConfig[] {
  const defaultView = createDefaultGridView(fields);
  const defaultKanban = createDefaultKanbanView(fields);
  const defaultGallery = createDefaultGalleryView(fields);
  if (!Array.isArray(raw)) return [defaultView, defaultKanban, defaultGallery];

  const fieldIds = new Set(fields.map((field) => field.id));
  const views: DuoweiViewConfig[] = [];
  for (const item of raw) {
    if (!isRecord(item)) continue;
    // 宽松展示：跳过 Basic 不支持的视图类型（只读文件时它们仍保存在原始 JSON 中）。
    if (item.type !== "grid" && item.type !== "kanban" && item.type !== "gallery") continue;
    const fieldOrder = Array.isArray(item.fieldOrder)
      ? item.fieldOrder.filter((fieldId): fieldId is string => typeof fieldId === "string" && fieldIds.has(fieldId))
      : [];
    const orderedSet = new Set(fieldOrder);
    const hiddenFields = Array.isArray(item.hiddenFields)
      ? item.hiddenFields.filter((fieldId): fieldId is string => typeof fieldId === "string" && fieldIds.has(fieldId))
      : [];
    const common = {
      id: typeof item.id === "string" ? item.id : createId("view"),
      name:
        typeof item.name === "string" && item.name.trim()
          ? item.name
          : item.type === "kanban"
            ? "看板"
            : item.type === "gallery"
              ? "画廊"
              : "表格",
      fieldOrder: [...fieldOrder, ...fields.map((field) => field.id).filter((fieldId) => !orderedSet.has(fieldId))],
      hiddenFields,
      sorts: normalizeSorts(item.sorts, fieldIds),
      filters: normalizeFilters(item.filters, fieldIds)
    };
    if (item.type === "kanban") {
      views.push({
        ...common,
        type: "kanban",
        groupFieldId: typeof item.groupFieldId === "string" && fieldIds.has(item.groupFieldId) ? item.groupFieldId : defaultKanban.groupFieldId,
        titleFieldId: typeof item.titleFieldId === "string" && fieldIds.has(item.titleFieldId) ? item.titleFieldId : defaultKanban.titleFieldId,
        cardFieldIds: Array.isArray(item.cardFieldIds)
          ? item.cardFieldIds.filter((fieldId): fieldId is string => typeof fieldId === "string" && fieldIds.has(fieldId))
          : defaultKanban.cardFieldIds
      });
    } else if (item.type === "gallery") {
      const titleFieldId = typeof item.titleFieldId === "string" && fieldIds.has(item.titleFieldId) ? item.titleFieldId : defaultGallery.titleFieldId;
      const coverFieldId = typeof item.coverFieldId === "string" && fieldIds.has(item.coverFieldId) ? item.coverFieldId : defaultGallery.coverFieldId;
      views.push({
        ...common,
        type: "gallery",
        coverFieldId,
        titleFieldId,
        cardFieldIds: Array.isArray(item.cardFieldIds)
          ? item.cardFieldIds.filter((fieldId): fieldId is string => typeof fieldId === "string" && fieldIds.has(fieldId))
          : defaultGallery.cardFieldIds
      });
    } else {
      views.push({
        ...common,
        type: "grid",
        rowHeight:
          item.rowHeight === "compact" || item.rowHeight === "comfortable" || item.rowHeight === "default"
            ? item.rowHeight
            : "default",
        frozenFieldCount: Number.isFinite(Number(item.frozenFieldCount))
          ? Math.max(0, Math.floor(Number(item.frozenFieldCount)))
          : 1
      });
    }
  }

  if (!views.some((view) => view.type === "grid")) views.unshift(defaultView);
  if (!views.some((view) => view.type === "kanban")) views.push(defaultKanban);
  if (!views.some((view) => view.type === "gallery")) views.push(defaultGallery);
  return views.length > 0 ? views : [defaultView, defaultKanban, defaultGallery];
}

function normalizeSorts(raw: unknown, fieldIds: Set<string>): DuoweiSortRule[] {
  if (!Array.isArray(raw)) return [];
  return raw.filter((item): item is DuoweiSortRule => {
    return (
      isRecord(item) &&
      typeof item.fieldId === "string" &&
      fieldIds.has(item.fieldId) &&
      (item.direction === "asc" || item.direction === "desc")
    );
  });
}

function normalizeFilters(raw: unknown, fieldIds: Set<string>): DuoweiFilterRule[] {
  if (!Array.isArray(raw)) return [];
  return raw.filter((item): item is DuoweiFilterRule => {
    return (
      isRecord(item) &&
      typeof item.fieldId === "string" &&
      fieldIds.has(item.fieldId) &&
      (item.op === "contains" || item.op === "equals" || item.op === "empty" || item.op === "notEmpty") &&
      typeof item.value === "string"
    );
  });
}

function normalizeFieldType(value: unknown): DuoweiFieldType {
  return (BASIC_FIELD_TYPES as readonly string[]).includes(value as string) ? (value as DuoweiFieldType) : "text";
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}
