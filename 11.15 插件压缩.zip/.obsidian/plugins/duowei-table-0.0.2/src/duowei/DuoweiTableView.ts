import { Menu, Modal, Notice, TFile, TextFileView, normalizePath, setIcon, type App, type IconName, type WorkspaceLeaf } from "obsidian";
import { computeVirtualWindow } from "../grid/virtualWindow";
import { DEFAULT_SETTINGS, type MultiTableSettings } from "../settings/SettingsTab";
import { detectDelimitedKind, parseDelimited, type DelimitedKind } from "./delimited";
import {
  applyConflictResolutions,
  computeCellConflicts,
  conflictRecordLabel,
  conflictValueLabel,
  MAX_MERGEABLE_CELL_CONFLICTS,
  type CellConflictItem,
  type ConflictResolutions,
  type ConflictSide,
  type RecordConflictItem
} from "./conflictMerge";
import {
  DUOWEI_EXTENSION,
  DUOWEI_VIEW_TYPE,
  cloneDuoweiDocument,
  createDefaultGalleryView,
  createDefaultGridView,
  createDefaultKanbanView,
  createDuoweiField,
  createDuoweiRecord,
  createId,
  defaultFieldWidth,
  nextOptionColor,
  parseDuoweiDocument,
  serializeDuoweiDocument,
  touchDuoweiDocument,
  type DuoweiDocument,
  type DuoweiField,
  type DuoweiFieldType,
  type DuoweiFilterRule,
  type DuoweiGalleryViewConfig,
  type DuoweiGridViewConfig,
  type DuoweiKanbanViewConfig,
  type DuoweiRecord,
  type DuoweiSortRule,
  type DuoweiViewConfig,
  type DuoweiViewType,
  type ParsedDuoweiDocument
} from "./schema";

interface ActiveCell {
  recordId: string;
  fieldId: string;
  rowIndex: number;
  columnIndex: number;
}

interface SelectionRange {
  anchorRow: number;
  anchorColumn: number;
  focusRow: number;
  focusColumn: number;
}

interface NormalizedSelectionRange {
  rowStart: number;
  rowEnd: number;
  columnStart: number;
  columnEnd: number;
}

interface FillDragState {
  baseRange: NormalizedSelectionRange;
  direction: "down" | "right" | null;
  targetRowEnd: number;
  targetColumnEnd: number;
}

interface ColumnDragState {
  sourceIndex: number;
  targetInsertIndex: number | null;
}

interface RowDragState {
  sourceIndex: number;
  targetInsertIndex: number | null;
}

interface SnapshotOperation {
  label: string;
  before: DuoweiDocument;
  after: DuoweiDocument;
}

interface SyncResult {
  synced: number;
  skipped: number;
  failed: number;
  items: SyncLogItem[];
}

interface SyncLogItem {
  recordId: string;
  title: string;
  notePath: string | null;
  status: "synced" | "skipped" | "failed";
  message: string;
  at: string;
}

export interface OperationLogItem {
  id: string;
  at: string;
  type: "edit" | "undo" | "redo" | "sync" | "conflict" | "import" | "export" | "system";
  label: string;
  detail: string;
  status: "ok" | "warning" | "error";
}

interface BackupFileInfo {
  file: TFile;
  kind: "auto" | "conflict";
  label: string;
  createdLabel: string;
  sizeLabel: string;
  recordCount: number | null;
  fieldCount: number | null;
  updatedAt: string | null;
  parseError: string | null;
}

interface DocumentDiffSummary {
  leftTitle: string;
  rightTitle: string;
  addedFields: number;
  removedFields: number;
  changedFields: number;
  addedRecords: number;
  removedRecords: number;
  changedRecords: number;
  changedValues: number;
  notePathChanges: number;
  viewChanges: number;
  leftUpdatedAt: string | null;
  rightUpdatedAt: string | null;
  error: string | null;
}

interface DuoweiTableViewOptions {
  getSettings?: () => MultiTableSettings;
  getOperationLog?: () => OperationLogItem[];
  appendOperationLog?: (item: OperationLogItem) => void;
  clearOperationLog?: () => void;
}

interface FieldMigrationImpact {
  nonEmpty: number;
  changed: number;
  emptied: number;
  failed: number;
  items: FieldMigrationPreviewItem[];
}

interface FieldMigrationPreviewItem {
  recordId: string;
  rowIndex: number;
  before: unknown;
  after?: unknown;
  error?: string;
}

interface ImportColumnPlan {
  sourceIndex: number;
  sourceName: string;
  target: "existing" | "new";
  fieldId?: string;
  fieldName: string;
  type: DuoweiFieldType;
  enabled: boolean;
}

interface ImportPreviewError {
  rowIndex: number;
  columnName: string;
  value: string;
  message: string;
}

interface ImportPreview {
  rows: string[][];
  dataRows: string[][];
  columns: ImportColumnPlan[];
  errors: ImportPreviewError[];
  validRows: number;
  sourceName: string;
}

interface BulkEditPreviewItem {
  recordId: string;
  rowIndex: number;
  fieldId: string;
  fieldName: string;
  columnIndex: number;
  before: unknown;
  after?: unknown;
  beforeDisplay: string;
  afterDisplay: string;
  error?: string;
}

interface BulkEditPreview {
  total: number;
  changed: number;
  unchanged: number;
  failed: number;
  items: BulkEditPreviewItem[];
}

interface CommitResult {
  ok: boolean;
  message?: string;
}

/** 页面预览（Page preview）核心插件里本插件的来源标识。 */
export const DUOWEI_HOVER_SOURCE = "duowei-table";

const FIELD_TYPES: Array<{ type: DuoweiFieldType; label: string; icon: string }> = [
  { type: "text", label: "文本", icon: "type" },
  { type: "number", label: "数字", icon: "hash" },
  { type: "checkbox", label: "勾选", icon: "check-square" },
  { type: "date", label: "日期", icon: "calendar" },
  { type: "singleSelect", label: "单选", icon: "circle-dot" },
  { type: "multiSelect", label: "多选", icon: "list-checks" },
  { type: "email", label: "邮箱", icon: "mail" },
  { type: "noteLink", label: "笔记链接", icon: "file-text" },
  { type: "attachment", label: "附件", icon: "paperclip" }
];

export class DuoweiTableView extends TextFileView {
  private readonly rootEl: HTMLDivElement;
  private readonly commandBarEl: HTMLDivElement;
  private readonly scrollerEl: HTMLDivElement;
  private readonly headerEl: HTMLDivElement;
  private readonly bodyEl: HTMLDivElement;
  private readonly addRowEl: HTMLDivElement;
  private readonly footerEl: HTMLDivElement;
  private readonly countEl: HTMLSpanElement;
  private readonly statusEl: HTMLSpanElement;
  private readonly searchInputEl: HTMLInputElement;
  private readonly undoButtonEl: HTMLButtonElement;
  private readonly redoButtonEl: HTMLButtonElement;
  private readonly viewManagerButtonEl: HTMLButtonElement;
  private readonly gridViewButtonEl: HTMLButtonElement;
  private readonly kanbanViewButtonEl: HTMLButtonElement;
  private readonly galleryViewButtonEl: HTMLButtonElement;
  private readonly fieldsButtonEl: HTMLButtonElement;
  private readonly filterButtonEl: HTMLButtonElement;
  private readonly sortButtonEl: HTMLButtonElement;
  private readonly densityButtonEl: HTMLButtonElement;
  private readonly freezeButtonEl: HTMLButtonElement;

  private documentModel: DuoweiDocument;
  private visibleRecords: DuoweiRecord[] = [];
  private activeCell: ActiveCell | null = null;
  private selectionRange: SelectionRange | null = null;
  private dragSelecting = false;
  private fillDrag: FillDragState | null = null;
  private columnDrag: ColumnDragState | null = null;
  private rowDrag: RowDragState | null = null;
  private renderFrame = 0;
  private lastWindowKey = "";
  private quickSearch = "";
  private undoStack: SnapshotOperation[] = [];
  private redoStack: SnapshotOperation[] = [];
  private detailRecordId: string | null = null;
  private detailEl: HTMLDivElement | null = null;
  private syncLog: SyncLogItem[] = [];
  private operationLog: OperationLogItem[] = [];
  private lastPersistedData = "";
  private lastConflictSignature: string | null = null;
  private lastConflictBackupPath: string | null = null;
  private lastAutoBackupAt = 0;
  /** 非 null 时：文件含 Basic 不支持的内容，进入保护性只读，禁止编辑且绝不改写原文件。 */
  private readOnlyReason: string | null = null;
  private readOnlyBannerEl: HTMLDivElement | null = null;

  constructor(leaf: WorkspaceLeaf, private readonly options: DuoweiTableViewOptions = {}) {
    super(leaf);
    this.navigation = true;
    this.documentModel = createDocumentForView("未命名多维表格");

    this.contentEl.addClass("mt-duowei-content");
    this.rootEl = this.contentEl.createDiv({ cls: "mt-view mt-view--duowei" });
    this.commandBarEl = this.rootEl.createDiv({ cls: "mt-command-bar" });

    const primary = this.commandBarEl.createDiv({
      cls: "mt-command-bar__group mt-command-bar__group--primary"
    });
    this.createCommandButton(primary, "plus", "行", "新增行", () => this.addRow());
    this.createCommandButton(primary, "columns-3", "列", "新增列", () => this.addColumn());
    this.createCommandButton(primary, "trash-2", "删除", "删除选中的行或列", () => this.deleteSelection());

    const viewSwitch = this.commandBarEl.createDiv({ cls: "mt-command-bar__group mt-duowei-view-switch" });
    this.viewManagerButtonEl = this.createCommandButton(viewSwitch, "panel-top", "视图", "管理视图", (event) =>
      this.openViewManagerMenu(event.currentTarget as HTMLElement)
    );
    this.gridViewButtonEl = this.createCommandButton(viewSwitch, "table-2", "表格", "切换到表格视图", () =>
      this.switchView("grid")
    );
    this.kanbanViewButtonEl = this.createCommandButton(viewSwitch, "columns-3", "看板", "切换到看板视图", () =>
      this.switchView("kanban")
    );
    this.galleryViewButtonEl = this.createCommandButton(viewSwitch, "layout-grid", "画廊", "切换到画廊视图", () =>
      this.switchView("gallery")
    );

    const tools = this.commandBarEl.createDiv({ cls: "mt-command-bar__group mt-command-bar__group--tools" });
    this.fieldsButtonEl = this.createCommandButton(tools, "table-properties", "字段", "字段显示", (event) =>
      this.openFieldsPanel(event.currentTarget as HTMLElement)
    );
    this.filterButtonEl = this.createCommandButton(tools, "list-filter", "筛选", "筛选记录", (event) =>
      this.openFilterPanel(event.currentTarget as HTMLElement)
    );
    this.sortButtonEl = this.createCommandButton(tools, "arrow-up-down", "排序", "排序记录", (event) =>
      this.openSortPanel(event.currentTarget as HTMLElement)
    );
    this.densityButtonEl = this.createCommandButton(tools, "rows-3", "行高", "设置行高", (event) =>
      this.openDensityMenu(event.currentTarget as HTMLElement)
    );
    this.freezeButtonEl = this.createCommandButton(tools, "panel-left", "冻结", "冻结前几列", (event) =>
      this.openFreezeMenu(event.currentTarget as HTMLElement)
    );

    const editGroup = this.commandBarEl.createDiv({ cls: "mt-command-bar__group" });
    this.undoButtonEl = this.createIconButton(editGroup, "undo-2", "撤销", () => this.undo());
    this.redoButtonEl = this.createIconButton(editGroup, "redo-2", "重做", () => this.redo());

    const end = this.commandBarEl.createDiv({ cls: "mt-command-bar__group mt-command-bar__group--end" });
    const searchWrap = end.createDiv({ cls: "mt-command-bar__search" });
    this.createIconButton(searchWrap, "search", "搜索", () => this.searchInputEl.focus());
    this.searchInputEl = searchWrap.createEl("input", {
      cls: "mt-command-search",
      type: "search",
      attr: { placeholder: "搜索当前表格", "aria-label": "搜索当前表格" }
    });
    this.searchInputEl.addEventListener("input", () => {
      this.quickSearch = this.searchInputEl.value.trim().toLowerCase();
      this.recomputeRecords();
      this.renderAll(true);
    });

    const moreButton = this.createIconButton(end, "more-horizontal", "更多操作", (event) =>
      this.openOverflowMenu(event.currentTarget as HTMLElement)
    );
    moreButton.addClass("mt-command-button--icon");

    this.scrollerEl = this.rootEl.createDiv({ cls: "mt-grid-scroller" });
    this.scrollerEl.tabIndex = 0;
    this.scrollerEl.setAttr("role", "grid");
    this.scrollerEl.setAttr("aria-label", "多维表格");
    this.headerEl = this.scrollerEl.createDiv({ cls: "mt-grid-header", attr: { role: "row" } });
    this.bodyEl = this.scrollerEl.createDiv({ cls: "mt-grid-body" });
    this.addRowEl = this.scrollerEl.createDiv({
      cls: "mt-grid-add-row",
      attr: { role: "button", tabindex: "0", "aria-label": "新增行" }
    });
    const addInner = this.addRowEl.createDiv({ cls: "mt-grid-add-row__inner" });
    setIcon(addInner.createSpan({ cls: "mt-grid-add-row__icon", attr: { "aria-hidden": "true" } }), "plus");
    addInner.createSpan({ cls: "mt-grid-add-row__label", text: "新增行" });
    this.addRowEl.addEventListener("click", () => this.addRow());
    this.addRowEl.addEventListener("keydown", (event) => {
      const key = (event as KeyboardEvent).key;
      if (key === "Enter" || key === " ") {
        event.preventDefault();
        this.addRow();
      }
    });

    this.footerEl = this.rootEl.createDiv({ cls: "mt-grid-footer" });
    this.footerEl.createSpan({
      cls: "mt-grid-footer__hint",
      text: "Enter 编辑/下移 · Tab 右移 · Shift+方向键选区 · Ctrl+D/R 填充 · Ctrl+C/V 复制粘贴 · Ctrl+Z 撤销"
    });
    const footerEnd = this.footerEl.createDiv({ cls: "mt-grid-footer__end" });
    this.countEl = footerEnd.createSpan({ cls: "mt-command-bar__count" });
    this.statusEl = footerEnd.createSpan({ cls: "mt-save-status", text: "已保存" });
    this.statusEl.dataset.state = "saved";
    this.statusEl.setAttr("aria-live", "polite");
    this.statusEl.addEventListener("click", () => {
      if (this.statusEl.dataset.state === "conflict") this.openConflictRecoveryPanel(this.statusEl);
    });

    this.registerDomEvent(this.scrollerEl, "scroll", () => this.scheduleRows());
    this.registerDomEvent(this.scrollerEl, "keydown", (event) => this.handleGridKeydown(event));
    this.registerDomEvent(this.scrollerEl, "copy", (event) => this.handleCopy(event));
    this.registerDomEvent(this.scrollerEl, "paste", (event) => this.handlePaste(event));
    this.registerDomEvent(this.scrollerEl, "pointerup", () => this.stopDragSelection());
    this.registerDomEvent(this.scrollerEl, "pointercancel", () => this.stopDragSelection());
    this.registerDomEvent(this.scrollerEl, "contextmenu", (event) => this.openCellContextMenu(event));

    const observer = new ResizeObserver(() => this.renderAll(true));
    observer.observe(this.scrollerEl);
    this.register(() => observer.disconnect());
    this.register(() => {
      if (this.renderFrame) this.rootEl.win.cancelAnimationFrame(this.renderFrame);
    });

    this.recomputeRecords();
    this.renderAll(true);
  }

  getViewType(): string {
    return DUOWEI_VIEW_TYPE;
  }

  getDisplayText(): string {
    return this.file?.basename ?? this.documentModel.name;
  }

  getIcon(): IconName {
    return "table-properties";
  }

  getViewData(): string {
    // 保护性只读：绝不用解析后的模型覆盖原文件，原样返回磁盘内容。
    if (this.readOnlyReason) return this.lastPersistedData;
    this.refreshFormulaValues(this.documentModel);
    return serializeDuoweiDocument(this.documentModel);
  }

  setViewData(data: string, clear: boolean): void {
    this.lastPersistedData = data;
    this.lastConflictSignature = null;
    this.lastConflictBackupPath = null;
    const name = this.file?.basename ?? "未命名多维表格";
    const parsed: ParsedDuoweiDocument = data.trim()
      ? parseDuoweiDocument(data, name)
      : { document: createDocumentForView(name), repaired: true, error: undefined, readOnly: false };
    this.readOnlyReason = parsed.readOnly ? parsed.readOnlyReason ?? "文件包含 Basic 不支持的内容" : null;
    this.documentModel = parsed.document;
    this.ensureActiveView();
    this.refreshFormulaValues(this.documentModel);
    this.recomputeRecords();
    this.undoStack = clear ? [] : this.undoStack;
    this.redoStack = clear ? [] : this.redoStack;
    this.activeCell = this.firstCell();
    this.selectionRange = this.activeCell
      ? {
          anchorRow: this.activeCell.rowIndex,
          anchorColumn: this.activeCell.columnIndex,
          focusRow: this.activeCell.rowIndex,
          focusColumn: this.activeCell.columnIndex
        }
      : null;
    if (this.readOnlyReason) {
      // 只读文件不触发任何自动保存，避免抹掉 Pro 独有数据。
      this.setStatus("只读保护", "conflict");
    } else if (parsed.repaired) {
      this.setStatus(parsed.error ? `已修复：${parsed.error}` : "已初始化", "saving");
      this.requestSave();
    } else {
      this.setStatus("已保存", "saved");
    }
    this.renderAll(true);
    this.updateReadOnlyBanner();
  }

  private updateReadOnlyBanner(): void {
    if (!this.readOnlyReason) {
      this.readOnlyBannerEl?.remove();
      this.readOnlyBannerEl = null;
      this.rootEl.removeClass("is-readonly-protected");
      return;
    }
    this.rootEl.addClass("is-readonly-protected");
    if (!this.readOnlyBannerEl) {
      this.readOnlyBannerEl = this.rootEl.createDiv({ cls: "mt-readonly-banner" });
      this.rootEl.prepend(this.readOnlyBannerEl);
    }
    this.readOnlyBannerEl.empty();
    const icon = this.readOnlyBannerEl.createSpan({ cls: "mt-readonly-banner__icon", attr: { "aria-hidden": "true" } });
    setIcon(icon, "shield-alert");
    const text = this.readOnlyBannerEl.createDiv({ cls: "mt-readonly-banner__text" });
    text.createEl("strong", { text: "保护性只读模式" });
    text.createEl("div", { text: `${this.readOnlyReason}。可查看但无法编辑，原文件不会被改写。请用完整版打开以继续编辑。` });
  }

  clear(): void {
    this.documentModel = createDocumentForView("未命名多维表格");
    this.visibleRecords = [];
    this.activeCell = null;
    this.selectionRange = null;
    this.undoStack = [];
    this.redoStack = [];
    this.closeRecordDetail();
    this.bodyEl.empty();
    this.headerEl.empty();
  }

  async save(clear?: boolean): Promise<void> {
    // 保护性只读：不写回文件，避免丢失 Basic 不支持的数据。
    if (this.readOnlyReason) return;
    const currentData = this.getViewData();
    const conflict = await this.detectExternalFileChange(currentData);
    if (conflict) {
      const signature = conflictSignature(this.file?.path ?? "", conflict.diskData, currentData);
      let backupPath = this.lastConflictBackupPath;
      if (this.lastConflictSignature !== signature || !backupPath) {
        backupPath = await this.createBackupFile("conflict", currentData);
        this.lastConflictSignature = signature;
        this.lastConflictBackupPath = backupPath;
        this.addOperationLog("conflict", "保存冲突备份", backupPath, "warning");
        new Notice(`检测到外部修改，已把当前编辑保存为冲突备份：${backupPath}`, 8000);
      }
      this.setStatus("外部修改，已保存冲突备份", "conflict");
      return;
    }
    await this.createAutoBackupBeforeOverwrite(currentData);
    await super.save(clear);
    this.lastPersistedData = currentData;
    this.lastConflictSignature = null;
    this.lastConflictBackupPath = null;
    this.setStatus("已保存", "saved");
  }

  private async detectExternalFileChange(currentData: string): Promise<{ diskData: string } | null> {
    const file = this.file;
    if (!file) return null;
    let diskData: string;
    try {
      diskData = await this.app.vault.read(file);
    } catch (error) {
      const message = error instanceof Error ? error.message : "保存前读取原文件失败";
      this.setStatus("保存前读取失败", "error");
      new Notice(message, 5000);
      return null;
    }
    if (diskData === currentData) {
      this.lastPersistedData = diskData;
      return null;
    }
    if (diskData !== this.lastPersistedData) return { diskData };
    return null;
  }

  private async createBackupFile(kind: "auto" | "conflict", data: string): Promise<string> {
    const file = this.file;
    const kindLabel = backupKindLabel(kind);
    const fallbackName = `${this.documentModel.name || "多维表格"}.${kindLabel}.${backupTimestamp()}.${DUOWEI_EXTENSION}`;
    if (!file) {
      const path = await this.uniqueVaultPath(fallbackName);
      await this.app.vault.create(path, data);
      return path;
    }
    const folder = file.parent?.path && file.parent.path !== "/" ? file.parent.path : "";
    const extension = file.extension || DUOWEI_EXTENSION;
    const path = await this.uniqueVaultPath(
      normalizePath(`${folder ? `${folder}/` : ""}${file.basename}.${kindLabel}.${backupTimestamp()}.${extension}`)
    );
    await this.app.vault.create(path, data);
    return path;
  }

  private async createAutoBackupBeforeOverwrite(currentData: string): Promise<void> {
    const file = this.file;
    const settings = this.duoweiSettings();
    if (!file || !settings.duoweiAutoBackupEnabled) return;
    if (!this.lastPersistedData || this.lastPersistedData === currentData) return;
    const now = Date.now();
    const intervalMs = settings.duoweiAutoBackupIntervalMinutes * 60 * 1000;
    if (this.lastAutoBackupAt > 0 && now - this.lastAutoBackupAt < intervalMs) return;
    try {
      const backupPath = await this.createBackupFile("auto", this.lastPersistedData);
      this.lastAutoBackupAt = now;
      const removed = await this.cleanupAutoBackups(settings.duoweiAutoBackupRetention);
      const detail = removed > 0 ? `${backupPath}，已清理 ${removed} 个旧自动备份` : backupPath;
      this.addOperationLog("system", "自动备份", detail);
    } catch (error) {
      const message = error instanceof Error ? error.message : "自动备份失败";
      this.addOperationLog("system", "自动备份失败", message, "error");
      new Notice(`自动备份失败：${message}`, 5000);
      console.error("[多维表格] 自动备份失败", error);
    }
  }

  private async cleanupAutoBackups(retention: number): Promise<number> {
    const backups = await this.listBackupFiles("auto");
    const toDelete = backups.slice(Math.max(1, retention));
    let removed = 0;
    for (const backup of toDelete) {
      try {
        await this.app.vault.delete(backup.file);
        removed += 1;
      } catch (error) {
        console.error("[多维表格] 清理旧自动备份失败", backup.file.path, error);
      }
    }
    return removed;
  }

  private async listBackupFiles(kind?: BackupFileInfo["kind"]): Promise<BackupFileInfo[]> {
    const file = this.file;
    if (!file) return [];
    const folderPath = file.parent?.path && file.parent.path !== "/" ? file.parent.path : "";
    const prefixes = backupPrefixes(file.basename, kind);
    const files = this.app.vault
      .getFiles()
      .filter((item) => item.extension === DUOWEI_EXTENSION)
      .filter((item) => {
        const sameFolder = (item.parent?.path && item.parent.path !== "/" ? item.parent.path : "") === folderPath;
        return sameFolder && prefixes.some((prefix) => item.basename.startsWith(prefix));
      })
      .sort((a, b) => b.stat.mtime - a.stat.mtime);
    const results: BackupFileInfo[] = [];
    for (const backup of files) {
      results.push(await this.backupFileInfo(backup, backupKindFromName(backup.basename)));
    }
    return results;
  }

  private async backupFileInfo(file: TFile, kind: BackupFileInfo["kind"]): Promise<BackupFileInfo> {
    let recordCount: number | null = null;
    let fieldCount: number | null = null;
    let updatedAt: string | null = null;
    let parseError: string | null = null;
    try {
      const data = await this.app.vault.read(file);
      const parsed = parseDuoweiDocument(data, file.basename);
      recordCount = parsed.document.records.length;
      fieldCount = parsed.document.fields.length;
      updatedAt = parsed.document.meta.updatedAt;
      parseError = parsed.repaired ? parsed.error ?? "备份内容需要修复" : null;
    } catch (error) {
      parseError = error instanceof Error ? error.message : "读取备份失败";
    }
    return {
      file,
      kind,
      label: backupDisplayName(file, this.file?.basename ?? ""),
      createdLabel: formatDateTimeLabel(new Date(file.stat.mtime)),
      sizeLabel: formatByteSize(file.stat.size),
      recordCount,
      fieldCount,
      updatedAt,
      parseError
    };
  }

  private async uniqueVaultPath(path: string): Promise<string> {
    const normalized = normalizePath(path);
    if (!this.app.vault.getAbstractFileByPath(normalized)) return normalized;
    const dot = normalized.lastIndexOf(".");
    const base = dot >= 0 ? normalized.slice(0, dot) : normalized;
    const extension = dot >= 0 ? normalized.slice(dot) : "";
    let index = 2;
    while (this.app.vault.getAbstractFileByPath(`${base}-${index}${extension}`)) index += 1;
    return `${base}-${index}${extension}`;
  }

  private openConflictRecoveryPanel(anchor: HTMLElement): void {
    const panel = this.createPanel(anchor, "冲突恢复");
    panel.root.addClass("mt-panel--conflict");
    const body = panel.body;
    const footer = panel.footer;
    const filePath = this.file?.path ?? "当前表格";
    const backupPath = this.lastConflictBackupPath;

    body.createDiv({
      cls: "mt-conflict-message",
      text: backupPath
        ? "检测到原文件已被外部修改。当前编辑已保存为冲突备份，原文件没有被覆盖。"
        : "当前没有待处理的冲突备份。"
    });
    const detail = body.createDiv({ cls: "mt-conflict-detail" });
    this.renderConflictDetail(detail, "原文件", filePath);
    this.renderConflictDetail(detail, "当前编辑备份", backupPath ?? "暂无");

    if (!backupPath) {
      footer.createDiv({ cls: "mt-summary-note", text: "发生保存冲突后，这里会显示可恢复的备份文件。" });
      return;
    }
    const diffEl = body.createDiv({ cls: "mt-conflict-diff" });
    diffEl.createDiv({ cls: "mt-conflict-diff__loading", text: "正在比较原文件和备份..." });
    void this.renderFileDiff(diffEl, backupPath, "原文件", "当前编辑备份");

    const mergeEl = body.createDiv({ cls: "mt-conflict-merge" });
    mergeEl.createDiv({ cls: "mt-conflict-diff__loading", text: "正在准备逐单元格合并..." });
    void this.renderCellMergeSection(mergeEl, panel.root, backupPath);

    const actions = footer.createDiv({ cls: "mt-conflict-actions" });
    const openBackup = actions.createEl("button", { cls: "mt-dialog__button", text: "打开备份", attr: { type: "button" } });
    openBackup.addEventListener("click", () => void this.openConflictBackup(backupPath));
    const keepDisk = actions.createEl("button", { cls: "mt-dialog__button", text: "保留原文件", attr: { type: "button" } });
    keepDisk.addEventListener("click", () => void this.keepDiskVersion(panel.root));
    const useBackup = actions.createEl("button", {
      cls: "mt-dialog__button mt-dialog__button--primary",
      text: "用备份覆盖原文件",
      attr: { type: "button" }
    });
    useBackup.addEventListener("click", () => void this.restoreConflictBackup(panel.root, backupPath));
  }

  private async renderCellMergeSection(container: HTMLElement, panelRoot: HTMLElement, backupPath: string): Promise<void> {
    const file = this.file;
    container.empty();
    if (!file) {
      container.createDiv({ cls: "mt-conflict-diff__empty", text: "当前表格文件不可用，无法逐单元格合并。" });
      return;
    }
    const backup = this.app.vault.getAbstractFileByPath(backupPath);
    if (!(backup instanceof TFile)) {
      container.createDiv({ cls: "mt-conflict-diff__empty", text: "备份文件不存在，无法逐单元格合并。" });
      return;
    }
    let diskData: string;
    let localData: string;
    try {
      [diskData, localData] = await Promise.all([this.app.vault.read(file), this.app.vault.read(backup)]);
    } catch (error) {
      container.createDiv({ cls: "mt-conflict-diff__empty", text: error instanceof Error ? error.message : "读取失败" });
      return;
    }
    const diskParsed = parseDuoweiDocument(diskData, file.basename);
    const localParsed = parseDuoweiDocument(localData, backup.basename);
    if (diskParsed.repaired || localParsed.repaired) {
      container.createDiv({ cls: "mt-conflict-diff__empty", text: "原文件或备份内容需要修复，暂不支持逐单元格合并。" });
      return;
    }
    const diskDocument = diskParsed.document;
    const localDocument = localParsed.document;
    const diff = computeCellConflicts(diskDocument, localDocument);
    if (diff.truncated) {
      container.createDiv({
        cls: "mt-conflict-diff__empty",
        text: `冲突项超过 ${MAX_MERGEABLE_CELL_CONFLICTS} 个，逐单元格合并暂不可用，请使用下方“保留原文件”或“用备份覆盖原文件”。`
      });
      return;
    }
    const totalItems = diff.cellConflicts.length + diff.recordConflicts.length;
    if (totalItems === 0) {
      container.createDiv({ cls: "mt-conflict-diff__empty", text: "没有可逐项合并的差异。" });
      return;
    }

    const resolutions: ConflictResolutions = { cells: new Map(), records: new Map() };
    const controls: Array<(side: ConflictSide) => void> = [];

    const title = container.createDiv({ cls: "mt-conflict-diff__title" });
    title.createSpan({ text: `逐项冲突（${totalItems} 项），默认保留当前编辑` });

    const quickActions = container.createDiv({ cls: "mt-conflict-merge__quick-actions" });
    const keepAllLocal = quickActions.createEl("button", { cls: "mt-dialog__button", text: "全部保留当前编辑", attr: { type: "button" } });
    const keepAllDisk = quickActions.createEl("button", { cls: "mt-dialog__button", text: "全部保留原文件", attr: { type: "button" } });
    keepAllLocal.addEventListener("click", () => controls.forEach((select) => select("local")));
    keepAllDisk.addEventListener("click", () => controls.forEach((select) => select("disk")));

    const list = container.createDiv({ cls: "mt-conflict-merge__list" });
    const localFieldsById = new Map(localDocument.fields.map((field) => [field.id, field]));
    const diskFieldsById = new Map(diskDocument.fields.map((field) => [field.id, field]));
    const localRecordsById = new Map(localDocument.records.map((record) => [record.id, record]));
    const diskRecordsById = new Map(diskDocument.records.map((record) => [record.id, record]));

    const addMergeRow = (
      label: string,
      diskText: string,
      localText: string,
      onSelect: (side: ConflictSide) => void
    ): void => {
      const row = list.createDiv({ cls: "mt-conflict-merge__row" });
      row.createDiv({ cls: "mt-conflict-merge__label", text: label });
      const values = row.createDiv({ cls: "mt-conflict-merge__values" });
      const diskBtn = values.createEl("button", { cls: "mt-conflict-merge__choice", attr: { type: "button" }, text: diskText });
      const localBtn = values.createEl("button", {
        cls: "mt-conflict-merge__choice is-selected",
        attr: { type: "button" },
        text: localText
      });
      const select = (side: ConflictSide) => {
        onSelect(side);
        diskBtn.classList.toggle("is-selected", side === "disk");
        localBtn.classList.toggle("is-selected", side === "local");
      };
      diskBtn.addEventListener("click", () => select("disk"));
      localBtn.addEventListener("click", () => select("local"));
      controls.push(select);
    };

    for (const item of diff.cellConflicts) {
      const field = localFieldsById.get(item.fieldId) ?? diskFieldsById.get(item.fieldId);
      const record = localRecordsById.get(item.recordId);
      const recordLabel = record ? conflictRecordLabel(record, localDocument.fields, localDocument.records.indexOf(record)) : item.recordId;
      resolutions.cells.set(item.key, "local");
      addMergeRow(
        `${recordLabel} · ${item.fieldName}`,
        `原文件：${conflictValueLabel(item.diskValue, field)}`,
        `当前编辑：${conflictValueLabel(item.localValue, field)}`,
        (side) => resolutions.cells.set(item.key, side)
      );
    }

    for (const item of diff.recordConflicts) {
      const record = item.kind === "diskOnly" ? diskRecordsById.get(item.recordId) : localRecordsById.get(item.recordId);
      const fields = item.kind === "diskOnly" ? diskDocument.fields : localDocument.fields;
      const recordLabel = record ? conflictRecordLabel(record, fields, 0) : item.recordId;
      resolutions.records.set(item.key, "local");
      addMergeRow(
        item.kind === "diskOnly" ? `${recordLabel} · 原文件新增的记录` : `${recordLabel} · 当前编辑新增的记录`,
        item.kind === "diskOnly" ? "恢复此记录" : "丢弃此记录（按原文件）",
        item.kind === "diskOnly" ? "保持删除（按当前编辑）" : "保留此记录（按当前编辑）",
        (side) => resolutions.records.set(item.key, side)
      );
    }

    const applyBar = container.createDiv({ cls: "mt-conflict-merge__apply" });
    const applyBtn = applyBar.createEl("button", {
      cls: "mt-dialog__button mt-dialog__button--primary",
      text: "应用选择并保存合并结果",
      attr: { type: "button" }
    });
    applyBtn.addEventListener("click", () => void this.applyCellMerge(panelRoot, diskDocument, localDocument, resolutions));
  }

  private async applyCellMerge(
    panelRoot: HTMLElement,
    diskDocument: DuoweiDocument,
    localDocument: DuoweiDocument,
    resolutions: ConflictResolutions
  ): Promise<void> {
    const file = this.file;
    if (!file) return;
    const diskCount =
      Array.from(resolutions.cells.values()).filter((side) => side === "disk").length +
      Array.from(resolutions.records.values()).filter((side) => side === "disk").length;
    const localCount = resolutions.cells.size + resolutions.records.size - diskCount;
    if (
      !(await this.confirmAction(
        `这会按你的选择合并原文件和当前编辑，并覆盖原文件。共 ${diskCount} 项保留原文件，${localCount} 项保留当前编辑。是否继续？`,
        "应用合并结果"
      ))
    )
      return;
    const merged = applyConflictResolutions(diskDocument, localDocument, resolutions);
    const mergedData = serializeDuoweiDocument(merged);
    await this.app.vault.modify(file, mergedData);
    this.setViewData(mergedData, false);
    this.lastPersistedData = mergedData;
    this.lastConflictSignature = null;
    this.lastConflictBackupPath = null;
    this.setStatus("已应用逐单元格合并", "saved");
    this.addOperationLog("conflict", "逐单元格合并冲突", `${diskCount} 项保留原文件，${localCount} 项保留当前编辑`, "warning");
    new Notice("已应用逐单元格合并结果。", 4000);
    panelRoot.remove();
  }

  private openBackupRecoveryPanel(anchor: HTMLElement): void {
    const panel = this.createPanel(anchor, "备份恢复");
    panel.root.addClass("mt-panel--backup-recovery");
    const body = panel.body;
    const footer = panel.footer;
    body.createDiv({ cls: "mt-conflict-message", text: "正在查找当前表格同目录下的备份文件..." });
    void this.renderBackupRecoveryPanel(panel.root, body, footer);
  }

  private async renderBackupRecoveryPanel(panelRoot: HTMLElement, body: HTMLElement, footer: HTMLElement): Promise<void> {
    const backups = await this.listBackupFiles();
    const settings = this.duoweiSettings();
    body.empty();
    footer.empty();
    body.createDiv({
      cls: "mt-backup-policy",
      text: settings.duoweiAutoBackupEnabled
        ? `自动备份已开启：至少间隔 ${settings.duoweiAutoBackupIntervalMinutes} 分钟，每个表格保留 ${settings.duoweiAutoBackupRetention} 个自动备份。`
        : "自动备份已关闭。"
    });
    if (backups.length === 0) {
      body.createDiv({ cls: "mt-panel__empty", text: "没有找到当前表格的备份文件。" });
      footer.createDiv({ cls: "mt-summary-note", text: "插件会在同目录生成自动备份和冲突备份，这里会列出可恢复版本。" });
      return;
    }

    const summary = body.createDiv({ cls: "mt-conflict-message" });
    summary.setText(`找到 ${backups.length} 个备份。恢复会用选中的备份覆盖当前表格文件。`);
    const list = body.createDiv({ cls: "mt-backup-list" });
    for (const backup of backups) {
      this.renderBackupItem(list, panelRoot, backup);
    }
  }

  private renderBackupItem(parent: HTMLElement, panelRoot: HTMLElement, backup: BackupFileInfo): void {
    const row = parent.createDiv({ cls: `mt-backup-item${backup.parseError ? " is-warning" : ""}` });
    const icon = row.createSpan({ cls: "mt-backup-item__icon", attr: { "aria-hidden": "true" } });
    setIcon(icon, backup.parseError ? "triangle-alert" : backup.kind === "auto" ? "archive" : "shield-alert");
    const text = row.createDiv({ cls: "mt-backup-item__text" });
    text.createDiv({ cls: "mt-backup-item__title", text: backup.label });
    const meta = text.createDiv({ cls: "mt-backup-item__meta" });
    const countText =
      backup.recordCount === null || backup.fieldCount === null ? "无法读取内容" : `${backup.recordCount} 行 · ${backup.fieldCount} 列`;
    meta.createSpan({ text: `${backupKindDisplayName(backup.kind)} · ${backup.createdLabel} · ${backup.sizeLabel} · ${countText}` });
    if (backup.updatedAt) meta.createSpan({ text: ` · 表格更新时间 ${formatDateTimeLabel(new Date(backup.updatedAt))}` });
    if (backup.parseError) text.createDiv({ cls: "mt-backup-item__warning", text: backup.parseError });
    const diff = text.createDiv({ cls: "mt-backup-item__diff" });
    diff.createDiv({ cls: "mt-conflict-diff__loading", text: "正在比较当前文件..." });
    void this.renderFileDiff(diff, backup.file.path, "当前文件", backupKindDisplayName(backup.kind));
    const actions = row.createDiv({ cls: "mt-backup-item__actions" });
    const open = actions.createEl("button", { cls: "clickable-icon mt-tool-button", attr: { type: "button", "aria-label": "打开备份", title: "打开备份" } });
    setIcon(open, "external-link");
    open.addEventListener("click", () => void this.openConflictBackup(backup.file.path));
    const restore = actions.createEl("button", {
      cls: "clickable-icon mt-tool-button",
      attr: { type: "button", "aria-label": "用此备份恢复", title: "用此备份恢复" }
    });
    setIcon(restore, "rotate-ccw");
    restore.addEventListener("click", () => void this.restoreBackupFromHistory(panelRoot, backup.file.path));
  }

  private async renderFileDiff(parent: HTMLElement, backupPath: string, leftTitle: string, rightTitle: string): Promise<void> {
    const file = this.file;
    parent.empty();
    if (!file) {
      parent.createDiv({ cls: "mt-conflict-diff__empty", text: "当前表格文件不可用，无法比较。" });
      return;
    }
    const backup = this.app.vault.getAbstractFileByPath(backupPath);
    if (!(backup instanceof TFile)) {
      parent.createDiv({ cls: "mt-conflict-diff__empty", text: "备份文件不存在，无法比较。" });
      return;
    }
    try {
      const [leftData, rightData] = await Promise.all([this.app.vault.read(file), this.app.vault.read(backup)]);
      const summary = createDocumentDiffSummary(leftData, rightData, this.file?.basename ?? leftTitle, backup.basename, leftTitle, rightTitle);
      this.renderDocumentDiffSummary(parent, summary);
    } catch (error) {
      parent.createDiv({ cls: "mt-conflict-diff__empty", text: error instanceof Error ? error.message : "比较失败" });
    }
  }

  private renderDocumentDiffSummary(parent: HTMLElement, summary: DocumentDiffSummary): void {
    const root = parent.createDiv({ cls: "mt-conflict-diff__summary" });
    const title = root.createDiv({ cls: "mt-conflict-diff__title" });
    title.createSpan({ text: `${summary.leftTitle} ↔ ${summary.rightTitle}` });
    if (summary.error) {
      root.createDiv({ cls: "mt-conflict-diff__empty", text: summary.error });
      return;
    }
    const stats = root.createDiv({ cls: "mt-conflict-diff__stats" });
    this.renderDiffStat(stats, "新增列", summary.addedFields);
    this.renderDiffStat(stats, "删除列", summary.removedFields);
    this.renderDiffStat(stats, "字段变化", summary.changedFields);
    this.renderDiffStat(stats, "新增行", summary.addedRecords);
    this.renderDiffStat(stats, "删除行", summary.removedRecords);
    this.renderDiffStat(stats, "记录变化", summary.changedRecords);
    this.renderDiffStat(stats, "值变化", summary.changedValues);
    this.renderDiffStat(stats, "绑定变化", summary.notePathChanges);
    this.renderDiffStat(stats, "视图变化", summary.viewChanges);
    const meta = root.createDiv({ cls: "mt-conflict-diff__meta" });
    meta.createSpan({ text: `${summary.leftTitle} 更新时间：${summary.leftUpdatedAt ? formatDateTimeLabel(new Date(summary.leftUpdatedAt)) : "未知"}` });
    meta.createSpan({ text: `${summary.rightTitle} 更新时间：${summary.rightUpdatedAt ? formatDateTimeLabel(new Date(summary.rightUpdatedAt)) : "未知"}` });
  }

  private renderDiffStat(parent: HTMLElement, label: string, value: number): void {
    const item = parent.createDiv({ cls: value > 0 ? "mt-conflict-diff__stat is-changed" : "mt-conflict-diff__stat" });
    item.createSpan({ cls: "mt-conflict-diff__stat-value", text: String(value) });
    item.createSpan({ cls: "mt-conflict-diff__stat-label", text: label });
  }

  private renderConflictDetail(parent: HTMLElement, label: string, value: string): void {
    const row = parent.createDiv({ cls: "mt-conflict-detail__row" });
    row.createSpan({ cls: "mt-conflict-detail__label", text: label });
    row.createSpan({ cls: "mt-conflict-detail__value", text: value });
  }

  private async openConflictBackup(path: string): Promise<void> {
    const file = this.app.vault.getAbstractFileByPath(path);
    if (!(file instanceof TFile)) {
      new Notice("冲突备份文件不存在。", 4000);
      return;
    }
    await this.app.workspace.getLeaf("tab").openFile(file);
  }

  private async keepDiskVersion(panelRoot: HTMLElement): Promise<void> {
    const file = this.file;
    if (!file) return;
    if (!(await this.confirmAction("将放弃当前未覆盖原文件的编辑，并重新载入磁盘上的原文件版本。是否继续？", "保留原文件"))) return;
    const diskData = await this.app.vault.read(file);
    this.setViewData(diskData, true);
    this.lastPersistedData = diskData;
    this.lastConflictSignature = null;
    this.lastConflictBackupPath = null;
    this.setStatus("已保留原文件", "saved");
    this.addOperationLog("conflict", "保留原文件", file.path, "warning");
    panelRoot.remove();
  }

  private async restoreConflictBackup(panelRoot: HTMLElement, backupPath: string): Promise<void> {
    const file = this.file;
    if (!file) return;
    if (!(await this.confirmAction("这会用冲突备份覆盖当前原文件。原文件的外部修改会被替换。是否继续？", "用备份覆盖原文件"))) return;
    const backup = this.app.vault.getAbstractFileByPath(backupPath);
    if (!(backup instanceof TFile)) {
      new Notice("冲突备份文件不存在。", 4000);
      return;
    }
    const backupData = await this.app.vault.read(backup);
    await this.app.vault.modify(file, backupData);
    this.setViewData(backupData, false);
    this.lastPersistedData = backupData;
    this.lastConflictSignature = null;
    this.lastConflictBackupPath = null;
    this.setStatus("已用备份覆盖原文件", "saved");
    this.addOperationLog("conflict", "用备份覆盖原文件", backupPath, "warning");
    panelRoot.remove();
  }

  private async restoreBackupFromHistory(panelRoot: HTMLElement, backupPath: string): Promise<void> {
    const file = this.file;
    if (!file) return;
    if (!(await this.confirmAction("这会用选中的备份覆盖当前表格文件。当前文件内容会被替换。是否继续？", "恢复备份"))) return;
    const backup = this.app.vault.getAbstractFileByPath(backupPath);
    if (!(backup instanceof TFile)) {
      new Notice("备份文件不存在。", 4000);
      return;
    }
    const backupData = await this.app.vault.read(backup);
    const parsed = parseDuoweiDocument(backupData, backup.basename);
    if (parsed.repaired && !(await this.confirmAction(`备份文件需要修复：${parsed.error ?? "未知问题"}。仍然恢复？`, "继续恢复"))) return;
    await this.app.vault.modify(file, backupData);
    this.setViewData(backupData, false);
    this.lastPersistedData = backupData;
    this.lastConflictSignature = null;
    this.lastConflictBackupPath = null;
    this.setStatus("已从备份恢复", "saved");
    this.addOperationLog("conflict", "从历史备份恢复", backupPath, parsed.repaired ? "warning" : "ok");
    new Notice("已从备份恢复当前表格。", 4000);
    panelRoot.remove();
  }

  private duoweiSettings(): MultiTableSettings {
    return this.options.getSettings?.() ?? DEFAULT_SETTINGS;
  }

  private createCommandButton(
    parent: HTMLElement,
    icon: string,
    label: string,
    title: string,
    callback: (event: MouseEvent) => void
  ): HTMLButtonElement {
    const button = parent.createEl("button", {
      cls: "clickable-icon mt-command-button mt-tool-button",
      attr: { type: "button", title, "aria-label": title }
    });
    setIcon(button.createSpan({ cls: "mt-command-button__icon", attr: { "aria-hidden": "true" } }), icon);
    button.createSpan({ cls: "mt-command-button__label", text: label });
    button.addEventListener("click", callback);
    return button;
  }

  private createIconButton(
    parent: HTMLElement,
    icon: string,
    title: string,
    callback: (event: MouseEvent) => void
  ): HTMLButtonElement {
    const button = parent.createEl("button", {
      cls: "clickable-icon mt-command-button mt-command-button--icon",
      attr: { type: "button", title, "aria-label": title }
    });
    setIcon(button.createSpan({ cls: "mt-command-button__icon", attr: { "aria-hidden": "true" } }), icon);
    button.addEventListener("click", callback);
    return button;
  }

  private currentView(): DuoweiViewConfig {
    return this.ensureActiveView();
  }

  private ensureActiveView(): DuoweiViewConfig {
    this.ensureRequiredViews();
    let view = this.documentModel.views.find((item) => item.id === this.documentModel.activeViewId);
    if (!view) {
      view = this.documentModel.views.find((item) => item.type === "grid") ?? this.documentModel.views[0];
      this.documentModel.activeViewId = view?.id;
    }

    const known = new Set(this.documentModel.fields.map((field) => field.id));
    for (const item of this.documentModel.views) {
      item.fieldOrder = item.fieldOrder.filter((fieldId) => known.has(fieldId));
      const ordered = new Set(item.fieldOrder);
      for (const field of this.documentModel.fields) {
        if (!ordered.has(field.id)) item.fieldOrder.push(field.id);
      }
      item.hiddenFields = item.hiddenFields.filter((fieldId) => known.has(fieldId));
      item.sorts = item.sorts.filter((sort) => known.has(sort.fieldId));
      item.filters = item.filters.filter((filter) => known.has(filter.fieldId));
      if (item.type === "kanban") {
        if (item.groupFieldId && !known.has(item.groupFieldId)) item.groupFieldId = null;
        if (item.titleFieldId && !known.has(item.titleFieldId)) item.titleFieldId = this.documentModel.fields[0]?.id ?? null;
        item.cardFieldIds = item.cardFieldIds.filter((fieldId) => known.has(fieldId));
      } else if (item.type === "gallery") {
        if (item.coverFieldId && !known.has(item.coverFieldId)) item.coverFieldId = null;
        if (item.titleFieldId && !known.has(item.titleFieldId)) item.titleFieldId = this.documentModel.fields[0]?.id ?? null;
        item.cardFieldIds = item.cardFieldIds.filter((fieldId) => known.has(fieldId));
      }
    }
    return view ?? createDefaultGridView(this.documentModel.fields);
  }

  private ensureRequiredViews(): void {
    if (!this.documentModel.views.some((item) => item.type === "grid")) {
      this.documentModel.views.unshift(createDefaultGridView(this.documentModel.fields));
    }
    if (!this.documentModel.views.some((item) => item.type === "kanban")) {
      this.documentModel.views.push(createDefaultKanbanView(this.documentModel.fields));
    }
    if (!this.documentModel.views.some((item) => item.type === "gallery")) {
      this.documentModel.views.push(createDefaultGalleryView(this.documentModel.fields));
    }
  }

  private viewByType(type: DuoweiViewType): DuoweiViewConfig {
    this.ensureRequiredViews();
    let view = this.documentModel.views.find((item) => item.type === type);
    if (!view) {
      view = createDefaultViewForType(type, this.documentModel.fields);
      this.documentModel.views.push(view);
    }
    return view;
  }

  private switchView(type: DuoweiViewType): void {
    this.applyMutation(viewSwitchLabel(type), (document) => {
      let view = document.views.find((item) => item.type === type);
      if (!view) {
        view = createDefaultViewForType(type, document.fields);
        document.views.push(view);
      }
      document.activeViewId = view.id;
    });
    this.activeCell = this.firstCell();
    this.selectionRange = this.activeCell
      ? {
          anchorRow: this.activeCell.rowIndex,
          anchorColumn: this.activeCell.columnIndex,
          focusRow: this.activeCell.rowIndex,
          focusColumn: this.activeCell.columnIndex
        }
      : null;
  }

  private switchViewById(viewId: string): void {
    this.applyMutation("切换视图", (document) => {
      const view = document.views.find((item) => item.id === viewId);
      if (view) document.activeViewId = view.id;
    });
    this.activeCell = this.firstCell();
    this.selectionRange = this.activeCell
      ? {
          anchorRow: this.activeCell.rowIndex,
          anchorColumn: this.activeCell.columnIndex,
          focusRow: this.activeCell.rowIndex,
          focusColumn: this.activeCell.columnIndex
        }
      : null;
  }

  private openViewManagerMenu(anchor: HTMLElement): void {
    const menu = new Menu();
    const current = this.currentView();
    for (const view of this.documentModel.views) {
      menu.addItem((item) => {
        item.setTitle(`${view.name} · ${viewTypeLabel(view.type)}`).setIcon(viewTypeIcon(view.type)).setChecked(view.id === current.id);
        item.onClick(() => this.switchViewById(view.id));
      });
    }
    menu.addSeparator();
    for (const type of ["grid", "kanban", "gallery", "calendar", "timeline"] as DuoweiViewType[]) {
      menu.addItem((item) => {
        item.setTitle(`新建${viewTypeLabel(type)}视图`).setIcon(viewTypeIcon(type));
        item.onClick(() => this.createView(type));
      });
    }
    menu.addSeparator();
    menu.addItem((item) => {
      item.setTitle("重命名当前视图").setIcon("pencil");
      item.onClick(() => void this.renameCurrentView());
    });
    menu.addItem((item) => {
      item.setTitle("复制当前视图").setIcon("copy");
      item.onClick(() => this.duplicateCurrentView());
    });
    menu.addItem((item) => {
      item.setTitle("删除当前视图").setIcon("trash-2").setWarning(true).setDisabled(this.documentModel.views.length <= 1);
      item.onClick(() => void this.deleteCurrentView());
    });
    const rect = anchor.getBoundingClientRect();
    menu.showAtPosition({ x: rect.left, y: rect.bottom + 4 });
  }

  private createView(type: DuoweiViewType): void {
    const baseName = viewTypeLabel(type);
    this.applyMutation("新建视图", (document) => {
      const usedNames = new Set(document.views.map((view) => view.name));
      const view = createDefaultViewForType(type, document.fields);
      view.name = uniqueName(baseName, usedNames);
      document.views.push(view);
      document.activeViewId = view.id;
    });
  }

  private async renameCurrentView(): Promise<void> {
    const current = this.currentView();
    const next = await this.promptText("视图名称", current.name);
    if (!next || next.trim() === current.name) return;
    this.applyMutation("重命名视图", (document) => {
      const view = document.views.find((item) => item.id === current.id);
      if (view) view.name = next.trim();
    });
  }

  private duplicateCurrentView(): void {
    const current = this.currentView();
    this.applyMutation("复制视图", (document) => {
      const source = document.views.find((item) => item.id === current.id);
      if (!source) return;
      const usedNames = new Set(document.views.map((view) => view.name));
      const clone = cloneDuoweiDocument({ ...document, views: [source] }).views[0];
      clone.id = createId("view");
      clone.name = uniqueName(`${source.name} 副本`, usedNames);
      document.views.push(clone);
      document.activeViewId = clone.id;
    });
  }

  private async deleteCurrentView(): Promise<void> {
    const current = this.currentView();
    if (this.documentModel.views.length <= 1) return;
    if (!(await this.confirmAction(`删除视图“${current.name}”？`))) return;
    this.applyMutation("删除视图", (document) => {
      document.views = document.views.filter((view) => view.id !== current.id);
      if (document.views.length === 0) document.views.push(createDefaultGridView(document.fields));
      document.activeViewId = document.views[0]?.id;
    });
  }

  private visibleFields(): DuoweiField[] {
    const view = this.currentView();
    const hidden = new Set(view.hiddenFields);
    const fieldById = new Map(this.documentModel.fields.map((field) => [field.id, field]));
    return view.fieldOrder
      .map((fieldId) => fieldById.get(fieldId))
      .filter((field): field is DuoweiField => field !== undefined && !hidden.has(field.id));
  }

  private recomputeRecords(): void {
    const fields = this.visibleFields();
    const view = this.currentView();
    const allFields = this.documentModel.fields;
    let records = [...this.documentModel.records];
    if (this.quickSearch) {
      records = records.filter((record) =>
        fields.some((field) => this.displayValue(record.values[field.id], field).toLowerCase().includes(this.quickSearch))
      );
    }
    if (view.filters.length > 0) {
      records = records.filter((record) => view.filters.every((rule) => this.recordMatchesFilter(record, rule, allFields)));
    }
    if (view.sorts.length > 0) {
      records.sort((left, right) => this.compareRecords(left, right, view.sorts, allFields));
    }
    this.visibleRecords = records;
    this.countEl.setText(
      this.quickSearch || view.filters.length > 0
        ? `${this.visibleRecords.length.toLocaleString()} / ${this.documentModel.records.length.toLocaleString()} 条记录`
        : `${this.visibleRecords.length.toLocaleString()} 条记录`
    );
    this.scrollerEl.setAttr("aria-rowcount", String(this.visibleRecords.length));
    this.scrollerEl.setAttr("aria-colcount", String(fields.length));
  }

  private renderAll(force = false): void {
    this.refreshFormulaValues(this.documentModel);
    this.recomputeRecords();
    const fields = this.visibleFields();
    const totalWidth = this.totalWidth(fields);
    const rowHeight = this.rowHeight();
    const view = this.currentView();
    this.rootEl.style.setProperty("--mt-row-height", `${rowHeight}px`);
    this.headerEl.style.width = `${totalWidth}px`;
    this.bodyEl.style.width = `${totalWidth}px`;
    this.bodyEl.style.height = `${this.visibleRecords.length * rowHeight}px`;
    this.addRowEl.style.width = `${totalWidth}px`;
    this.updateUndoRedoButtons();
    this.updateToolBadges();
    this.rootEl.classList.toggle("is-kanban-view", view.type === "kanban");
    this.rootEl.classList.toggle("is-grid-view", view.type === "grid");
    this.rootEl.classList.toggle("is-gallery-view", view.type === "gallery");
    if (view.type === "kanban") {
      this.headerEl.empty();
      this.bodyEl.style.width = "";
      this.bodyEl.style.height = "";
      this.addRowEl.style.width = "";
      this.lastWindowKey = "";
      this.renderKanban(view);
    } else if (view.type === "gallery") {
      this.headerEl.empty();
      this.bodyEl.style.width = "";
      this.bodyEl.style.height = "";
      this.addRowEl.style.width = "";
      this.lastWindowKey = "";
      this.renderGallery(view);
    } else {
      this.renderHeader(fields);
      if (force) this.lastWindowKey = "";
      this.scheduleRows(force);
    }
  }

  private renderHeader(fields: DuoweiField[]): void {
    this.headerEl.empty();
    this.headerEl.style.gridTemplateColumns = this.gridTemplate(fields);
    const frozenCount = this.frozenFieldCount(fields);
    const frozenLeft = this.frozenLeftOffsets(fields);

    const index = this.headerEl.createDiv({
      cls: "mt-grid-header__index",
      text: "#",
      attr: { role: "columnheader", "aria-label": "选择全部" }
    });
    index.toggleClass("has-frozen-fields", frozenCount > 0);
    index.addEventListener("click", () => this.selectAll());

    fields.forEach((field, columnIndex) => {
      const header = this.headerEl.createDiv({
        cls: "mt-grid-header__cell",
        attr: {
          role: "columnheader",
          draggable: "true",
          "aria-colindex": String(columnIndex + 1),
          "data-column": String(columnIndex),
          title: field.name
        }
      });
      this.applyFrozenColumnStyle(header, fields, columnIndex, frozenCount, frozenLeft);
      this.applyColumnDragClasses(header, columnIndex);
      if (this.isColumnSelected(columnIndex)) header.addClass("is-selected");
      const icon = header.createSpan({ cls: "mt-grid-header__type-icon", attr: { "aria-hidden": "true" } });
      setIcon(icon, this.fieldTypeIcon(field.type));
      header.createSpan({ cls: "mt-grid-header__label", text: field.name });
      const menuButton = header.createEl("button", {
        cls: "clickable-icon mt-column-menu-button",
        attr: { type: "button", title: "字段操作", "aria-label": `${field.name} 字段操作` }
      });
      setIcon(menuButton, "more-horizontal");
      menuButton.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        this.openFieldMenu(menuButton, field, columnIndex);
      });
      const resize = header.createDiv({ cls: "mt-column-resize", attr: { "aria-hidden": "true" } });
      resize.addEventListener("pointerdown", (event) => this.beginResize(event, field));
      header.addEventListener("dragstart", (event) => this.beginColumnDrag(event, columnIndex));
      header.addEventListener("dragover", (event) => this.updateColumnDrag(event, columnIndex));
      header.addEventListener("drop", (event) => this.finishColumnDrop(event, columnIndex));
      header.addEventListener("dragend", () => this.cancelColumnDrag());
      header.addEventListener("click", (event) => {
        if (menuButton.contains(event.target as Node) || resize.contains(event.target as Node)) return;
        this.selectColumn(columnIndex, event.shiftKey);
      });
      header.addEventListener("dblclick", () => void this.renameField(field));
    });
  }

  private recordMatchesFilter(record: DuoweiRecord, rule: DuoweiFilterRule, fields: DuoweiField[]): boolean {
    const field = fields.find((item) => item.id === rule.fieldId);
    if (!field) return true;
    const display = this.displayValue(record.values[field.id], field).trim().toLowerCase();
    const expected = rule.value.trim().toLowerCase();
    switch (rule.op) {
      case "equals":
        return display === expected;
      case "empty":
        return display.length === 0;
      case "notEmpty":
        return display.length > 0;
      default:
        return display.includes(expected);
    }
  }

  private compareRecords(
    left: DuoweiRecord,
    right: DuoweiRecord,
    sorts: DuoweiSortRule[],
    fields: DuoweiField[]
  ): number {
    for (const sort of sorts) {
      const field = fields.find((item) => item.id === sort.fieldId);
      if (!field) continue;
      const leftRaw = left.values[field.id];
      const rightRaw = right.values[field.id];
      let result = 0;
      if (field.type === "number") {
        const leftNumber = Number(leftRaw);
        const rightNumber = Number(rightRaw);
        if (Number.isFinite(leftNumber) && Number.isFinite(rightNumber)) {
          result = leftNumber - rightNumber;
        }
      }
      if (result === 0) {
        const leftDisplay = this.displayValue(leftRaw, field);
        const rightDisplay = this.displayValue(rightRaw, field);
        if (leftDisplay === "" && rightDisplay !== "") result = 1;
        else if (rightDisplay === "" && leftDisplay !== "") result = -1;
        else result = leftDisplay.localeCompare(rightDisplay, "zh-Hans-CN");
      }
      if (result !== 0) return sort.direction === "desc" ? -result : result;
    }
    return 0;
  }

  private updateToolBadges(): void {
    const view = this.currentView();
    this.setToolBadge(this.filterButtonEl, view.filters.length);
    this.setToolBadge(this.sortButtonEl, view.sorts.length);
    this.setToolBadge(this.fieldsButtonEl, view.hiddenFields.length);
    this.densityButtonEl.classList.toggle("is-active", view.type === "grid" && view.rowHeight !== "default");
    this.densityButtonEl.disabled = view.type !== "grid";
    const frozenCount = view.type === "grid" ? this.frozenFieldCount(this.visibleFields()) : 0;
    this.setToolBadge(this.freezeButtonEl, frozenCount);
    this.freezeButtonEl.classList.toggle("is-active", view.type === "grid" && frozenCount > 0);
    this.freezeButtonEl.disabled = view.type !== "grid";
    this.gridViewButtonEl.classList.toggle("is-active", view.type === "grid");
    this.kanbanViewButtonEl.classList.toggle("is-active", view.type === "kanban");
    this.galleryViewButtonEl.classList.toggle("is-active", view.type === "gallery");
  }

  private setToolBadge(button: HTMLButtonElement, count: number): void {
    let badge = button.querySelector(".mt-command-button__badge") as HTMLSpanElement | null;
    if (!badge) {
      badge = button.createSpan({ cls: "mt-command-button__badge" });
    }
    badge.setText(String(count));
    badge.classList.toggle("is-hidden", count === 0);
    button.classList.toggle("is-active", count > 0);
  }

  private scheduleRows(force = false): void {
    if (force) this.lastWindowKey = "";
    if (this.renderFrame) return;
    this.renderFrame = this.rootEl.win.requestAnimationFrame(() => {
      this.renderFrame = 0;
      this.renderRows();
    });
  }

  private renderRows(): void {
    const fields = this.visibleFields();
    if (fields.length === 0) {
      this.bodyEl.empty();
      this.bodyEl.createDiv({ cls: "mt-empty-state__hint", text: "暂无字段，点击上方“列”创建字段。" });
      return;
    }

    const rowHeight = this.rowHeight();
    const window = computeVirtualWindow({
      scrollTop: this.scrollerEl.scrollTop,
      viewportHeight: this.scrollerEl.clientHeight,
      rowHeight,
      count: this.visibleRecords.length,
      overscan: 8
    });
    const key = [
      window.start,
      window.end,
      this.visibleRecords.length,
      fields.map((field) => `${field.id}:${field.width ?? ""}`).join(","),
      this.activeCell?.recordId ?? "",
      this.activeCell?.fieldId ?? "",
      this.selectionKey(),
      this.fillDragKey(),
      this.rowDragKey()
    ].join("|");
    if (key === this.lastWindowKey) return;
    this.lastWindowKey = key;
    this.bodyEl.empty();

    const template = this.gridTemplate(fields);
    const frozenCount = this.frozenFieldCount(fields);
    const frozenLeft = this.frozenLeftOffsets(fields);
    const rowReorderEnabled = this.canReorderRows();
    for (let rowIndex = window.start; rowIndex < window.end; rowIndex += 1) {
      const record = this.visibleRecords[rowIndex];
      if (!record) continue;
      const row = this.bodyEl.createDiv({
        cls: "mt-grid-row",
        attr: { role: "row", "aria-rowindex": String(rowIndex + 1) }
      });
      row.style.top = `${rowIndex * rowHeight}px`;
      row.style.height = `${rowHeight}px`;
      row.style.gridTemplateColumns = template;

      const rowIndexEl = row.createDiv({
        cls: "mt-grid-row__index",
        attr: { role: "rowheader", draggable: rowReorderEnabled ? "true" : "false", "data-row": String(rowIndex) }
      });
      rowIndexEl.toggleClass("has-frozen-fields", frozenCount > 0);
      rowIndexEl.toggleClass("is-reorder-disabled", !rowReorderEnabled);
      this.applyRowDragClasses(rowIndexEl, rowIndex);
      if (this.isRowSelected(rowIndex)) rowIndexEl.addClass("is-selected");
      rowIndexEl.createSpan({ cls: "mt-grid-row__number", text: String(rowIndex + 1) });
      rowIndexEl.addEventListener("click", (event) => this.selectRow(rowIndex, event.shiftKey));
      rowIndexEl.addEventListener("dragstart", (event) => this.beginRowDrag(event, rowIndex));
      rowIndexEl.addEventListener("dragover", (event) => this.updateRowDrag(event, rowIndex));
      rowIndexEl.addEventListener("drop", (event) => this.finishRowDrop(event, rowIndex));
      rowIndexEl.addEventListener("dragend", () => this.cancelRowDrag());

      fields.forEach((field, columnIndex) => {
        const cell = row.createDiv({
          cls: "mt-grid-cell",
          attr: {
            role: "gridcell",
            tabindex: this.isActive(record.id, field.id) ? "0" : "-1",
            "aria-rowindex": String(rowIndex + 1),
            "aria-colindex": String(columnIndex + 1),
            "data-row": String(rowIndex),
            "data-column": String(columnIndex),
            "data-record-id": record.id,
            "data-field-id": field.id
          }
        });
        this.applyFrozenColumnStyle(cell, fields, columnIndex, frozenCount, frozenLeft);
        this.applySelectionClasses(cell, rowIndex, columnIndex);
        this.applyFillPreviewClasses(cell, rowIndex, columnIndex);
        if (this.isActive(record.id, field.id)) cell.addClass("is-active");
        this.renderCellValue(cell, record, field);
        this.renderFillHandle(cell, rowIndex, columnIndex);
        cell.addEventListener("pointerdown", (event) => this.beginCellSelection(event, cell, record, field, rowIndex, columnIndex));
        cell.addEventListener("pointerenter", () => this.extendDragSelection(rowIndex, columnIndex));
        cell.addEventListener("dblclick", () => this.startCellEdit(cell, record, field, rowIndex, columnIndex));
      });
    }

    this.focusRenderedActiveCell(false);
  }

  private renderKanban(view: DuoweiKanbanViewConfig): void {
    this.bodyEl.empty();
    this.scrollerEl.scrollTop = 0;
    const fields = this.documentModel.fields;
    const groupField =
      fields.find((field) => field.id === view.groupFieldId) ??
      fields.find((field) => field.type === "singleSelect" || field.type === "checkbox") ??
      fields[0];
    if (!groupField) {
      this.bodyEl.createDiv({ cls: "mt-empty-state__hint", text: "暂无字段，无法创建看板。" });
      return;
    }

    if (view.groupFieldId !== groupField.id) {
      view.groupFieldId = groupField.id;
      this.requestSave();
    }

    const titleField = fields.find((field) => field.id === view.titleFieldId) ?? fields[0] ?? groupField;
    const titleFieldId = titleField.id;
    const groupFieldId = groupField.id;
    const cardFields = view.cardFieldIds
      .map((fieldId) => fields.find((field) => field.id === fieldId))
      .filter(isDuoweiField)
      .filter((field) => field.id !== titleFieldId && field.id !== groupFieldId)
      .slice(0, 5);
    const columns = this.kanbanColumns(groupField);
    const board = this.bodyEl.createDiv({ cls: "mt-kanban-board" });
    board.style.minHeight = `${Math.max(240, this.scrollerEl.clientHeight - 28)}px`;

    for (const column of columns) {
      const columnEl = board.createDiv({ cls: "mt-kanban-column" });
      columnEl.dataset.value = column.valueKey;
      const header = columnEl.createDiv({ cls: "mt-kanban-column__header" });
      const title = header.createDiv({ cls: "mt-kanban-column__title" });
      if (column.color) {
        const dot = title.createSpan({ cls: "mt-kanban-column__dot" });
        dot.style.setProperty("--mt-kanban-color", column.color);
      }
      title.createSpan({ text: column.label });
      const records = this.visibleRecords.filter((record) => this.kanbanValueKey(record.values[groupField.id], groupField) === column.valueKey);
      header.createSpan({ cls: "mt-kanban-column__count", text: String(records.length) });
      const list = columnEl.createDiv({ cls: "mt-kanban-column__list" });
      list.addEventListener("dragover", (event) => {
        event.preventDefault();
        columnEl.addClass("is-drop-target");
      });
      list.addEventListener("dragleave", () => columnEl.removeClass("is-drop-target"));
      list.addEventListener("drop", (event) => {
        event.preventDefault();
        columnEl.removeClass("is-drop-target");
        const recordId = event.dataTransfer?.getData("text/plain");
        if (recordId) this.moveRecordToKanbanColumn(recordId, groupField, column.rawValue);
      });

      for (const record of records) {
        const card = list.createDiv({ cls: "mt-kanban-card", attr: { draggable: "true" } });
        card.dataset.recordId = record.id;
        card.addEventListener("dragstart", (event) => {
          event.dataTransfer?.setData("text/plain", record.id);
          event.dataTransfer?.setData("application/x-duowei-record", record.id);
          event.dataTransfer?.setDragImage(card, 12, 12);
        });
        card.addEventListener("dblclick", () => {
          const rowIndex = this.visibleRecords.findIndex((item) => item.id === record.id);
          const columnIndex = Math.max(0, this.visibleFields().findIndex((field) => field.id === titleField.id));
          const cell = this.cellElement(rowIndex, columnIndex);
          this.activeCell = { recordId: record.id, fieldId: titleField.id, rowIndex, columnIndex };
          if (cell) this.startCellEdit(cell, record, titleField, rowIndex, columnIndex);
        });
        card.addEventListener("contextmenu", (event) => {
          event.preventDefault();
          this.openRecordContextMenu(event, record);
        });
        card.createDiv({
          cls: "mt-kanban-card__title",
          text: this.displayValue(record.values[titleField.id], titleField) || "未命名记录"
        });
        const meta = card.createDiv({ cls: "mt-kanban-card__meta" });
        for (const field of cardFields) {
          const value = this.displayValue(record.values[field.id], field);
          if (!value) continue;
          const row = meta.createDiv({ cls: "mt-kanban-card__field" });
          const icon = row.createSpan({ cls: "mt-kanban-card__field-icon" });
          setIcon(icon, this.fieldTypeIcon(field.type));
          row.createSpan({ cls: "mt-kanban-card__field-name", text: field.name });
          row.createSpan({ cls: "mt-kanban-card__field-value", text: value });
        }
      }

      const add = list.createEl("button", { cls: "mt-kanban-add", attr: { type: "button" } });
      setIcon(add.createSpan({ cls: "mt-kanban-add__icon" }), "plus");
      add.createSpan({ text: "新增记录" });
      add.addEventListener("click", () => this.addKanbanRecord(groupField, column.rawValue));
    }
  }

  private renderGallery(view: DuoweiGalleryViewConfig): void {
    this.bodyEl.empty();
    this.scrollerEl.scrollTop = 0;
    const fields = this.documentModel.fields;
    if (fields.length === 0) {
      this.bodyEl.createDiv({ cls: "mt-empty-state__hint", text: "暂无字段，无法创建画廊。" });
      return;
    }

    const coverField = fields.find((field) => field.id === view.coverFieldId) ?? null;
    const titleField = fields.find((field) => field.id === view.titleFieldId) ?? fields[0];
    const blocked = new Set([coverField?.id, titleField?.id].filter((fieldId): fieldId is string => Boolean(fieldId)));
    const cardFields = view.cardFieldIds
      .map((fieldId) => fields.find((field) => field.id === fieldId))
      .filter(isDuoweiField)
      .filter((field) => !blocked.has(field.id))
      .slice(0, 6);

    if (titleField && view.titleFieldId !== titleField.id) {
      view.titleFieldId = titleField.id;
      this.requestSave();
    }

    const board = this.bodyEl.createDiv({ cls: "mt-gallery-board" });
    board.style.minHeight = `${Math.max(240, this.scrollerEl.clientHeight - 28)}px`;

    for (const record of this.visibleRecords) {
      const card = board.createDiv({ cls: "mt-gallery-card", attr: { tabindex: "0", role: "button" } });
      card.dataset.recordId = record.id;
      card.addEventListener("dblclick", () => this.focusRecordInGrid(record, titleField));
      card.addEventListener("keydown", (event) => {
        if (event.key === "Enter") {
          event.preventDefault();
          this.focusRecordInGrid(record, titleField);
        }
      });
      card.addEventListener("contextmenu", (event) => {
        event.preventDefault();
        this.openRecordContextMenu(event, record);
      });

      const cover = card.createDiv({ cls: "mt-gallery-card__cover" });
      if (coverField) {
        const coverValue = this.displayValue(record.values[coverField.id], coverField);
        const icon = cover.createSpan({ cls: "mt-gallery-card__cover-icon" });
        setIcon(icon, linkedFieldIcon(coverField.type));
        if (coverValue) {
          const coverText = cover.createEl("button", {
            cls: "mt-gallery-card__cover-link",
            text: coverValue,
            attr: { type: "button", title: coverValue }
          });
          coverText.addEventListener("click", (event) => {
            event.preventDefault();
            event.stopPropagation();
            void this.openLinkedFieldValue(coverValue, coverField);
          });
        } else {
          cover.createSpan({ cls: "mt-gallery-card__cover-empty", text: "无封面" });
        }
      } else {
        setIcon(cover.createSpan({ cls: "mt-gallery-card__cover-icon" }), "image");
        cover.createSpan({ cls: "mt-gallery-card__cover-empty", text: "未设置封面字段" });
      }

      const title = card.createDiv({
        cls: "mt-gallery-card__title",
        text: titleField ? this.displayValue(record.values[titleField.id], titleField) || "未命名记录" : "未命名记录"
      });
      title.setAttr("title", title.getText());

      const meta = card.createDiv({ cls: "mt-gallery-card__meta" });
      for (const field of cardFields) {
        const value = this.displayValue(record.values[field.id], field);
        if (!value) continue;
        const row = meta.createDiv({ cls: "mt-gallery-card__field" });
        const icon = row.createSpan({ cls: "mt-gallery-card__field-icon" });
        setIcon(icon, this.fieldTypeIcon(field.type));
        row.createSpan({ cls: "mt-gallery-card__field-name", text: field.name });
        row.createSpan({ cls: "mt-gallery-card__field-value", text: value });
      }
    }

    const add = board.createEl("button", { cls: "mt-gallery-add", attr: { type: "button" } });
    setIcon(add.createSpan({ cls: "mt-gallery-add__icon" }), "plus");
    add.createSpan({ text: "新增记录" });
    add.addEventListener("click", () => this.addRow());
  }

  private kanbanColumns(field: DuoweiField): Array<{ valueKey: string; rawValue: unknown; label: string; color?: string }> {
    if (field.type === "singleSelect" || field.type === "multiSelect") {
      const options = field.options ?? [];
      return [
        ...options.map((option) => ({
          valueKey: option.id,
          rawValue: option.id,
          label: option.name,
          color: option.color
        })),
        { valueKey: "__empty__", rawValue: undefined, label: "未分类" }
      ];
    }
    if (field.type === "checkbox") {
      return [
        { valueKey: "true", rawValue: true, label: "已勾选", color: "var(--color-green)" },
        { valueKey: "false", rawValue: false, label: "未勾选", color: "var(--text-faint)" }
      ];
    }

    const values = new Map<string, string>();
    for (const record of this.visibleRecords) {
      const display = this.displayValue(record.values[field.id], field);
      if (display) values.set(display, display);
    }
    return [
      ...[...values.values()].map((value) => ({ valueKey: value, rawValue: value, label: value })),
      { valueKey: "__empty__", rawValue: undefined, label: "未分类" }
    ];
  }

  private kanbanValueKey(value: unknown, field: DuoweiField): string {
    if (value === undefined || value === null || value === "") return "__empty__";
    if (field.type === "checkbox") return value === true ? "true" : "false";
    if (field.type === "multiSelect" && Array.isArray(value)) return value[0] === undefined ? "__empty__" : String(value[0]);
    return String(value);
  }

  private moveRecordToKanbanColumn(recordId: string, field: DuoweiField, value: unknown): void {
    this.applyMutation("移动看板卡片", (document) => {
      const record = document.records.find((item) => item.id === recordId);
      const targetField = document.fields.find((item) => item.id === field.id);
      if (!record || !targetField) return;
      record.values[targetField.id] = targetField.type === "multiSelect" && value !== undefined ? [value] : value;
      record.updatedAt = new Date().toISOString();
    });
  }

  private addKanbanRecord(field: DuoweiField, value: unknown): void {
    this.applyMutation("新增看板记录", (document) => {
      const record = createDuoweiRecord(document.fields);
      const targetField = document.fields.find((item) => item.id === field.id);
      if (targetField) {
        record.values[targetField.id] = targetField.type === "multiSelect" && value !== undefined ? [value] : value;
      }
      document.records.push(record);
    });
  }

  private renderCellValue(cell: HTMLElement, record: DuoweiRecord, field: DuoweiField): void {
    const rawValue = record.values[field.id];
    if (field.type === "checkbox") {
      const checkbox = cell.createEl("input", {
        cls: "mt-checkbox",
        type: "checkbox",
        attr: { "aria-label": field.name }
      });
      checkbox.checked = rawValue === true;
      checkbox.addEventListener("click", (event) => {
        event.stopPropagation();
        this.setCellValue(record, field, checkbox.checked, "更新勾选");
      });
      return;
    }

    if (field.type === "attachment" || field.type === "noteLink" || field.type === "email") {
      this.renderLinkedCellValue(cell, rawValue, field);
      return;
    }

    if (field.type === "singleSelect") {
      const display = this.displayValue(rawValue, field);
      if (display) {
        const option = field.options?.find((item) => item.id === rawValue || item.name === rawValue);
        const chip = cell.createSpan({ cls: "mt-select-chip", text: display });
        if (option?.color) {
          chip.addClass("has-color");
          chip.style.setProperty("--mt-chip-color", option.color);
        }
        return;
      }
    }

    if (field.type === "multiSelect") {
      const chips = cell.createSpan({ cls: "mt-duowei-chip-list" });
      const values = Array.isArray(rawValue) ? rawValue : [];
      for (const item of values) {
        const option = field.options?.find((candidate) => candidate.id === item || candidate.name === item);
        const chip = chips.createSpan({ cls: "mt-select-chip", text: option?.name ?? String(item) });
        if (option?.color) {
          chip.addClass("has-color");
          chip.style.setProperty("--mt-chip-color", option.color);
        }
      }
      if (values.length > 0) return;
    }

    cell.createSpan({ cls: "mt-grid-cell__value", text: this.displayValue(rawValue, field) });
  }

  private renderLinkedCellValue(cell: HTMLElement, rawValue: unknown, field: DuoweiField): void {
    const display = this.displayValue(rawValue, field);
    const wrapper = cell.createSpan({ cls: "mt-grid-cell__file" });
    const icon = wrapper.createSpan({ cls: "mt-grid-cell__file-icon", attr: { "aria-hidden": "true" } });
    setIcon(icon, linkedFieldIcon(field.type));
    if (!display) {
      wrapper.createSpan({ cls: "mt-grid-cell__value" });
      return;
    }
    const link = wrapper.createEl("a", {
      cls: "mt-grid-cell__file-link",
      text: display,
      attr: { href: "#", title: display }
    });
    link.addEventListener("pointerdown", (event) => event.stopPropagation());
    link.addEventListener("dblclick", (event) => event.stopPropagation());
    link.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      void this.openLinkedFieldValue(display, field);
    });
    this.registerLinkPreview(link, display, field);
  }

  /**
   * 让笔记链接/附件单元格接入 Obsidian「页面预览」核心插件：
   * 按住 Ctrl/Cmd 悬停即可弹出预览（是否需要按修饰键由页面预览设置决定）。
   */
  private registerLinkPreview(target: HTMLElement, display: string, field: DuoweiField): void {
    if (field.type !== "noteLink" && field.type !== "attachment") return;
    const linktext = stripWikiLink(display);
    if (!linktext) return;
    const emit = (event: MouseEvent) => {
      this.app.workspace.trigger("hover-link", {
        event,
        source: DUOWEI_HOVER_SOURCE,
        hoverParent: this.leaf,
        targetEl: target,
        linktext,
        sourcePath: this.file?.path ?? ""
      });
    };
    target.addEventListener("mouseover", emit);
  }

  private async openLinkedFieldValue(display: string, field: DuoweiField): Promise<void> {
    if (!display) return;
    if (field.type === "email") {
      this.rootEl.win.open(display.startsWith("mailto:") ? display : `mailto:${display}`, "_blank", "noopener");
      return;
    }
    const linkText = stripWikiLink(display);
    const sourcePath = this.file?.path ?? "";
    const file = this.resolveVaultFile(linkText);
    if (file) {
      await this.app.workspace.getLeaf("tab").openFile(file);
      return;
    }
    await this.app.workspace.openLinkText(linkText, sourcePath, "tab");
  }

  private openVaultFilePicker(field: DuoweiField, onChoose: (file: TFile) => void): void {
    const markdownOnly = field.type === "noteLink";
    const files = (markdownOnly ? this.app.vault.getMarkdownFiles() : this.app.vault.getFiles()).sort((left, right) =>
      left.path.localeCompare(right.path, "zh-Hans-CN")
    );
    if (files.length === 0) {
      new Notice(markdownOnly ? "当前库中没有可选择的 Markdown 笔记。" : "当前库中没有可选择的文件。", 3000);
      return;
    }
    new VaultFilePickerModal(this.app, {
      title: markdownOnly ? "选择笔记" : "选择文件",
      files,
      onChoose
    }).open();
  }

  private beginCellSelection(
    event: PointerEvent,
    cell: HTMLElement,
    record: DuoweiRecord,
    field: DuoweiField,
    rowIndex: number,
    columnIndex: number
  ): void {
    if (event.button !== 0 || isEditorElement(event.target)) return;
    event.preventDefault();
    this.activeCell = { recordId: record.id, fieldId: field.id, rowIndex, columnIndex };
    if (event.shiftKey && this.selectionRange) {
      this.selectionRange = { ...this.selectionRange, focusRow: rowIndex, focusColumn: columnIndex };
    } else {
      this.selectionRange = { anchorRow: rowIndex, anchorColumn: columnIndex, focusRow: rowIndex, focusColumn: columnIndex };
    }
    this.dragSelecting = true;
    this.renderAll();
    this.rootEl.win.setTimeout(() => cell.focus(), 0);
  }

  private renderFillHandle(cell: HTMLElement, rowIndex: number, columnIndex: number): void {
    const range = this.normalizedSelectionRange();
    if (!range || this.fillDrag) return;
    if (rowIndex !== range.rowEnd || columnIndex !== range.columnEnd) return;
    if (this.visibleRecords.length === 0 || this.visibleFields().length === 0) return;
    const handle = cell.createDiv({
      cls: "mt-fill-handle",
      attr: { role: "button", "aria-label": "拖拽填充", title: "拖拽填充" }
    });
    handle.addEventListener("pointerdown", (event) => this.beginFillDrag(event, range));
  }

  private beginFillDrag(event: PointerEvent, range: NormalizedSelectionRange): void {
    if (event.button !== 0) return;
    event.preventDefault();
    event.stopPropagation();
    this.dragSelecting = false;
    this.fillDrag = {
      baseRange: { ...range },
      direction: null,
      targetRowEnd: range.rowEnd,
      targetColumnEnd: range.columnEnd
    };
    this.scrollerEl.addClass("is-fill-dragging");
    const onMove = (moveEvent: PointerEvent) => this.updateFillDrag(moveEvent.clientX, moveEvent.clientY);
    const onUp = () => {
      this.rootEl.win.removeEventListener("pointermove", onMove);
      this.rootEl.win.removeEventListener("pointerup", onUp);
      this.finishFillDrag();
    };
    this.rootEl.win.addEventListener("pointermove", onMove);
    this.rootEl.win.addEventListener("pointerup", onUp, { once: true });
  }

  private updateFillDrag(clientX: number, clientY: number): void {
    const drag = this.fillDrag;
    if (!drag) return;
    const cell = this.rootEl.doc.elementFromPoint(clientX, clientY)?.closest(".mt-grid-cell") as HTMLElement | null;
    if (!cell) return;
    const rowIndex = Number(cell.dataset.row);
    const columnIndex = Number(cell.dataset.column);
    if (!Number.isFinite(rowIndex) || !Number.isFinite(columnIndex)) return;
    const rowDelta = rowIndex - drag.baseRange.rowEnd;
    const columnDelta = columnIndex - drag.baseRange.columnEnd;
    if (rowDelta <= 0 && columnDelta <= 0) {
      this.fillDrag = { ...drag, direction: null, targetRowEnd: drag.baseRange.rowEnd, targetColumnEnd: drag.baseRange.columnEnd };
    } else if (rowDelta >= columnDelta) {
      this.fillDrag = {
        ...drag,
        direction: "down",
        targetRowEnd: Math.max(drag.baseRange.rowEnd, rowIndex),
        targetColumnEnd: drag.baseRange.columnEnd
      };
    } else {
      this.fillDrag = {
        ...drag,
        direction: "right",
        targetRowEnd: drag.baseRange.rowEnd,
        targetColumnEnd: Math.max(drag.baseRange.columnEnd, columnIndex)
      };
    }
    this.renderAll();
  }

  private finishFillDrag(): void {
    const drag = this.fillDrag;
    this.fillDrag = null;
    this.scrollerEl.removeClass("is-fill-dragging");
    if (!drag?.direction) {
      this.renderAll();
      return;
    }
    const targetRange: NormalizedSelectionRange =
      drag.direction === "down"
        ? {
            ...drag.baseRange,
            rowEnd: clamp(drag.targetRowEnd, drag.baseRange.rowEnd, Math.max(0, this.visibleRecords.length - 1))
          }
        : {
            ...drag.baseRange,
            columnEnd: clamp(drag.targetColumnEnd, drag.baseRange.columnEnd, Math.max(0, this.visibleFields().length - 1))
          };
    this.selectionRange = {
      anchorRow: targetRange.rowStart,
      anchorColumn: targetRange.columnStart,
      focusRow: targetRange.rowEnd,
      focusColumn: targetRange.columnEnd
    };
    this.fillRange(drag.direction, drag.baseRange, targetRange, drag.direction === "down" ? "拖拽向下填充" : "拖拽向右填充");
  }

  private extendDragSelection(rowIndex: number, columnIndex: number): void {
    if (!this.dragSelecting || !this.selectionRange) return;
    this.selectionRange = { ...this.selectionRange, focusRow: rowIndex, focusColumn: columnIndex };
    this.renderAll();
  }

  private stopDragSelection(): void {
    this.dragSelecting = false;
  }

  private beginColumnDrag(event: DragEvent, columnIndex: number): void {
    const target = event.target as HTMLElement | null;
    if (target?.closest(".mt-column-menu-button, .mt-column-resize")) {
      event.preventDefault();
      return;
    }
    const field = this.visibleFields()[columnIndex];
    if (!field) {
      event.preventDefault();
      return;
    }
    this.columnDrag = { sourceIndex: columnIndex, targetInsertIndex: null };
    this.headerEl.addClass("is-column-dragging");
    event.dataTransfer?.setData("text/plain", field.id);
    event.dataTransfer?.setData("application/x-duowei-field", field.id);
    event.dataTransfer?.setDragImage((event.currentTarget as HTMLElement) ?? this.headerEl, 12, 12);
    if (event.dataTransfer) event.dataTransfer.effectAllowed = "move";
    this.renderAll();
  }

  private updateColumnDrag(event: DragEvent, columnIndex: number): void {
    if (!this.columnDrag) return;
    event.preventDefault();
    if (event.dataTransfer) event.dataTransfer.dropEffect = "move";
    const header = event.currentTarget as HTMLElement;
    const rect = header.getBoundingClientRect();
    const insertIndex = event.clientX > rect.left + rect.width / 2 ? columnIndex + 1 : columnIndex;
    if (this.columnDrag.targetInsertIndex === insertIndex) return;
    this.columnDrag = { ...this.columnDrag, targetInsertIndex: insertIndex };
    this.renderAll();
  }

  private finishColumnDrop(event: DragEvent, columnIndex: number): void {
    if (!this.columnDrag) return;
    event.preventDefault();
    const header = event.currentTarget as HTMLElement;
    const rect = header.getBoundingClientRect();
    const insertIndex = event.clientX > rect.left + rect.width / 2 ? columnIndex + 1 : columnIndex;
    const drag = { ...this.columnDrag, targetInsertIndex: insertIndex };
    this.cancelColumnDrag(false);
    this.reorderVisibleColumn(drag.sourceIndex, drag.targetInsertIndex);
  }

  private cancelColumnDrag(render = true): void {
    this.columnDrag = null;
    this.headerEl.removeClass("is-column-dragging");
    if (render) this.renderAll();
  }

  private reorderVisibleColumn(sourceIndex: number, targetInsertIndex: number | null): void {
    const fields = this.visibleFields();
    const source = fields[sourceIndex];
    if (!source || targetInsertIndex === null) return;
    const rawInsertIndex = clamp(targetInsertIndex, 0, fields.length);
    if (rawInsertIndex === sourceIndex || rawInsertIndex === sourceIndex + 1) return;
    const finalInsertIndex = rawInsertIndex > sourceIndex ? rawInsertIndex - 1 : rawInsertIndex;
    const remainingVisibleFieldIds = fields.map((field) => field.id).filter((fieldId) => fieldId !== source.id);
    const beforeFieldId = remainingVisibleFieldIds[finalInsertIndex] ?? null;
    this.applyMutation("移动列", (document) => {
      const view = document.views.find((item) => item.id === document.activeViewId);
      if (!view) return;
      view.fieldOrder = view.fieldOrder.filter((fieldId) => fieldId !== source.id);
      const targetIndex = beforeFieldId ? view.fieldOrder.indexOf(beforeFieldId) : view.fieldOrder.length;
      view.fieldOrder.splice(targetIndex >= 0 ? targetIndex : view.fieldOrder.length, 0, source.id);
      this.activeCell = this.activeCell ? { ...this.activeCell, fieldId: source.id, columnIndex: finalInsertIndex } : null;
      if (this.activeCell) {
        this.selectionRange = {
          anchorRow: this.activeCell.rowIndex,
          anchorColumn: finalInsertIndex,
          focusRow: this.activeCell.rowIndex,
          focusColumn: finalInsertIndex
        };
      }
    });
  }

  private beginRowDrag(event: DragEvent, rowIndex: number): void {
    if (!this.canReorderRows()) {
      event.preventDefault();
      new Notice("当前存在搜索、筛选或排序时不能拖拽排序行。", 3000);
      return;
    }
    const record = this.visibleRecords[rowIndex];
    if (!record) {
      event.preventDefault();
      return;
    }
    this.rowDrag = { sourceIndex: rowIndex, targetInsertIndex: null };
    this.scrollerEl.addClass("is-row-dragging");
    event.dataTransfer?.setData("text/plain", record.id);
    event.dataTransfer?.setData("application/x-duowei-record-order", record.id);
    event.dataTransfer?.setDragImage((event.currentTarget as HTMLElement) ?? this.scrollerEl, 8, 8);
    if (event.dataTransfer) event.dataTransfer.effectAllowed = "move";
    this.renderAll();
  }

  private updateRowDrag(event: DragEvent, rowIndex: number): void {
    if (!this.rowDrag) return;
    event.preventDefault();
    if (event.dataTransfer) event.dataTransfer.dropEffect = "move";
    const rowHeader = event.currentTarget as HTMLElement;
    const rect = rowHeader.getBoundingClientRect();
    const insertIndex = event.clientY > rect.top + rect.height / 2 ? rowIndex + 1 : rowIndex;
    if (this.rowDrag.targetInsertIndex === insertIndex) return;
    this.rowDrag = { ...this.rowDrag, targetInsertIndex: insertIndex };
    this.renderAll();
  }

  private finishRowDrop(event: DragEvent, rowIndex: number): void {
    if (!this.rowDrag) return;
    event.preventDefault();
    const rowHeader = event.currentTarget as HTMLElement;
    const rect = rowHeader.getBoundingClientRect();
    const insertIndex = event.clientY > rect.top + rect.height / 2 ? rowIndex + 1 : rowIndex;
    const drag = { ...this.rowDrag, targetInsertIndex: insertIndex };
    this.cancelRowDrag(false);
    this.reorderVisibleRow(drag.sourceIndex, drag.targetInsertIndex);
  }

  private cancelRowDrag(render = true): void {
    this.rowDrag = null;
    this.scrollerEl.removeClass("is-row-dragging");
    if (render) this.renderAll();
  }

  private reorderVisibleRow(sourceIndex: number, targetInsertIndex: number | null): void {
    if (!this.canReorderRows()) return;
    const source = this.visibleRecords[sourceIndex];
    if (!source || targetInsertIndex === null) return;
    const rawInsertIndex = clamp(targetInsertIndex, 0, this.visibleRecords.length);
    if (rawInsertIndex === sourceIndex || rawInsertIndex === sourceIndex + 1) return;
    const finalInsertIndex = rawInsertIndex > sourceIndex ? rawInsertIndex - 1 : rawInsertIndex;
    const remainingVisibleRecordIds = this.visibleRecords.map((record) => record.id).filter((recordId) => recordId !== source.id);
    const beforeRecordId = remainingVisibleRecordIds[finalInsertIndex] ?? null;
    this.applyMutation("移动行", (document) => {
      const currentIndex = document.records.findIndex((record) => record.id === source.id);
      if (currentIndex < 0) return;
      const [record] = document.records.splice(currentIndex, 1);
      if (!record) return;
      const targetIndex = beforeRecordId ? document.records.findIndex((item) => item.id === beforeRecordId) : document.records.length;
      const boundedIndex = targetIndex >= 0 ? targetIndex : document.records.length;
      document.records.splice(boundedIndex, 0, record);
      this.activeCell = {
        recordId: record.id,
        fieldId: this.visibleFields()[this.activeCell?.columnIndex ?? 0]?.id ?? document.fields[0]?.id ?? "",
        rowIndex: finalInsertIndex,
        columnIndex: this.activeCell?.columnIndex ?? 0
      };
      this.selectionRange = {
        anchorRow: finalInsertIndex,
        anchorColumn: 0,
        focusRow: finalInsertIndex,
        focusColumn: Math.max(0, this.visibleFields().length - 1)
      };
    });
  }

  private startCellEdit(
    cell: HTMLElement,
    record: DuoweiRecord,
    field: DuoweiField,
    rowIndex: number,
    columnIndex: number,
    initial?: string
  ): void {
    if (cell.hasClass("is-editing")) return;
    if (isComputedField(field)) {
      new Notice(computedReadonlyMessage(field), 3000);
      return;
    }
    if (field.type === "checkbox") {
      this.setCellValue(record, field, record.values[field.id] !== true, "更新勾选");
      return;
    }

    cell.empty();
    cell.addClass("is-editing");
    let closed = false;
    let errorEl: HTMLDivElement | null = null;
    const showError = (message: string) => {
      editor.addClass("is-invalid");
      cell.addClass("is-edit-invalid");
      errorEl = errorEl ?? cell.createDiv({ cls: "mt-cell-editor-error" });
      errorEl.setText(message);
      this.rootEl.win.setTimeout(() => editor.focus(), 0);
    };
    const clearError = () => {
      editor.removeClass("is-invalid");
      cell.removeClass("is-edit-invalid");
      errorEl?.remove();
      errorEl = null;
    };
    const commitMove = (move: "none" | "down" | "right" | "left") => {
      if (closed) return false;
      const value = editor instanceof HTMLTextAreaElement ? editor.value : editor.value;
      const result = this.commitRawValue(record, field, value, "编辑单元格");
      if (!result.ok) {
        showError(result.message ?? "单元格写入失败");
        return false;
      }
      closed = true;
      cell.removeClass("is-editing");
      cell.removeClass("is-edit-invalid");
      this.moveAfterCommit(rowIndex, columnIndex, move);
      return true;
    };
    const cancel = () => {
      closed = true;
      cell.removeClass("is-editing");
      cell.removeClass("is-edit-invalid");
      this.renderAll(true);
      this.focusRenderedActiveCell();
    };

    const editor = cell.createEl("input", { cls: "mt-cell-editor", type: inputTypeForField(field.type) });
    if (field.type === "attachment" || field.type === "noteLink") {
      editor.addClass("mt-cell-editor--file-name");
      const icon = cell.createSpan({ cls: "mt-cell-editor__file-icon", attr: { "aria-hidden": "true" } });
      setIcon(icon, linkedFieldIcon(field.type));
      const picker = cell.createEl("button", {
        cls: "clickable-icon mt-cell-editor__file-picker",
        attr: { type: "button", title: "选择文件", "aria-label": "选择文件" }
      });
      setIcon(picker, "folder-search");
      picker.addEventListener("pointerdown", (event) => {
        event.preventDefault();
        event.stopPropagation();
      });
      picker.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        this.openVaultFilePicker(field, (file) => {
          editor.value = file.path;
          commitMove("none");
        });
      });
    }
    editor.value = initial ?? this.editValue(record.values[field.id], field);
    editor.addEventListener("input", clearError);
    editor.addEventListener("keydown", (event) => {
      const keyboardEvent = event as KeyboardEvent;
      if (keyboardEvent.key === "Escape") {
        keyboardEvent.preventDefault();
        cancel();
        return;
      }
      if (keyboardEvent.key === "Tab") {
        keyboardEvent.preventDefault();
        commitMove(keyboardEvent.shiftKey ? "left" : "right");
        return;
      }
      if (keyboardEvent.key === "Enter" && !(editor instanceof HTMLTextAreaElement && keyboardEvent.shiftKey)) {
        keyboardEvent.preventDefault();
        commitMove("down");
      }
    });
    editor.addEventListener("blur", () => commitMove("none"));
    this.rootEl.win.setTimeout(() => {
      editor.focus();
      if (initial === undefined) editor.select();
      else editor.setSelectionRange(editor.value.length, editor.value.length);
    }, 0);
  }

  private commitRawValue(record: DuoweiRecord, field: DuoweiField, raw: string, label: string): CommitResult {
    try {
      if (isComputedField(field)) throw new Error(computedReadonlyMessage(field, false));
      this.applyMutation(label, (document) => {
        const targetField = document.fields.find((item) => item.id === field.id);
        const targetRecord = document.records.find((item) => item.id === record.id);
        if (!targetField || !targetRecord) return;
        targetRecord.values[targetField.id] = this.parseRawValue(raw, targetField, targetRecord.id);
        targetRecord.updatedAt = new Date().toISOString();
      });
      return { ok: true };
    } catch (error) {
      const message = error instanceof Error ? error.message : "单元格写入失败";
      this.setStatus(message, "error");
      new Notice(message, 3000);
      return { ok: false, message };
    }
  }

  private setCellValue(record: DuoweiRecord, field: DuoweiField, value: unknown, label: string): void {
    if (isComputedField(field)) return;
    this.applyMutation(label, (document) => {
      const targetRecord = document.records.find((item) => item.id === record.id);
      if (!targetRecord) return;
      targetRecord.values[field.id] = value;
      targetRecord.updatedAt = new Date().toISOString();
    });
  }

  private addRow(afterRow = this.activeCell?.rowIndex ?? this.visibleRecords.length - 1): void {
    this.applyMutation("新增行", (document) => {
      const record = createDuoweiRecord(document.fields);
      const visibleAfter = this.visibleRecords[afterRow];
      const sourceIndex = visibleAfter ? document.records.findIndex((item) => item.id === visibleAfter.id) : document.records.length - 1;
      const insertIndex = Math.max(0, sourceIndex + 1);
      document.records.splice(insertIndex, 0, record);
      this.activeCell = {
        recordId: record.id,
        fieldId: this.visibleFields()[this.activeCell?.columnIndex ?? 0]?.id ?? document.fields[0]?.id ?? "",
        rowIndex: Math.min(afterRow + 1, document.records.length - 1),
        columnIndex: this.activeCell?.columnIndex ?? 0
      };
    });
  }

  private addColumn(afterColumn = this.activeCell?.columnIndex ?? this.visibleFields().length - 1): void {
    this.applyMutation("新增列", (document) => {
      const field = createDuoweiField("text", this.uniqueFieldName("新字段"));
      document.fields.push(field);
      for (const view of document.views) {
        const insertAt = Math.max(0, Math.min(afterColumn + 1, view.fieldOrder.length));
        view.fieldOrder.splice(insertAt, 0, field.id);
      }
      this.activeCell = {
        recordId: this.visibleRecords[this.activeCell?.rowIndex ?? 0]?.id ?? document.records[0]?.id ?? "",
        fieldId: field.id,
        rowIndex: this.activeCell?.rowIndex ?? 0,
        columnIndex: Math.max(0, afterColumn + 1)
      };
    });
    this.renameFieldById(this.activeCell?.fieldId ?? "");
  }

  private deleteSelection(): void {
    const range = this.normalizedSelectionRange();
    if (!range) return;
    const fields = this.visibleFields();
    const allRows = range.rowStart === 0 && range.rowEnd === Math.max(0, this.visibleRecords.length - 1);
    const allColumns = range.columnStart === 0 && range.columnEnd === Math.max(0, fields.length - 1);
    if (allColumns && !allRows) {
      this.deleteRows(range.rowStart, range.rowEnd);
      return;
    }
    if (allRows && !allColumns) {
      this.deleteColumns(range.columnStart, range.columnEnd);
      return;
    }
    this.clearSelection();
  }

  private deleteRows(rowStart: number, rowEnd: number): void {
    const ids = new Set(this.visibleRecords.slice(rowStart, rowEnd + 1).map((record) => record.id));
    if (ids.size === 0) return;
    this.applyMutation("删除行", (document) => {
      document.records = document.records.filter((record) => !ids.has(record.id));
      this.activeCell = this.firstCell();
      this.selectionRange = this.activeCell
        ? {
            anchorRow: this.activeCell.rowIndex,
            anchorColumn: this.activeCell.columnIndex,
            focusRow: this.activeCell.rowIndex,
            focusColumn: this.activeCell.columnIndex
          }
        : null;
    });
  }

  private deleteColumns(columnStart: number, columnEnd: number): void {
    const fields = this.visibleFields().slice(columnStart, columnEnd + 1);
    if (fields.length === 0) return;
    const ids = new Set(fields.map((field) => field.id));
    this.applyMutation("删除列", (document) => {
      document.fields = document.fields.filter((field) => !ids.has(field.id));
      for (const record of document.records) {
        for (const id of ids) delete record.values[id];
      }
      for (const view of document.views) {
        view.fieldOrder = view.fieldOrder.filter((id) => !ids.has(id));
        view.hiddenFields = view.hiddenFields.filter((id) => !ids.has(id));
        view.sorts = view.sorts.filter((sort) => !ids.has(sort.fieldId));
        view.filters = view.filters.filter((filter) => !ids.has(filter.fieldId));
        if (view.type === "kanban") {
          if (view.groupFieldId && ids.has(view.groupFieldId)) view.groupFieldId = null;
          if (view.titleFieldId && ids.has(view.titleFieldId)) view.titleFieldId = null;
          view.cardFieldIds = view.cardFieldIds.filter((id) => !ids.has(id));
        }
        if (view.type === "gallery") {
          if (view.coverFieldId && ids.has(view.coverFieldId)) view.coverFieldId = null;
          if (view.titleFieldId && ids.has(view.titleFieldId)) view.titleFieldId = null;
          view.cardFieldIds = view.cardFieldIds.filter((id) => !ids.has(id));
        }
      }
      if (document.fields.length === 0) {
        const field = createDuoweiField("text", "字段");
        document.fields.push(field);
        for (const view of document.views) view.fieldOrder.push(field.id);
      }
      this.activeCell = this.firstCell();
      this.selectionRange = this.activeCell
        ? {
            anchorRow: this.activeCell.rowIndex,
            anchorColumn: this.activeCell.columnIndex,
            focusRow: this.activeCell.rowIndex,
            focusColumn: this.activeCell.columnIndex
          }
        : null;
    });
  }

  private clearSelection(): void {
    const range = this.normalizedSelectionRange();
    if (!range) return;
    const records = this.visibleRecords.slice(range.rowStart, range.rowEnd + 1);
    const fields = this.visibleFields().slice(range.columnStart, range.columnEnd + 1);
    this.applyMutation("清空单元格", (document) => {
      const ids = new Set(records.map((record) => record.id));
      for (const record of document.records) {
        if (!ids.has(record.id)) continue;
        for (const field of fields) {
          record.values[field.id] = field.type === "checkbox" ? false : undefined;
          record.updatedAt = new Date().toISOString();
        }
      }
    });
  }

  private canFillSelection(direction: "down" | "right"): boolean {
    const range = this.normalizedSelectionRange();
    if (!range) return false;
    if (direction === "down") return range.rowEnd > range.rowStart;
    return range.columnEnd > range.columnStart;
  }

  private fillSelection(direction: "down" | "right"): void {
    const range = this.normalizedSelectionRange();
    if (!range || !this.canFillSelection(direction)) return;
    this.fillRange(direction, range, range, direction === "down" ? "向下填充" : "向右填充");
  }

  private fillRange(
    direction: "down" | "right",
    sourceRange: NormalizedSelectionRange,
    targetRange: NormalizedSelectionRange,
    label: string
  ): void {
    const fields = this.visibleFields();
    const records = this.visibleRecords;
    this.applyMutation(label, (document) => {
      if (direction === "down") {
        const sourceRecord = records[sourceRange.rowStart];
        if (!sourceRecord) return;
        for (let rowIndex = sourceRange.rowEnd + 1; rowIndex <= targetRange.rowEnd; rowIndex += 1) {
          const targetVisibleRecord = records[rowIndex];
          const targetRecord = document.records.find((item) => item.id === targetVisibleRecord?.id);
          if (!targetRecord) continue;
          for (let columnIndex = sourceRange.columnStart; columnIndex <= sourceRange.columnEnd; columnIndex += 1) {
            const field = fields[columnIndex];
            if (!field) continue;
            if (isComputedField(field)) continue;
            targetRecord.values[field.id] = cloneCellValue(sourceRecord.values[field.id]);
            targetRecord.updatedAt = new Date().toISOString();
          }
        }
      } else {
        const sourceField = fields[sourceRange.columnStart];
        if (!sourceField) return;
        for (let rowIndex = sourceRange.rowStart; rowIndex <= sourceRange.rowEnd; rowIndex += 1) {
          const sourceRecord = records[rowIndex];
          const targetRecord = document.records.find((item) => item.id === sourceRecord?.id);
          if (!sourceRecord || !targetRecord) continue;
          for (let columnIndex = sourceRange.columnEnd + 1; columnIndex <= targetRange.columnEnd; columnIndex += 1) {
          const field = fields[columnIndex];
          if (!field) continue;
          if (isComputedField(field)) continue;
          targetRecord.values[field.id] = cloneCellValue(coerceValue(sourceRecord.values[sourceField.id], field));
          targetRecord.updatedAt = new Date().toISOString();
        }
        }
      }
    });
  }

  private openBulkEditPanel(anchor: HTMLElement): void {
    const range = this.normalizedSelectionRange();
    if (!range) return;
    const fields = this.visibleFields().slice(range.columnStart, range.columnEnd + 1);
    if (fields.length === 0) return;
    const panel = this.createPanel(anchor, "批量修改");
    const body = panel.body;
    const count = (range.rowEnd - range.rowStart + 1) * fields.length;
    const summary = body.createDiv({ cls: "mt-panel__empty", text: `将预览 ${count} 个单元格` });
    const row = body.createDiv({ cls: "mt-panel__rule" });
    row.createSpan({ cls: "mt-panel__rule-prefix", text: "值" });
    const input = row.createEl("input", { cls: "mt-panel__input", type: "text" });
    input.placeholder = fields.length === 1 ? fields[0]?.name ?? "值" : "按各列字段类型解析";
    const previewEl = body.createDiv({ cls: "mt-bulk-preview" });
    const applyBtn = panel.footer.createEl("button", { cls: "mt-panel__add", attr: { type: "button" } });
    setIcon(applyBtn.createSpan({ cls: "mt-panel__add-icon" }), "replace");
    const applyLabel = applyBtn.createSpan({ text: "应用可成功项" });
    let preview = this.createBulkEditPreview(range, input.value);
    const renderPreview = () => {
      preview = this.createBulkEditPreview(range, input.value);
      summary.setText(
        `预览 ${preview.total} 个单元格：${preview.changed} 个会修改，${preview.unchanged} 个不变，${preview.failed} 个失败`
      );
      applyLabel.setText(preview.failed > 0 ? "应用可成功项" : "应用到选区");
      applyBtn.disabled = preview.changed === 0;
      this.renderBulkEditPreview(previewEl, preview);
    };
    input.addEventListener("input", renderPreview);
    applyBtn.addEventListener("click", () => {
      const latest = this.createBulkEditPreview(range, input.value);
      if (latest.changed === 0) {
        new Notice(latest.failed > 0 ? "没有可应用的修改。" : "没有变化。", 3000);
        return;
      }
      this.applyBulkEditPreview(latest, input.value);
      panel.root.remove();
      if (latest.failed > 0) new Notice(`已应用 ${latest.changed} 项，跳过 ${latest.failed} 个失败单元格。`, 4000);
    });
    renderPreview();
    this.rootEl.win.setTimeout(() => input.focus(), 0);
  }

  private createBulkEditPreview(range: NormalizedSelectionRange, raw: string): BulkEditPreview {
    const fields = this.visibleFields();
    const records = this.visibleRecords;
    const items: BulkEditPreviewItem[] = [];
    for (let rowIndex = range.rowStart; rowIndex <= range.rowEnd; rowIndex += 1) {
      const record = records[rowIndex];
      if (!record) continue;
      for (let columnIndex = range.columnStart; columnIndex <= range.columnEnd; columnIndex += 1) {
        const field = fields[columnIndex];
        if (!field) continue;
        const before = record.values[field.id];
        const beforeDisplay = this.displayValue(before, field);
        if (isComputedField(field)) {
          items.push({
            recordId: record.id,
            rowIndex,
            fieldId: field.id,
            fieldName: field.name,
            columnIndex,
            before,
            beforeDisplay,
            afterDisplay: beforeDisplay,
            error: computedReadonlyMessage(field, false)
          });
          continue;
        }
        try {
          const previewField = cloneFieldForBulkParse(field);
          const after = this.parseRawValue(raw, previewField, record.id);
          const afterDisplay = this.displayValue(after, previewField);
          const changed = JSON.stringify(before) !== JSON.stringify(after);
          items.push({
            recordId: record.id,
            rowIndex,
            fieldId: field.id,
            fieldName: field.name,
            columnIndex,
            before,
            after,
            beforeDisplay,
            afterDisplay,
            error: changed ? undefined : ""
          });
        } catch (error) {
          items.push({
            recordId: record.id,
            rowIndex,
            fieldId: field.id,
            fieldName: field.name,
            columnIndex,
            before,
            beforeDisplay,
            afterDisplay: "",
            error: error instanceof Error ? error.message : "无法解析"
          });
        }
      }
    }
    const failed = items.filter((item) => item.error && item.after === undefined).length;
    const changed = items.filter((item) => !item.error && JSON.stringify(item.before) !== JSON.stringify(item.after)).length;
    return {
      total: items.length,
      changed,
      unchanged: items.length - changed - failed,
      failed,
      items
    };
  }

  private renderBulkEditPreview(container: HTMLElement, preview: BulkEditPreview): void {
    container.empty();
    const changedItems = preview.items.filter((item) => !item.error && JSON.stringify(item.before) !== JSON.stringify(item.after));
    const failedItems = preview.items.filter((item) => item.error && item.after === undefined);
    const sampleItems = [...failedItems.slice(0, 4), ...changedItems.slice(0, 6 - Math.min(4, failedItems.length))];
    if (sampleItems.length === 0) {
      container.createDiv({ cls: "mt-bulk-preview__empty", text: preview.failed > 0 ? "没有可应用的修改。" : "输入值与选区当前值一致。" });
      return;
    }
    for (const item of sampleItems) {
      const row = container.createDiv({ cls: item.error ? "mt-bulk-preview__item is-error" : "mt-bulk-preview__item" });
      row.createSpan({ cls: "mt-bulk-preview__cell", text: `${item.rowIndex + 1} 行 · ${item.fieldName}` });
      if (item.error) {
        row.createSpan({ cls: "mt-bulk-preview__error", text: item.error });
      } else {
        row.createSpan({ cls: "mt-bulk-preview__value", text: item.beforeDisplay || "空" });
        row.createSpan({ cls: "mt-bulk-preview__arrow", text: "→" });
        row.createSpan({ cls: "mt-bulk-preview__value", text: item.afterDisplay || "空" });
      }
    }
    const hidden = preview.items.length - sampleItems.length;
    if (hidden > 0) container.createDiv({ cls: "mt-bulk-preview__more", text: `还有 ${hidden} 项未显示` });
  }

  private applyBulkEditPreview(preview: BulkEditPreview, raw: string): void {
    const updates = preview.items.filter((item) => !item.error && JSON.stringify(item.before) !== JSON.stringify(item.after));
    if (updates.length === 0) return;
    this.applyMutation("批量修改", (document) => {
      for (const item of updates) {
        const record = document.records.find((candidate) => candidate.id === item.recordId);
        const field = document.fields.find((candidate) => candidate.id === item.fieldId);
        if (!record || !field) continue;
        if (isComputedField(field)) continue;
        record.values[field.id] = this.parseRawValue(raw, field, record.id);
        record.updatedAt = new Date().toISOString();
      }
    });
  }

  private async renameField(field: DuoweiField): Promise<void> {
    const next = await this.promptText("字段名称", field.name);
    if (!next || next.trim() === field.name) return;
    this.applyMutation("重命名字段", (document) => {
      const target = document.fields.find((item) => item.id === field.id);
      if (target) target.name = next.trim();
    });
  }

  private renameFieldById(fieldId: string): void {
    const field = this.documentModel.fields.find((item) => item.id === fieldId);
    if (field) void this.renameField(field);
  }

  private async setFieldSyncKey(field: DuoweiField): Promise<void> {
    const suggested = field.syncKey ?? frontmatterKeyFromFieldName(field.name);
    const next = await this.promptText("同步到笔记属性", suggested, "留空将取消字段同步。");
    if (next === null) return;
    const syncKey = next.trim();
    if (!syncKey) {
      this.clearFieldSyncKey(field);
      return;
    }
    this.applyMutation("设置字段同步属性", (document) => {
      const target = document.fields.find((item) => item.id === field.id);
      if (target) target.syncKey = syncKey;
    });
  }

  private clearFieldSyncKey(field: DuoweiField): void {
    this.applyMutation("取消字段同步", (document) => {
      const target = document.fields.find((item) => item.id === field.id);
      if (target) delete target.syncKey;
    });
  }

  private async changeFieldType(field: DuoweiField, type: DuoweiFieldType): Promise<void> {
    if (field.type === type) return;
    const previewField = cloneFieldForType(field, type);
    const impact = analyzeFieldMigration(this.documentModel.records, field, previewField);
    if (impact.nonEmpty > 0) {
      if (!(await this.confirmFieldMigration(field, previewField, impact))) return;
    }
    this.applyMutation("修改字段类型", (document) => {
      const target = document.fields.find((item) => item.id === field.id);
      if (!target) return;
      target.type = type;
      target.width = target.width ?? defaultFieldWidth(type);
      if ((type === "singleSelect" || type === "multiSelect") && !target.options) {
        target.options = [];
      }
      if (type !== "singleSelect" && type !== "multiSelect") {
        delete target.options;
      }
      for (const record of document.records) {
        try {
          record.values[target.id] = coerceValueForMigration(record.values[target.id], target);
        } catch {
          record.values[target.id] = target.type === "checkbox" ? false : undefined;
        }
      }
    });
  }

  private async addSelectOption(field: DuoweiField): Promise<void> {
    if (field.type !== "singleSelect" && field.type !== "multiSelect") return;
    const name = await this.promptText("选项名称", "新选项");
    if (!name?.trim()) return;
    this.applyMutation("新增选项", (document) => {
      const target = document.fields.find((item) => item.id === field.id);
      if (!target) return;
      target.options = target.options ?? [];
      target.options.push({
        id: `opt_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`,
        name: name.trim(),
        color: nextOptionColor(target.options)
      });
    });
  }

  private async renameSelectOption(field: DuoweiField): Promise<void> {
    if (field.type !== "singleSelect" && field.type !== "multiSelect") return;
    const option = await this.pickSelectOption(field, "选择要重命名的选项");
    if (!option) return;
    const next = await this.promptText("选项名称", option.name);
    if (!next?.trim() || next.trim() === option.name) return;
    this.applyMutation("重命名选项", (document) => {
      const target = document.fields.find((item) => item.id === field.id);
      const targetOption = target?.options?.find((item) => item.id === option.id);
      if (targetOption) targetOption.name = next.trim();
    });
  }

  private async recolorSelectOption(field: DuoweiField): Promise<void> {
    if (field.type !== "singleSelect" && field.type !== "multiSelect") return;
    const option = await this.pickSelectOption(field, "选择要设置颜色的选项");
    if (!option) return;
    const next = await this.promptText("选项颜色", option.color ?? "var(--interactive-accent)", "留空将移除自定义颜色。");
    if (next === null) return;
    this.applyMutation("设置选项颜色", (document) => {
      const target = document.fields.find((item) => item.id === field.id);
      const targetOption = target?.options?.find((item) => item.id === option.id);
      if (!targetOption) return;
      const value = next.trim();
      if (value) targetOption.color = value;
      else delete targetOption.color;
    });
  }

  private async deleteSelectOption(field: DuoweiField): Promise<void> {
    if (field.type !== "singleSelect" && field.type !== "multiSelect") return;
    const option = await this.pickSelectOption(field, "选择要删除的选项");
    if (!option) return;
    const usage = this.optionUsageCount(field, option.id);
    const message = usage > 0
      ? `删除“${option.name}”会清空 ${usage} 个单元格中的该选项，是否继续？`
      : `删除“${option.name}”？`;
    if (!(await this.confirmAction(message))) return;
    this.applyMutation("删除选项", (document) => {
      const target = document.fields.find((item) => item.id === field.id);
      if (!target?.options) return;
      target.options = target.options.filter((item) => item.id !== option.id);
      for (const record of document.records) {
        const value = record.values[field.id];
        if (target.type === "singleSelect" && value === option.id) {
          record.values[field.id] = undefined;
          record.updatedAt = new Date().toISOString();
        } else if (target.type === "multiSelect" && Array.isArray(value)) {
          const next = value.filter((item) => item !== option.id);
          if (next.length !== value.length) {
            record.values[field.id] = next.length > 0 ? next : undefined;
            record.updatedAt = new Date().toISOString();
          }
        }
      }
    });
  }

  private async pickSelectOption(field: DuoweiField, title: string): Promise<{ id: string; name: string; color?: string } | null> {
    const options = field.options ?? [];
    if (options.length === 0) {
      new Notice("这个字段还没有选项。", 3000);
      return null;
    }
    const labels = options.map((option, index) => `${index + 1}. ${option.name}`).join("\n");
    const answer = await this.promptText(title, "1", labels);
    if (!answer?.trim()) return null;
    const index = Number(answer.trim()) - 1;
    if (Number.isInteger(index) && index >= 0 && index < options.length) return options[index] ?? null;
    return options.find((option) => option.name === answer.trim() || option.id === answer.trim()) ?? null;
  }

  private async pickField(title: string, fields: DuoweiField[], currentFieldId?: string, description = ""): Promise<DuoweiField | null> {
    if (fields.length === 0) return null;
    const labels = fields
      .map((field, index) => {
        const current = field.id === currentFieldId ? "（当前）" : "";
        const typeLabel = FIELD_TYPES.find((item) => item.type === field.type)?.label ?? field.type;
        return `${index + 1}. ${field.name} · ${typeLabel}${current}`;
      })
      .join("\n");
    const answer = await this.promptText(title, currentFieldId ? String(Math.max(1, fields.findIndex((field) => field.id === currentFieldId) + 1)) : "1", description ? `${description}\n${labels}` : labels);
    if (!answer?.trim()) return null;
    const input = answer.trim();
    const index = Number(input) - 1;
    if (Number.isInteger(index) && index >= 0 && index < fields.length) return fields[index] ?? null;
    return fields.find((field) => field.id === input || field.name === input) ?? null;
  }

  private optionUsageCount(field: DuoweiField, optionId: string): number {
    let count = 0;
    for (const record of this.documentModel.records) {
      const value = record.values[field.id];
      if (field.type === "singleSelect" && value === optionId) count += 1;
      if (field.type === "multiSelect" && Array.isArray(value) && value.includes(optionId)) count += 1;
    }
    return count;
  }

  private openFieldMenu(anchor: HTMLElement, field: DuoweiField, columnIndex: number): void {
    const menu = new Menu();
    menu.addItem((item) => {
      item.setTitle("重命名字段").setIcon("pencil");
      item.onClick(() => void this.renameField(field));
    });
    if (!isComputedField(field)) {
      menu.addItem((item) => {
        item.setTitle(field.syncKey ? `同步属性：${field.syncKey}` : "设置同步属性").setIcon("refresh-cw");
        item.onClick(() => void this.setFieldSyncKey(field));
      });
      if (field.syncKey) {
        menu.addItem((item) => {
          item.setTitle("取消字段同步").setIcon("unlink");
          item.onClick(() => this.clearFieldSyncKey(field));
        });
      }
    }
    menu.addItem((item) => {
      item.setTitle("在右侧新增列").setIcon("plus");
      item.onClick(() => this.addColumn(columnIndex));
    });
    menu.addSeparator();
    for (const option of FIELD_TYPES) {
      menu.addItem((item) => {
        item.setTitle(option.label).setIcon(option.icon).setChecked(field.type === option.type);
        item.onClick(() => void this.changeFieldType(field, option.type));
      });
    }
    if (field.type === "singleSelect" || field.type === "multiSelect") {
      menu.addSeparator();
      menu.addItem((item) => {
        item.setTitle("新增选项").setIcon("plus-circle");
        item.onClick(() => void this.addSelectOption(field));
      });
      menu.addItem((item) => {
        item.setTitle("重命名选项").setIcon("pencil");
        item.onClick(() => void this.renameSelectOption(field));
      });
      menu.addItem((item) => {
        item.setTitle("设置选项颜色").setIcon("palette");
        item.onClick(() => void this.recolorSelectOption(field));
      });
      menu.addItem((item) => {
        item.setTitle("删除选项").setIcon("trash-2").setWarning(true);
        item.onClick(() => void this.deleteSelectOption(field));
      });
    }
    menu.addSeparator();
    menu.addItem((item) => {
      item.setTitle("删除字段").setIcon("trash-2").setWarning(true);
      item.onClick(() => this.deleteColumns(columnIndex, columnIndex));
    });
    const rect = anchor.getBoundingClientRect();
    menu.showAtPosition({ x: rect.left, y: rect.bottom + 4 });
  }

  private openFieldsPanel(anchor: HTMLElement): void {
    if (this.currentView().type === "kanban") {
      this.openKanbanSettingsPanel(anchor);
      return;
    }
    if (this.currentView().type === "gallery") {
      this.openGallerySettingsPanel(anchor);
      return;
    }
    const panel = this.createPanel(anchor, "字段");
    const list = panel.body.createDiv({ cls: "mt-panel__list" });
    const render = () => {
      list.empty();
      const view = this.currentView();
      const hidden = new Set(view.hiddenFields);
      const fields = view.fieldOrder
        .map((fieldId) => this.documentModel.fields.find((field) => field.id === fieldId))
        .filter((field): field is DuoweiField => Boolean(field));
      for (const field of fields) {
        const row = list.createDiv({ cls: "mt-panel__rule mt-duowei-field-row" });
        const checkbox = row.createEl("input", {
          type: "checkbox",
          cls: "mt-row-checkbox",
          attr: { "aria-label": `显示 ${field.name}` }
        });
        checkbox.checked = !hidden.has(field.id);
        row.createSpan({ cls: "mt-panel__rule-prefix mt-duowei-field-icon" }, (span) => setIcon(span, this.fieldTypeIcon(field.type)));
        row.createSpan({ cls: "mt-duowei-field-name", text: field.name });
        checkbox.addEventListener("change", () => {
          this.applyMutation(checkbox.checked ? "显示字段" : "隐藏字段", (document) => {
            const target = document.views.find((item) => item.type === "grid");
            if (!target) return;
            const nextHidden = new Set(target.hiddenFields);
            if (checkbox.checked) nextHidden.delete(field.id);
            else nextHidden.add(field.id);
            if (nextHidden.size >= document.fields.length) nextHidden.delete(field.id);
            target.hiddenFields = [...nextHidden];
          });
          render();
        });
      }
    };
    render();

    const addBtn = panel.footer.createEl("button", { cls: "mt-panel__add", attr: { type: "button" } });
    setIcon(addBtn.createSpan({ cls: "mt-panel__add-icon" }), "plus");
    addBtn.createSpan({ text: "新增字段" });
    addBtn.addEventListener("click", () => {
      this.addColumn(this.visibleFields().length - 1);
      panel.root.remove();
    });
  }

  private openKanbanSettingsPanel(anchor: HTMLElement): void {
    const view = this.currentView();
    if (view.type !== "kanban") return;
    const fields = this.documentModel.fields;
    const panel = this.createPanel(anchor, "看板字段");
    const body = panel.body;

    const groupRow = body.createDiv({ cls: "mt-panel__rule mt-duowei-setting-row" });
    groupRow.createSpan({ cls: "mt-panel__rule-prefix", text: "分组" });
    const groupSelect = groupRow.createEl("select", { cls: "mt-panel__select" });
    for (const field of fields) {
      const option = groupSelect.createEl("option", { value: field.id, text: field.name });
      if (field.id === view.groupFieldId) option.selected = true;
    }
    groupSelect.addEventListener("change", () => {
      this.applyKanbanRules("设置看板分组", (kanban) => {
        kanban.groupFieldId = groupSelect.value;
      });
    });

    const titleRow = body.createDiv({ cls: "mt-panel__rule mt-duowei-setting-row" });
    titleRow.createSpan({ cls: "mt-panel__rule-prefix", text: "标题" });
    const titleSelect = titleRow.createEl("select", { cls: "mt-panel__select" });
    for (const field of fields) {
      const option = titleSelect.createEl("option", { value: field.id, text: field.name });
      if (field.id === view.titleFieldId) option.selected = true;
    }
    titleSelect.addEventListener("change", () => {
      this.applyKanbanRules("设置看板标题", (kanban) => {
        kanban.titleFieldId = titleSelect.value;
      });
    });

    body.createDiv({ cls: "mt-panel__empty", text: "卡片显示字段" });
    const selected = new Set(view.cardFieldIds);
    for (const field of fields) {
      const row = body.createDiv({ cls: "mt-panel__rule mt-duowei-field-row" });
      const checkbox = row.createEl("input", {
        type: "checkbox",
        cls: "mt-row-checkbox",
        attr: { "aria-label": `显示 ${field.name}` }
      });
      checkbox.checked = selected.has(field.id);
      row.createSpan({ cls: "mt-panel__rule-prefix mt-duowei-field-icon" }, (span) => setIcon(span, this.fieldTypeIcon(field.type)));
      row.createSpan({ cls: "mt-duowei-field-name", text: field.name });
      checkbox.addEventListener("change", () => {
        this.applyKanbanRules("设置看板卡片字段", (kanban) => {
          const next = new Set(kanban.cardFieldIds);
          if (checkbox.checked) next.add(field.id);
          else next.delete(field.id);
          kanban.cardFieldIds = [...next];
        });
      });
    }
  }

  private openGallerySettingsPanel(anchor: HTMLElement): void {
    const view = this.currentView();
    if (view.type !== "gallery") return;
    const fields = this.documentModel.fields;
    const panel = this.createPanel(anchor, "画廊字段");
    const body = panel.body;

    const coverRow = body.createDiv({ cls: "mt-panel__rule mt-duowei-setting-row" });
    coverRow.createSpan({ cls: "mt-panel__rule-prefix", text: "封面" });
    const coverSelect = coverRow.createEl("select", { cls: "mt-panel__select" });
    const noCover = coverSelect.createEl("option", { value: "", text: "无封面" });
    if (!view.coverFieldId) noCover.selected = true;
    for (const field of fields) {
      const option = coverSelect.createEl("option", { value: field.id, text: field.name });
      if (field.id === view.coverFieldId) option.selected = true;
    }
    coverSelect.addEventListener("change", () => {
      this.applyGalleryRules("设置画廊封面", (gallery) => {
        gallery.coverFieldId = coverSelect.value || null;
      });
    });

    const titleRow = body.createDiv({ cls: "mt-panel__rule mt-duowei-setting-row" });
    titleRow.createSpan({ cls: "mt-panel__rule-prefix", text: "标题" });
    const titleSelect = titleRow.createEl("select", { cls: "mt-panel__select" });
    for (const field of fields) {
      const option = titleSelect.createEl("option", { value: field.id, text: field.name });
      if (field.id === view.titleFieldId) option.selected = true;
    }
    titleSelect.addEventListener("change", () => {
      this.applyGalleryRules("设置画廊标题", (gallery) => {
        gallery.titleFieldId = titleSelect.value;
      });
    });

    body.createDiv({ cls: "mt-panel__empty", text: "卡片显示字段" });
    const selected = new Set(view.cardFieldIds);
    for (const field of fields) {
      const row = body.createDiv({ cls: "mt-panel__rule mt-duowei-field-row" });
      const checkbox = row.createEl("input", {
        type: "checkbox",
        cls: "mt-row-checkbox",
        attr: { "aria-label": `显示 ${field.name}` }
      });
      checkbox.checked = selected.has(field.id);
      row.createSpan({ cls: "mt-panel__rule-prefix mt-duowei-field-icon" }, (span) => setIcon(span, this.fieldTypeIcon(field.type)));
      row.createSpan({ cls: "mt-duowei-field-name", text: field.name });
      checkbox.addEventListener("change", () => {
        this.applyGalleryRules("设置画廊卡片字段", (gallery) => {
          const next = new Set(gallery.cardFieldIds);
          if (checkbox.checked) next.add(field.id);
          else next.delete(field.id);
          gallery.cardFieldIds = [...next];
        });
      });
    }
  }

  private openFilterPanel(anchor: HTMLElement): void {
    const fields = this.documentModel.fields;
    const draft: DuoweiFilterRule[] = this.currentView().filters.map((rule) => ({ ...rule }));
    const opLabels: Record<DuoweiFilterRule["op"], string> = {
      contains: "包含",
      equals: "等于",
      empty: "为空",
      notEmpty: "不为空"
    };
    const apply = () => {
      this.applyViewRules("更新筛选", (view) => {
        view.filters = draft.filter((rule) => fields.some((field) => field.id === rule.fieldId));
      });
    };

    const panel = this.createPanel(anchor, "筛选");
    const list = panel.body.createDiv({ cls: "mt-panel__list" });
    const render = () => {
      list.empty();
      if (draft.length === 0) {
        list.createDiv({ cls: "mt-panel__empty", text: "暂无筛选条件" });
      }
      draft.forEach((rule, index) => {
        const row = list.createDiv({ cls: "mt-panel__rule" });
        row.createSpan({ cls: "mt-panel__rule-prefix", text: index === 0 ? "当" : "且" });
        const fieldSelect = row.createEl("select", { cls: "mt-panel__select" });
        for (const field of fields) {
          const option = fieldSelect.createEl("option", { value: field.id, text: field.name });
          if (field.id === rule.fieldId) option.selected = true;
        }
        fieldSelect.addEventListener("change", () => {
          rule.fieldId = fieldSelect.value;
          apply();
        });
        const opSelect = row.createEl("select", { cls: "mt-panel__select mt-panel__select--op" });
        for (const op of Object.keys(opLabels) as DuoweiFilterRule["op"][]) {
          const option = opSelect.createEl("option", { value: op, text: opLabels[op] });
          if (op === rule.op) option.selected = true;
        }
        opSelect.addEventListener("change", () => {
          rule.op = opSelect.value as DuoweiFilterRule["op"];
          render();
          apply();
        });
        if (rule.op !== "empty" && rule.op !== "notEmpty") {
          const input = row.createEl("input", { cls: "mt-panel__input", type: "text", value: rule.value });
          input.placeholder = "值";
          input.addEventListener("input", () => {
            rule.value = input.value;
            apply();
          });
        }
        const remove = row.createEl("button", {
          cls: "clickable-icon mt-panel__remove",
          attr: { type: "button", "aria-label": "删除条件" }
        });
        setIcon(remove, "x");
        remove.addEventListener("click", () => {
          draft.splice(index, 1);
          render();
          apply();
        });
      });
    };
    render();

    const addBtn = panel.footer.createEl("button", { cls: "mt-panel__add", attr: { type: "button" } });
    setIcon(addBtn.createSpan({ cls: "mt-panel__add-icon" }), "plus");
    addBtn.createSpan({ text: "添加条件" });
    addBtn.addEventListener("click", () => {
      const field = fields[0];
      if (!field) return;
      draft.push({ fieldId: field.id, op: "contains", value: "" });
      render();
      apply();
    });
  }

  private openSortPanel(anchor: HTMLElement): void {
    const fields = this.documentModel.fields;
    const draft: DuoweiSortRule[] = this.currentView().sorts.map((rule) => ({ ...rule }));
    const apply = () => {
      this.applyViewRules("更新排序", (view) => {
        view.sorts = draft.filter((rule) => fields.some((field) => field.id === rule.fieldId));
      });
    };

    const panel = this.createPanel(anchor, "排序");
    const list = panel.body.createDiv({ cls: "mt-panel__list" });
    const render = () => {
      list.empty();
      if (draft.length === 0) {
        list.createDiv({ cls: "mt-panel__empty", text: "暂无排序规则" });
      }
      draft.forEach((rule, index) => {
        const row = list.createDiv({ cls: "mt-panel__rule" });
        const fieldSelect = row.createEl("select", { cls: "mt-panel__select" });
        for (const field of fields) {
          const option = fieldSelect.createEl("option", { value: field.id, text: field.name });
          if (field.id === rule.fieldId) option.selected = true;
        }
        fieldSelect.addEventListener("change", () => {
          rule.fieldId = fieldSelect.value;
          apply();
        });
        const dirSelect = row.createEl("select", { cls: "mt-panel__select mt-panel__select--op" });
        const asc = dirSelect.createEl("option", { value: "asc", text: "升序" });
        const desc = dirSelect.createEl("option", { value: "desc", text: "降序" });
        if (rule.direction === "asc") asc.selected = true;
        else desc.selected = true;
        dirSelect.addEventListener("change", () => {
          rule.direction = dirSelect.value as DuoweiSortRule["direction"];
          apply();
        });
        const remove = row.createEl("button", {
          cls: "clickable-icon mt-panel__remove",
          attr: { type: "button", "aria-label": "删除排序" }
        });
        setIcon(remove, "x");
        remove.addEventListener("click", () => {
          draft.splice(index, 1);
          render();
          apply();
        });
      });
    };
    render();

    const addBtn = panel.footer.createEl("button", { cls: "mt-panel__add", attr: { type: "button" } });
    setIcon(addBtn.createSpan({ cls: "mt-panel__add-icon" }), "plus");
    addBtn.createSpan({ text: "添加排序" });
    addBtn.addEventListener("click", () => {
      const used = new Set(draft.map((rule) => rule.fieldId));
      const field = fields.find((item) => !used.has(item.id)) ?? fields[0];
      if (!field) return;
      draft.push({ fieldId: field.id, direction: "asc" });
      render();
      apply();
    });
  }

  private openDensityMenu(anchor: HTMLElement): void {
    const current = this.currentView();
    if (current.type !== "grid") return;
    const menu = new Menu();
    const options: Array<{ value: DuoweiGridViewConfig["rowHeight"]; label: string }> = [
      { value: "compact", label: "紧凑" },
      { value: "default", label: "标准" },
      { value: "comfortable", label: "舒适" }
    ];
    for (const option of options) {
      menu.addItem((item) => {
        item.setTitle(option.label).setChecked(current.rowHeight === option.value);
        item.onClick(() => {
          this.applyViewRules("调整行高", (view) => {
            if (view.type === "grid") view.rowHeight = option.value;
          });
        });
      });
    }
    const rect = anchor.getBoundingClientRect();
    menu.showAtPosition({ x: rect.left, y: rect.bottom + 4 });
  }

  private openFreezeMenu(anchor: HTMLElement): void {
    const current = this.currentView();
    if (current.type !== "grid") return;
    const fields = this.visibleFields();
    const max = fields.length;
    const currentCount = this.frozenFieldCount(fields);
    const menu = new Menu();
    const presets = Array.from(new Set([0, 1, 2, 3, max].filter((count) => count >= 0 && count <= max)));
    for (const count of presets) {
      menu.addItem((item) => {
        item.setTitle(count === 0 ? "不冻结列" : count === max ? "冻结全部可见列" : `冻结前 ${count} 列`);
        item.setIcon(count > 0 ? "panel-left" : "panel-left-close");
        item.setChecked(currentCount === count);
        item.onClick(() => this.setFrozenFieldCount(count));
      });
    }
    menu.addSeparator();
    menu.addItem((item) => {
      item.setTitle("冻结到当前列").setIcon("move-horizontal").setDisabled(!this.activeCell);
      item.onClick(() => {
        if (!this.activeCell) return;
        this.setFrozenFieldCount(this.activeCell.columnIndex + 1);
      });
    });
    menu.addItem((item) => {
      item.setTitle("少冻结一列").setIcon("minus").setDisabled(currentCount <= 0);
      item.onClick(() => this.setFrozenFieldCount(Math.max(0, currentCount - 1)));
    });
    menu.addItem((item) => {
      item.setTitle("多冻结一列").setIcon("plus").setDisabled(currentCount >= max);
      item.onClick(() => this.setFrozenFieldCount(Math.min(max, currentCount + 1)));
    });
    const rect = anchor.getBoundingClientRect();
    menu.showAtPosition({ x: rect.left, y: rect.bottom + 4 });
  }

  private setFrozenFieldCount(count: number): void {
    const visibleCount = this.visibleFields().length;
    const nextCount = clamp(Math.floor(count), 0, visibleCount);
    this.applyViewRules("设置冻结列", (view) => {
      if (view.type === "grid") view.frozenFieldCount = nextCount;
    });
  }

  private createPanel(anchor: HTMLElement, title: string): { root: HTMLElement; body: HTMLElement; footer: HTMLElement } {
    const root = this.rootEl.doc.body.createDiv({ cls: "mt-panel" });
    const header = root.createDiv({ cls: "mt-panel__header" });
    header.createSpan({ cls: "mt-panel__title", text: title });
    const body = root.createDiv({ cls: "mt-panel__body" });
    const footer = root.createDiv({ cls: "mt-panel__footer" });

    const rect = anchor.getBoundingClientRect();
    root.style.top = `${rect.bottom + 6}px`;
    root.style.left = `${Math.min(rect.left, this.rootEl.win.innerWidth - 380)}px`;

    let closed = false;
    const close = () => {
      if (closed) return;
      closed = true;
      this.rootEl.doc.removeEventListener("pointerdown", onOutside, true);
      root.remove();
    };
    const onOutside = (event: PointerEvent) => {
      if (!root.contains(event.target as Node)) close();
    };
    root.addEventListener("pointerdown", (event) => event.stopPropagation());
    this.rootEl.win.setTimeout(() => this.rootEl.doc.addEventListener("pointerdown", onOutside, true), 0);
    return { root, body, footer };
  }

  private promptText(title: string, initialValue = "", description = ""): Promise<string | null> {
    return new Promise((resolve) => {
      const root = this.rootEl.doc.body.createDiv({ cls: "mt-dialog" });
      const panel = root.createDiv({ cls: "mt-dialog__panel" });
      panel.createDiv({ cls: "mt-dialog__title", text: title });
      if (description) {
        const desc = panel.createDiv({ cls: "mt-dialog__description" });
        for (const line of description.split("\n")) desc.createDiv({ text: line });
      }
      const input = panel.createEl("input", { cls: "mt-dialog__input", type: "text", value: initialValue });
      const actions = panel.createDiv({ cls: "mt-dialog__actions" });
      const cancel = actions.createEl("button", { cls: "mt-dialog__button", text: "取消", attr: { type: "button" } });
      const confirm = actions.createEl("button", {
        cls: "mt-dialog__button mt-dialog__button--primary",
        text: "确定",
        attr: { type: "button" }
      });
      let settled = false;
      const close = (value: string | null) => {
        if (settled) return;
        settled = true;
        this.rootEl.doc.removeEventListener("keydown", onKeydown, true);
        root.remove();
        resolve(value);
      };
      const onKeydown = (event: KeyboardEvent) => {
        if (event.key === "Escape") {
          event.preventDefault();
          close(null);
        }
        if (event.key === "Enter") {
          event.preventDefault();
          close(input.value);
        }
      };
      cancel.addEventListener("click", () => close(null));
      confirm.addEventListener("click", () => close(input.value));
      root.addEventListener("pointerdown", (event) => {
        if (event.target === root) close(null);
      });
      this.rootEl.doc.addEventListener("keydown", onKeydown, true);
      this.rootEl.win.setTimeout(() => {
        input.focus();
        input.select();
      }, 0);
    });
  }

  private confirmAction(message: string, title = "确认操作"): Promise<boolean> {
    return new Promise((resolve) => {
      const root = this.rootEl.doc.body.createDiv({ cls: "mt-dialog" });
      const panel = root.createDiv({ cls: "mt-dialog__panel" });
      panel.createDiv({ cls: "mt-dialog__title", text: title });
      const desc = panel.createDiv({ cls: "mt-dialog__description" });
      for (const line of message.split("\n")) desc.createDiv({ text: line });
      const actions = panel.createDiv({ cls: "mt-dialog__actions" });
      const cancel = actions.createEl("button", { cls: "mt-dialog__button", text: "取消", attr: { type: "button" } });
      const confirm = actions.createEl("button", {
        cls: "mt-dialog__button mt-dialog__button--danger",
        text: "继续",
        attr: { type: "button" }
      });
      let settled = false;
      const close = (value: boolean) => {
        if (settled) return;
        settled = true;
        this.rootEl.doc.removeEventListener("keydown", onKeydown, true);
        root.remove();
        resolve(value);
      };
      const onKeydown = (event: KeyboardEvent) => {
        if (event.key === "Escape") {
          event.preventDefault();
          close(false);
        }
        if (event.key === "Enter") {
          event.preventDefault();
          close(true);
        }
      };
      cancel.addEventListener("click", () => close(false));
      confirm.addEventListener("click", () => close(true));
      root.addEventListener("pointerdown", (event) => {
        if (event.target === root) close(false);
      });
      this.rootEl.doc.addEventListener("keydown", onKeydown, true);
      this.rootEl.win.setTimeout(() => confirm.focus(), 0);
    });
  }

  private applyViewRules(label: string, mutator: (view: DuoweiViewConfig) => void): void {
    this.applyMutation(label, (document) => {
      let view = document.views.find((item) => item.id === document.activeViewId);
      if (!view) {
        view = createDefaultGridView(document.fields);
        document.views = [view];
        document.activeViewId = view.id;
      }
      mutator(view);
    });
  }

  private applyKanbanRules(label: string, mutator: (view: DuoweiKanbanViewConfig) => void): void {
    this.applyMutation(label, (document) => {
      let view = document.views.find((item): item is DuoweiKanbanViewConfig => item.type === "kanban");
      if (!view) {
        view = createDefaultKanbanView(document.fields);
        document.views.push(view);
      }
      mutator(view);
      document.activeViewId = view.id;
    });
  }

  private applyGalleryRules(label: string, mutator: (view: DuoweiGalleryViewConfig) => void): void {
    this.applyMutation(label, (document) => {
      let view = document.views.find((item): item is DuoweiGalleryViewConfig => item.type === "gallery");
      if (!view) {
        view = createDefaultGalleryView(document.fields);
        document.views.push(view);
      }
      mutator(view);
      document.activeViewId = view.id;
    });
  }

  private openOverflowMenu(anchor: HTMLElement): void {
    const menu = new Menu();
    if (this.currentView().type === "grid") {
      menu.addItem((item) => {
        item.setTitle("复制选区").setIcon("copy").setDisabled(!this.normalizedSelectionRange());
        item.onClick(() => this.copySelectionToClipboard());
      });
      menu.addItem((item) => {
        item.setTitle("清空选区").setIcon("eraser").setDisabled(!this.normalizedSelectionRange());
        item.onClick(() => this.clearSelection());
      });
      menu.addItem((item) => {
        item.setTitle("向下填充").setIcon("arrow-down").setDisabled(!this.canFillSelection("down"));
        item.onClick(() => this.fillSelection("down"));
      });
      menu.addItem((item) => {
        item.setTitle("向右填充").setIcon("arrow-right").setDisabled(!this.canFillSelection("right"));
        item.onClick(() => this.fillSelection("right"));
      });
      menu.addItem((item) => {
        item.setTitle("批量修改选区").setIcon("replace").setDisabled(!this.normalizedSelectionRange());
        item.onClick(() => this.openBulkEditPanel(anchor));
      });
      menu.addSeparator();
    } else if (this.currentView().type === "kanban") {
      menu.addItem((item) => {
        item.setTitle("看板字段设置").setIcon("settings-2");
        item.onClick(() => this.openKanbanSettingsPanel(anchor));
      });
      menu.addSeparator();
    } else if (this.currentView().type === "gallery") {
      menu.addItem((item) => {
        item.setTitle("画廊字段设置").setIcon("settings-2");
        item.onClick(() => this.openGallerySettingsPanel(anchor));
      });
      menu.addSeparator();
    }
    menu.addItem((item) => {
      item.setTitle("新增行").setIcon("plus");
      item.onClick(() => this.addRow());
    });
    menu.addItem((item) => {
      item.setTitle("新增列").setIcon("columns-3");
      item.onClick(() => this.addColumn());
    });
    menu.addSeparator();
    menu.addItem((item) => {
      const count = this.documentModel.records.filter((record) => typeof record.notePath === "string" && record.notePath).length;
      item.setTitle("同步所有绑定记录").setIcon("refresh-cw").setDisabled(count === 0 || this.syncableFields().length === 0);
      item.onClick(() => void this.syncAllBoundRecords());
    });
    menu.addItem((item) => {
      item.setTitle("同步日志").setIcon("list-checks").setDisabled(this.syncLog.length === 0);
      item.onClick(() => this.openSyncLogPanel(anchor));
    });
    menu.addItem((item) => {
      item.setTitle("操作日志").setIcon("history").setDisabled(this.allOperationLog().length === 0);
      item.onClick(() => this.openOperationLogPanel(anchor));
    });
    menu.addItem((item) => {
      item.setTitle("冲突恢复").setIcon("shield-alert").setDisabled(!this.lastConflictBackupPath);
      item.onClick(() => this.openConflictRecoveryPanel(anchor));
    });
    menu.addItem((item) => {
      item.setTitle("备份恢复").setIcon("archive-restore");
      item.onClick(() => this.openBackupRecoveryPanel(anchor));
    });
    menu.addSeparator();
    menu.addItem((item) => {
      item.setTitle("导入 CSV/TSV").setIcon("upload");
      item.onClick(() => this.importDelimitedFile());
    });
    const rect = anchor.getBoundingClientRect();
    menu.showAtPosition({ x: rect.right, y: rect.bottom + 4 });
  }

  private openSyncLogPanel(anchor: HTMLElement): void {
    const panel = this.createPanel(anchor, "同步日志");
    panel.root.addClass("mt-panel--sync-log");
    const body = panel.body;
    const footer = panel.footer;
    if (this.syncLog.length === 0) {
      body.createDiv({ cls: "mt-panel__empty", text: "还没有同步记录。" });
      return;
    }
    const counts = this.syncLog.reduce(
      (acc, item) => {
        acc[item.status] += 1;
        return acc;
      },
      { synced: 0, skipped: 0, failed: 0 }
    );
    const summary = body.createDiv({ cls: "mt-sync-log-summary" });
    this.renderSyncLogStat(summary, "成功", counts.synced, "synced");
    this.renderSyncLogStat(summary, "跳过", counts.skipped, "skipped");
    this.renderSyncLogStat(summary, "失败", counts.failed, "failed");

    const list = body.createDiv({ cls: "mt-sync-log-list" });
    for (const item of this.syncLog) {
      const row = list.createDiv({ cls: `mt-sync-log-item is-${item.status}` });
      const icon = row.createSpan({ cls: "mt-sync-log-item__icon", attr: { "aria-hidden": "true" } });
      setIcon(icon, item.status === "synced" ? "check-circle-2" : item.status === "failed" ? "circle-alert" : "circle-minus");
      const text = row.createDiv({ cls: "mt-sync-log-item__text" });
      text.createDiv({ cls: "mt-sync-log-item__title", text: item.title });
      text.createDiv({ cls: "mt-sync-log-item__path", text: item.notePath ?? "未绑定笔记" });
      text.createDiv({ cls: "mt-sync-log-item__message", text: item.message });
      row.createDiv({ cls: "mt-sync-log-item__time", text: syncTimeLabel(item.at) });
    }

    const actions = footer.createDiv({ cls: "mt-conflict-actions" });
    const retry = actions.createEl("button", { cls: "mt-dialog__button mt-dialog__button--primary", text: "重试失败项", attr: { type: "button" } });
    retry.disabled = counts.failed === 0;
    retry.addEventListener("click", () => {
      panel.root.remove();
      void this.retryFailedSync();
    });
    const clear = actions.createEl("button", { cls: "mt-dialog__button", text: "清空日志", attr: { type: "button" } });
    clear.addEventListener("click", () => {
      this.syncLog = [];
      panel.root.remove();
    });
  }

  private renderSyncLogStat(parent: HTMLElement, label: string, value: number, status: SyncLogItem["status"]): void {
    const item = parent.createDiv({ cls: `mt-sync-log-stat is-${status}` });
    item.createDiv({ cls: "mt-sync-log-stat__value", text: value.toLocaleString() });
    item.createDiv({ cls: "mt-sync-log-stat__label", text: label });
  }

  private openOperationLogPanel(anchor: HTMLElement): void {
    const panel = this.createPanel(anchor, "操作日志");
    panel.root.addClass("mt-panel--operation-log");
    const body = panel.body;
    const footer = panel.footer;
    const logs = this.allOperationLog();
    if (logs.length === 0) {
      body.createDiv({ cls: "mt-panel__empty", text: "还没有操作记录。" });
      return;
    }
    const counts = logs.reduce(
      (acc, item) => {
        acc[item.status] += 1;
        return acc;
      },
      { ok: 0, warning: 0, error: 0 }
    );
    const summary = body.createDiv({ cls: "mt-sync-log-summary mt-operation-log-summary" });
    this.renderOperationLogStat(summary, "正常", counts.ok, "ok");
    this.renderOperationLogStat(summary, "提醒", counts.warning, "warning");
    this.renderOperationLogStat(summary, "错误", counts.error, "error");

    const list = body.createDiv({ cls: "mt-sync-log-list mt-operation-log-list" });
    for (const item of logs) {
      const row = list.createDiv({ cls: `mt-sync-log-item mt-operation-log-item is-${item.status}` });
      const icon = row.createSpan({ cls: "mt-sync-log-item__icon", attr: { "aria-hidden": "true" } });
      setIcon(icon, operationLogIcon(item));
      const text = row.createDiv({ cls: "mt-sync-log-item__text" });
      text.createDiv({ cls: "mt-sync-log-item__title", text: item.label });
      text.createDiv({ cls: "mt-sync-log-item__path", text: operationLogTypeLabel(item.type) });
      if (item.detail) text.createDiv({ cls: "mt-sync-log-item__message", text: item.detail });
      row.createDiv({ cls: "mt-sync-log-item__time", text: syncTimeLabel(item.at) });
    }

    const actions = footer.createDiv({ cls: "mt-conflict-actions" });
    const clear = actions.createEl("button", { cls: "mt-dialog__button", text: "清空日志", attr: { type: "button" } });
    clear.addEventListener("click", () => {
      this.operationLog = [];
      this.options.clearOperationLog?.();
      panel.root.remove();
    });
  }

  private renderOperationLogStat(parent: HTMLElement, label: string, value: number, status: OperationLogItem["status"]): void {
    const item = parent.createDiv({ cls: `mt-sync-log-stat mt-operation-log-stat is-${status}` });
    item.createDiv({ cls: "mt-sync-log-stat__value", text: value.toLocaleString() });
    item.createDiv({ cls: "mt-sync-log-stat__label", text: label });
  }

  private addOperationLog(
    type: OperationLogItem["type"],
    label: string,
    detail = "",
    status: OperationLogItem["status"] = "ok"
  ): void {
    const item = {
      id: createId("op"),
      at: new Date().toISOString(),
      type,
      label,
      detail,
      status
    };
    this.operationLog = [item, ...this.operationLog].slice(0, this.duoweiSettings().operationLogRetention);
    this.options.appendOperationLog?.(item);
  }

  private allOperationLog(): OperationLogItem[] {
    const external = this.options.getOperationLog?.();
    return external ? external.slice(0, this.duoweiSettings().operationLogRetention) : this.operationLog;
  }

  private openCellContextMenu(event: MouseEvent): void {
    if (this.currentView().type !== "grid") return;
    const cell = (event.target as HTMLElement | null)?.closest(".mt-grid-cell") as HTMLElement | null;
    if (!cell) return;
    event.preventDefault();
    const rowIndex = Number(cell.dataset.row);
    const columnIndex = Number(cell.dataset.column);
    if (Number.isFinite(rowIndex) && Number.isFinite(columnIndex) && !this.isCellSelected(rowIndex, columnIndex)) {
      const record = this.visibleRecords[rowIndex];
      const field = this.visibleFields()[columnIndex];
      if (record && field) {
        this.activeCell = { recordId: record.id, fieldId: field.id, rowIndex, columnIndex };
        this.selectionRange = { anchorRow: rowIndex, anchorColumn: columnIndex, focusRow: rowIndex, focusColumn: columnIndex };
        this.renderAll();
      }
    }
    const activeRecord = this.activeCell ? this.visibleRecords[this.activeCell.rowIndex] : undefined;
    const menu = new Menu();
    menu.addItem((item) => {
      item.setTitle("编辑单元格").setIcon("pencil");
      item.onClick(() => this.startActiveCellEdit());
    });
    menu.addItem((item) => {
      item.setTitle("复制").setIcon("copy");
      item.onClick(() => this.copySelectionToClipboard());
    });
    menu.addItem((item) => {
      item.setTitle("清空内容").setIcon("eraser");
      item.onClick(() => this.clearSelection());
    });
    menu.addItem((item) => {
      item.setTitle("向下填充").setIcon("arrow-down").setDisabled(!this.canFillSelection("down"));
      item.onClick(() => this.fillSelection("down"));
    });
    menu.addItem((item) => {
      item.setTitle("向右填充").setIcon("arrow-right").setDisabled(!this.canFillSelection("right"));
      item.onClick(() => this.fillSelection("right"));
    });
    menu.addItem((item) => {
      item.setTitle("批量修改选区").setIcon("replace");
      item.onClick(() => this.openBulkEditPanel(cell));
    });
    menu.addSeparator();
    this.addRecordMenuItems(menu, activeRecord);
    menu.addSeparator();
    menu.addItem((item) => {
      item.setTitle("在下方新增行").setIcon("plus");
      item.onClick(() => this.addRow(rowIndex));
    });
    menu.addItem((item) => {
      item.setTitle("删除选中行/列").setIcon("trash-2").setWarning(true);
      item.onClick(() => this.deleteSelection());
    });
    menu.showAtMouseEvent(event);
  }

  private openRecordContextMenu(event: MouseEvent, record: DuoweiRecord): void {
    const menu = new Menu();
    this.addRecordMenuItems(menu, record);
    menu.addSeparator();
    menu.addItem((item) => {
      item.setTitle("新增记录").setIcon("plus");
      item.onClick(() => this.addRow(this.visibleRecords.findIndex((item) => item.id === record.id)));
    });
    menu.showAtMouseEvent(event);
  }

  private addRecordMenuItems(menu: Menu, record: DuoweiRecord | undefined): void {
    const hasRecord = Boolean(record);
    const hasBoundNote = hasRecord && Boolean(record?.notePath);
    const hasSyncFields = this.syncableFields().length > 0;
    menu.addItem((item) => {
      item.setTitle("打开详情").setIcon("panel-right").setDisabled(!hasRecord);
      item.onClick(() => {
        if (record) this.openRecordDetail(record.id);
      });
    });
    menu.addItem((item) => {
      item.setTitle("打开绑定笔记").setIcon("file-text").setDisabled(!hasBoundNote);
      item.onClick(() => {
        if (record) void this.openBoundNote(record);
      });
    });
    menu.addItem((item) => {
      item.setTitle("绑定笔记").setIcon("link").setDisabled(!hasRecord);
      item.onClick(() => {
        if (record) void this.bindRecordToActiveMarkdown(record);
      });
    });
    menu.addItem((item) => {
      item.setTitle("同步当前记录到笔记").setIcon("refresh-cw").setDisabled(!hasBoundNote || !hasSyncFields);
      item.onClick(() => {
        if (record) void this.syncRecordToBoundNote(record);
      });
    });
  }

  private confirmFieldMigration(sourceField: DuoweiField, targetField: DuoweiField, impact: FieldMigrationImpact): Promise<boolean> {
    return new Promise((resolve) => {
      const root = this.rootEl.doc.body.createDiv({ cls: "mt-dialog mt-dialog--migration" });
      const panel = root.createDiv({ cls: "mt-dialog__panel mt-dialog__panel--wide" });
      const sourceLabel = FIELD_TYPES.find((item) => item.type === sourceField.type)?.label ?? sourceField.type;
      const targetLabel = FIELD_TYPES.find((item) => item.type === targetField.type)?.label ?? targetField.type;
      panel.createDiv({ cls: "mt-dialog__title", text: `修改“${sourceField.name}”字段类型` });
      panel.createDiv({
        cls: "mt-dialog__lead",
        text: `从 ${sourceLabel} 改为 ${targetLabel}。转换会立即应用到当前表格，并可通过撤销恢复。`
      });

      const stats = panel.createDiv({ cls: "mt-migration-stats" });
      this.renderMigrationStat(stats, "非空", impact.nonEmpty);
      this.renderMigrationStat(stats, "会变化", impact.changed);
      this.renderMigrationStat(stats, "会清空", impact.emptied);
      this.renderMigrationStat(stats, "会失败", impact.failed, impact.failed > 0);

      const preview = panel.createDiv({ cls: "mt-migration-preview" });
      const header = preview.createDiv({ cls: "mt-migration-preview__header" });
      header.createSpan({ text: "预览" });
      header.createSpan({ text: `显示 ${Math.min(impact.items.length, 12)} / ${impact.items.length} 项` });
      const list = preview.createDiv({ cls: "mt-migration-preview__list" });
      for (const item of impact.items.slice(0, 12)) {
        const row = list.createDiv({ cls: item.error ? "mt-migration-preview__item is-error" : "mt-migration-preview__item" });
        const record = this.documentModel.records[item.rowIndex];
        row.createDiv({
          cls: "mt-migration-preview__record",
          text: record ? this.recordPreviewTitle(record, item.rowIndex) : `${item.rowIndex + 1} 行`
        });
        row.createDiv({ cls: "mt-migration-preview__value", text: this.displayValue(item.before, sourceField) || "空" });
        row.createDiv({ cls: "mt-migration-preview__arrow", text: item.error ? "!" : "→" });
        row.createDiv({
          cls: item.error ? "mt-migration-preview__error" : "mt-migration-preview__value",
          text: item.error ?? (this.displayValue(item.after, targetField) || "空")
        });
      }
      if (impact.items.length === 0) {
        list.createDiv({ cls: "mt-migration-preview__empty", text: "没有非空单元格需要转换。" });
      } else if (impact.items.length > 12) {
        list.createDiv({ cls: "mt-migration-preview__more", text: `还有 ${impact.items.length - 12} 项未显示` });
      }

      const actions = panel.createDiv({ cls: "mt-dialog__actions" });
      const cancel = actions.createEl("button", { cls: "mt-dialog__button", text: "取消", attr: { type: "button" } });
      const confirm = actions.createEl("button", {
        cls: impact.failed > 0 ? "mt-dialog__button mt-dialog__button--danger" : "mt-dialog__button mt-dialog__button--primary",
        text: impact.failed > 0 ? "继续并清空失败项" : "确认修改",
        attr: { type: "button" }
      });
      let settled = false;
      const close = (value: boolean) => {
        if (settled) return;
        settled = true;
        this.rootEl.doc.removeEventListener("keydown", onKeydown, true);
        root.remove();
        resolve(value);
      };
      const onKeydown = (event: KeyboardEvent) => {
        if (event.key === "Escape") {
          event.preventDefault();
          close(false);
        }
        if (event.key === "Enter" && (event.metaKey || event.ctrlKey)) {
          event.preventDefault();
          close(true);
        }
      };
      cancel.addEventListener("click", () => close(false));
      confirm.addEventListener("click", () => close(true));
      root.addEventListener("pointerdown", (event) => {
        if (event.target === root) close(false);
      });
      this.rootEl.doc.addEventListener("keydown", onKeydown, true);
      this.rootEl.win.setTimeout(() => cancel.focus(), 0);
    });
  }

  private renderMigrationStat(parent: HTMLElement, label: string, value: number, warning = false): void {
    const item = parent.createDiv({ cls: warning ? "mt-migration-stat is-warning" : "mt-migration-stat" });
    item.createDiv({ cls: "mt-migration-stat__value", text: String(value) });
    item.createDiv({ cls: "mt-migration-stat__label", text: label });
  }

  private recordPreviewTitle(record: DuoweiRecord, rowIndex: number): string {
    const titleField = this.documentModel.fields[0];
    const title = titleField ? this.displayValue(record.values[titleField.id], titleField) : "";
    return title ? `${rowIndex + 1} 行 · ${title}` : `${rowIndex + 1} 行`;
  }

  private recordTitle(record: DuoweiRecord): string {
    const titleField = this.documentModel.fields[0];
    const rowIndex = this.documentModel.records.findIndex((item) => item.id === record.id);
    const title = titleField ? this.displayValue(record.values[titleField.id], titleField).trim() : "";
    return title || `${rowIndex >= 0 ? rowIndex + 1 : "?"} 行`;
  }

  private openRecordDetail(recordId: string): void {
    this.detailRecordId = recordId;
    this.renderRecordDetail();
  }

  private closeRecordDetail(): void {
    this.detailRecordId = null;
    this.detailEl?.remove();
    this.detailEl = null;
  }

  private renderRecordDetail(): void {
    if (!this.detailRecordId) return;
    const record = this.documentModel.records.find((item) => item.id === this.detailRecordId);
    if (!record) {
      this.closeRecordDetail();
      return;
    }
    if (!this.detailEl) {
      this.detailEl = this.rootEl.createDiv({ cls: "mt-record-detail" });
    }
    const detail = this.detailEl;
    detail.empty();
    const fields = this.currentView().fieldOrder
      .map((fieldId) => this.documentModel.fields.find((field) => field.id === fieldId))
      .filter(isDuoweiField);
    const titleField = fields[0] ?? this.documentModel.fields[0];
    const titleText = titleField ? this.displayValue(record.values[titleField.id], titleField) || "未命名记录" : "未命名记录";

    const header = detail.createDiv({ cls: "mt-record-detail__header" });
    const titleWrap = header.createDiv({ cls: "mt-record-detail__title-wrap" });
    titleWrap.createDiv({ cls: "mt-record-detail__eyebrow", text: record.notePath ? "已绑定笔记" : "独立记录" });
    titleWrap.createDiv({ cls: "mt-record-detail__title", text: titleText });
    const close = header.createEl("button", {
      cls: "clickable-icon mt-record-detail__close",
      attr: { type: "button", title: "关闭详情", "aria-label": "关闭详情" }
    });
    setIcon(close, "x");
    close.addEventListener("click", () => this.closeRecordDetail());

    const actions = detail.createDiv({ cls: "mt-record-detail__actions" });
    const openNote = actions.createEl("button", { cls: "mt-record-detail__action", attr: { type: "button" } });
    setIcon(openNote.createSpan({ cls: "mt-record-detail__action-icon" }), "file-text");
    openNote.createSpan({ text: "打开笔记" });
    openNote.disabled = !record.notePath;
    openNote.addEventListener("click", () => void this.openBoundNote(record));
    const bind = actions.createEl("button", { cls: "mt-record-detail__action", attr: { type: "button" } });
    setIcon(bind.createSpan({ cls: "mt-record-detail__action-icon" }), "link");
    bind.createSpan({ text: "绑定笔记" });
    bind.addEventListener("click", () => void this.bindRecordToActiveMarkdown(record));
    const sync = actions.createEl("button", { cls: "mt-record-detail__action", attr: { type: "button" } });
    setIcon(sync.createSpan({ cls: "mt-record-detail__action-icon" }), "refresh-cw");
    sync.createSpan({ text: "同步" });
    sync.disabled = !record.notePath || this.syncableFields().length === 0;
    sync.addEventListener("click", () => void this.syncRecordToBoundNote(record));

    const body = detail.createDiv({ cls: "mt-record-detail__body" });
    for (const field of fields) {
      const row = body.createDiv({ cls: "mt-record-detail__field" });
      const label = row.createDiv({ cls: "mt-record-detail__label" });
      setIcon(label.createSpan({ cls: "mt-record-detail__field-icon" }), this.fieldTypeIcon(field.type));
      label.createSpan({ cls: "mt-record-detail__field-name", text: field.name });
      const editorWrap = row.createDiv({ cls: "mt-record-detail__editor-wrap" });
      this.renderDetailEditor(editorWrap, record, field);
    }
  }

  private renderDetailEditor(parent: HTMLElement, record: DuoweiRecord, field: DuoweiField): void {
    if (field.type === "checkbox") {
      const checkbox = parent.createEl("input", {
        cls: "mt-record-detail__checkbox",
        type: "checkbox",
        attr: { "aria-label": field.name }
      });
      checkbox.checked = record.values[field.id] === true;
      checkbox.addEventListener("change", () => {
        this.setCellValue(record, field, checkbox.checked, "更新详情字段");
        this.renderRecordDetail();
      });
      return;
    }

    const editor = parent.createEl("input", { cls: "mt-record-detail__editor", type: inputTypeForField(field.type) });
    if (field.type === "attachment" || field.type === "noteLink") {
      parent.addClass("mt-record-detail__editor-wrap--file");
      const picker = parent.createEl("button", {
        cls: "clickable-icon mt-record-detail__file-picker",
        attr: { type: "button", title: "选择文件", "aria-label": "选择文件" }
      });
      setIcon(picker, "folder-search");
      picker.addEventListener("pointerdown", (event) => {
        event.preventDefault();
        event.stopPropagation();
      });
      picker.addEventListener("click", (event) => {
        event.preventDefault();
        this.openVaultFilePicker(field, (file) => {
          editor.value = file.path;
          commit();
        });
      });
    }
    editor.value = this.editValue(record.values[field.id], field);
    editor.placeholder = field.type === "multiSelect" ? "用逗号分隔多个值" : "";
    let errorEl: HTMLDivElement | null = null;
    const showError = (message: string) => {
      parent.addClass("is-invalid");
      editor.addClass("is-invalid");
      errorEl = errorEl ?? parent.createDiv({ cls: "mt-record-detail__editor-error" });
      errorEl.setText(message);
    };
    const clearError = () => {
      parent.removeClass("is-invalid");
      editor.removeClass("is-invalid");
      errorEl?.remove();
      errorEl = null;
    };
    const commit = () => {
      const current = this.documentModel.records.find((item) => item.id === record.id);
      const targetField = this.documentModel.fields.find((item) => item.id === field.id);
      if (!current || !targetField) return;
      const before = this.editValue(current.values[targetField.id], targetField);
      if (before === editor.value) return;
      const result = this.commitRawValue(current, targetField, editor.value, "更新详情字段");
      if (!result.ok) {
        showError(result.message ?? "字段写入失败");
        return;
      }
      clearError();
      this.renderRecordDetail();
    };
    editor.addEventListener("blur", commit);
    editor.addEventListener("input", clearError);
    editor.addEventListener("keydown", (event) => {
      const keyboardEvent = event as KeyboardEvent;
      if (keyboardEvent.key === "Enter" && !(editor instanceof HTMLTextAreaElement && keyboardEvent.shiftKey)) {
        keyboardEvent.preventDefault();
        commit();
        if (!editor.hasClass("is-invalid")) editor.blur();
      }
      if (keyboardEvent.key === "Escape") {
        editor.value = this.editValue(record.values[field.id], field);
        clearError();
        editor.blur();
      }
    });
  }

  private async openBoundNote(record: DuoweiRecord): Promise<void> {
    const file = this.boundMarkdownFile(record);
    if (!file) {
      new Notice("这条记录还没有绑定可打开的笔记。", 3000);
      return;
    }
    await this.app.workspace.getLeaf("tab").openFile(file);
  }

  private async bindRecordToActiveMarkdown(record: DuoweiRecord): Promise<void> {
    const activeFile = this.app.workspace.getActiveFile();
    let targetFile = activeFile?.extension === "md" ? activeFile : null;
    if (!targetFile) {
      const rawPath = await this.promptText("绑定笔记路径或名称", record.notePath ?? "");
      if (!rawPath?.trim()) return;
      targetFile = this.resolveMarkdownFile(rawPath.trim());
    }
    if (!targetFile) {
      new Notice("没有找到要绑定的 Markdown 笔记。", 3000);
      return;
    }
    const frontmatter = (this.app.metadataCache.getFileCache(targetFile)?.frontmatter ?? {}) as Record<string, unknown>;
    this.applyMutation("绑定笔记", (document) => {
      const target = document.records.find((item) => item.id === record.id);
      if (!target) return;
      target.notePath = targetFile.path;
      for (const field of document.fields) {
        if (!field.syncKey) continue;
        if (!Object.prototype.hasOwnProperty.call(frontmatter, field.syncKey)) continue;
        target.values[field.id] = duoweiValueFromFrontmatter(frontmatter[field.syncKey], field);
      }
      target.updatedAt = new Date().toISOString();
    });
    new Notice(`已绑定到 ${targetFile.basename}。`, 3000);
  }

  private async syncRecordToBoundNote(record: DuoweiRecord): Promise<SyncResult> {
    const result = await this.syncRecordsToBoundNotes([record], true);
    this.renderAll(true);
    return result;
  }

  private async syncAllBoundRecords(): Promise<void> {
    const result = await this.syncRecordsToBoundNotes(
      this.documentModel.records.filter((record) => Boolean(record.notePath)),
      false
    );
    this.renderAll(true);
    if (result.failed > 0) {
      new Notice(`同步完成：成功 ${result.synced} 条，跳过 ${result.skipped} 条，失败 ${result.failed} 条。`, 6000);
    } else {
      new Notice(`同步完成：成功 ${result.synced} 条，跳过 ${result.skipped} 条。`, 4000);
    }
  }

  private async retryFailedSync(): Promise<void> {
    const failedIds = new Set(this.syncLog.filter((item) => item.status === "failed").map((item) => item.recordId));
    const records = this.documentModel.records.filter((record) => failedIds.has(record.id));
    if (records.length === 0) {
      new Notice("没有可重试的失败记录。", 3000);
      return;
    }
    const result = await this.syncRecordsToBoundNotes(records, false);
    this.renderAll(true);
    new Notice(`重试完成：成功 ${result.synced} 条，跳过 ${result.skipped} 条，失败 ${result.failed} 条。`, 5000);
  }

  private async syncRecordsToBoundNotes(records: DuoweiRecord[], single: boolean): Promise<SyncResult> {
    const fields = this.syncableFields();
    const result: SyncResult = { synced: 0, skipped: 0, failed: 0, items: [] };
    const now = new Date().toISOString();
    if (fields.length === 0) {
      new Notice("没有设置可同步的字段。请先在字段菜单里设置同步属性。", 4000);
      result.skipped = records.length;
      result.items = records.map((record) => this.createSyncLogItem(record, "skipped", "没有设置可同步字段", now));
      this.syncLog = result.items;
      this.addOperationLog("sync", "同步跳过", `没有可同步字段，跳过 ${result.skipped} 条`, "warning");
      return result;
    }

    for (const record of records) {
      const file = this.boundMarkdownFile(record);
      if (!file) {
        result.skipped += 1;
        result.items.push(this.createSyncLogItem(record, "skipped", "没有绑定可同步的 Markdown 笔记", now));
        continue;
      }
      try {
        await this.app.fileManager.processFrontMatter(file, (frontmatter) => {
          for (const field of fields) {
            if (!field.syncKey) continue;
            const value = frontmatterValueForField(record.values[field.id], field);
            if (value === undefined) delete frontmatter[field.syncKey];
            else frontmatter[field.syncKey] = value;
          }
        });
        result.synced += 1;
        result.items.push(this.createSyncLogItem(record, "synced", `已写入 ${fields.length} 个字段`, now, file.path));
      } catch (error) {
        result.failed += 1;
        const message = error instanceof Error ? error.message : "同步失败";
        result.items.push(this.createSyncLogItem(record, "failed", message, now, file.path));
        console.error("[多维表格] 同步记录到笔记失败", record.id, record.notePath, error);
      }
    }

    this.syncLog = result.items;
    this.addOperationLog(
      "sync",
      single ? "同步当前记录" : "同步绑定记录",
      `成功 ${result.synced} 条，跳过 ${result.skipped} 条，失败 ${result.failed} 条`,
      result.failed > 0 ? "error" : result.skipped > 0 ? "warning" : "ok"
    );
    if (single) {
      if (result.synced > 0) new Notice("当前记录已同步到绑定笔记。", 3000);
      else if (result.skipped > 0) new Notice("当前记录没有可同步的绑定笔记。", 3000);
      else if (result.failed > 0) new Notice("当前记录同步失败，请查看控制台错误。", 4000);
    }
    this.setStatus(result.failed > 0 ? "部分同步失败" : "同步完成", result.failed > 0 ? "error" : "saved");
    return result;
  }

  private createSyncLogItem(
    record: DuoweiRecord,
    status: SyncLogItem["status"],
    message: string,
    at: string,
    notePath = record.notePath
  ): SyncLogItem {
    return {
      recordId: record.id,
      title: this.recordTitle(record),
      notePath: notePath ?? null,
      status,
      message,
      at
    };
  }

  private parseRawValue(raw: string, field: DuoweiField, sourceRecordId?: string): unknown {
    void sourceRecordId;
    const parsed = parseRawValue(raw, field);
    if (field.type !== "noteLink" || parsed === undefined) return parsed;
    const value = String(parsed);
    if (this.resolveVaultFile(value)?.extension === "md") return value;
    throw new Error("请输入存在的 Obsidian 笔记路径、文件名或 [[笔记链接]]");
  }

  private syncableFields(): DuoweiField[] {
    return this.documentModel.fields.filter(
      (field) => typeof field.syncKey === "string" && field.syncKey.trim().length > 0
    );
  }

  private boundMarkdownFile(record: DuoweiRecord): TFile | null {
    if (!record.notePath) return null;
    const file = this.app.vault.getFileByPath(record.notePath);
    return file?.extension === "md" ? file : null;
  }

  private resolveMarkdownFile(input: string): TFile | null {
    const normalized = normalizePath(input.endsWith(".md") ? input : `${input}.md`);
    const exact = this.app.vault.getFileByPath(normalized);
    if (exact?.extension === "md") return exact;
    return this.app.vault.getMarkdownFiles().find((file) => file.path === input || file.basename === input || file.name === input) ?? null;
  }

  private resolveVaultFile(input: string): TFile | null {
    const cleaned = stripWikiLink(input);
    const normalized = normalizePath(cleaned);
    const exact = this.app.vault.getFileByPath(normalized);
    if (exact) return exact;
    const withMd = this.app.vault.getFileByPath(normalizePath(`${cleaned}.md`));
    if (withMd) return withMd;
    return (
      this.app.vault
        .getFiles()
        .find((file) => file.path === cleaned || file.name === cleaned || file.basename === cleaned || file.basename === cleaned.replace(/\.md$/, "")) ??
      null
    );
  }

  private importDelimitedFile(): void {
    const input = this.rootEl.createEl("input", {
      type: "file",
      attr: { accept: ".csv,.tsv,text/csv,text/tab-separated-values" }
    });
    input.addClass("mt-hidden-file-input");
    input.addEventListener("change", () => {
      const file = input.files?.[0];
      input.remove();
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        try {
          const text = String(reader.result ?? "");
          const kind = detectDelimitedKind(file.name);
          const rows = parseDelimited(text, kind);
          this.openImportPreview(rows, file.name);
        } catch (error) {
          const message = error instanceof Error ? error.message : "导入失败";
          this.setStatus(message, "error");
          new Notice(message, 4000);
        }
      };
      reader.onerror = () => {
        new Notice("读取导入文件失败。", 4000);
      };
      reader.readAsText(file);
    });
    input.click();
  }

  private openImportPreview(rows: string[][], sourceName: string): void {
    const preview = this.createImportPreview(rows, sourceName);
    if (!preview) return;
    const root = this.rootEl.doc.body.createDiv({ cls: "mt-dialog mt-dialog--import" });
    const panel = root.createDiv({ cls: "mt-dialog__panel mt-dialog__panel--wide mt-import-dialog" });
    panel.createDiv({ cls: "mt-dialog__title", text: `导入 ${sourceName}` });
    const lead = panel.createDiv({ cls: "mt-dialog__lead" });
    const summary = lead.createSpan();
    const mapping = panel.createDiv({ cls: "mt-import-mapping" });
    const previewBox = panel.createDiv({ cls: "mt-import-preview" });
    const actions = panel.createDiv({ cls: "mt-dialog__actions" });
    const cancel = actions.createEl("button", { cls: "mt-dialog__button", text: "取消", attr: { type: "button" } });
    const confirm = actions.createEl("button", {
      cls: "mt-dialog__button mt-dialog__button--primary",
      text: "导入可成功行",
      attr: { type: "button" }
    });

    const render = () => {
      const latest = this.refreshImportPreview(preview);
      summary.setText(`共 ${latest.dataRows.length} 行，${latest.columns.filter((column) => column.enabled).length} 列；可导入 ${latest.validRows} 行，失败 ${latest.errors.length} 个单元格。`);
      confirm.disabled = latest.validRows === 0 || latest.columns.every((column) => !column.enabled);
      this.renderImportMapping(mapping, latest, render);
      this.renderImportPreview(previewBox, latest);
    };

    let settled = false;
    const close = () => {
      if (settled) return;
      settled = true;
      this.rootEl.doc.removeEventListener("keydown", onKeydown, true);
      root.remove();
    };
    const onKeydown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        close();
      }
      if (event.key === "Enter" && (event.metaKey || event.ctrlKey)) {
        event.preventDefault();
        if (!confirm.disabled) {
          this.applyImportPreview(this.refreshImportPreview(preview));
          close();
        }
      }
    };
    cancel.addEventListener("click", close);
    confirm.addEventListener("click", () => {
      const latest = this.refreshImportPreview(preview);
      if (latest.validRows === 0) {
        new Notice("没有可导入的记录。", 3000);
        return;
      }
      this.applyImportPreview(latest);
      close();
    });
    root.addEventListener("pointerdown", (event) => {
      if (event.target === root) close();
    });
    this.rootEl.doc.addEventListener("keydown", onKeydown, true);
    render();
    this.rootEl.win.setTimeout(() => cancel.focus(), 0);
  }

  private createImportPreview(rows: string[][], sourceName: string): ImportPreview | null {
    if (rows.length < 1) {
      new Notice("导入文件为空。", 3000);
      return null;
    }
    const header = rows[0] ?? [];
    const dataRows = rows.slice(1).filter((row) => row.some((cell) => cell.trim() !== ""));
    if (header.length === 0 || dataRows.length === 0) {
      new Notice("导入文件需要包含表头和至少一行数据。", 4000);
      return null;
    }
    const existingByName = new Map(this.documentModel.fields.map((field) => [field.name, field]));
    const usedNames = new Set(this.documentModel.fields.map((field) => field.name));
    const columns = header.map((rawName, index): ImportColumnPlan => {
      const sourceName = rawName.trim() || `字段 ${index + 1}`;
      const existing = existingByName.get(sourceName);
      const values = dataRows.map((row) => row[index] ?? "");
      if (existing) {
        return {
          sourceIndex: index,
          sourceName,
          target: "existing",
          fieldId: existing.id,
          fieldName: existing.name,
          type: existing.type,
          enabled: true
        };
      }
      const fieldName = uniqueName(sourceName, usedNames);
      return {
        sourceIndex: index,
        sourceName,
        target: "new",
        fieldName,
        type: inferFieldType(values),
        enabled: true
      };
    });
    return this.refreshImportPreview({ rows, dataRows, columns, errors: [], validRows: 0, sourceName });
  }

  private refreshImportPreview(preview: ImportPreview): ImportPreview {
    const errors: ImportPreviewError[] = [];
    for (let rowIndex = 0; rowIndex < preview.dataRows.length; rowIndex += 1) {
      const row = preview.dataRows[rowIndex] ?? [];
      for (const column of preview.columns) {
        if (!column.enabled) continue;
        const field = this.fieldForImportColumn(column);
        try {
          this.parseRawValue(row[column.sourceIndex] ?? "", field);
        } catch (error) {
          errors.push({
            rowIndex,
            columnName: column.fieldName,
            value: row[column.sourceIndex] ?? "",
            message: error instanceof Error ? error.message : "无法解析"
          });
        }
      }
    }
    const failedRows = new Set(errors.map((error) => error.rowIndex));
    preview.errors = errors;
    preview.validRows = Math.max(0, preview.dataRows.length - failedRows.size);
    return preview;
  }

  private renderImportMapping(container: HTMLElement, preview: ImportPreview, onChange: () => void): void {
    container.empty();
    const header = container.createDiv({ cls: "mt-import-mapping__header" });
    header.createSpan({ text: "导入列" });
    header.createSpan({ text: "目标字段" });
    header.createSpan({ text: "字段类型" });
    for (const column of preview.columns) {
      const row = container.createDiv({ cls: column.enabled ? "mt-import-mapping__row" : "mt-import-mapping__row is-disabled" });
      const enabled = row.createEl("input", {
        cls: "mt-import-mapping__check",
        type: "checkbox",
        attr: { "aria-label": `导入 ${column.sourceName}` }
      });
      enabled.checked = column.enabled;
      const source = row.createDiv({ cls: "mt-import-mapping__source" });
      source.createDiv({ cls: "mt-import-mapping__name", text: column.sourceName });
      source.createDiv({ cls: "mt-import-mapping__sample", text: this.importColumnSample(preview.dataRows, column.sourceIndex) || "空" });
      const target = row.createEl("select", { cls: "mt-import-mapping__select" });
      target.createEl("option", { value: "__new__", text: `新字段：${column.fieldName}` });
      for (const field of this.documentModel.fields) {
        target.createEl("option", { value: field.id, text: `已有：${field.name}` });
      }
      target.value = column.target === "existing" && column.fieldId ? column.fieldId : "__new__";
      const type = row.createEl("select", { cls: "mt-import-mapping__select" });
      for (const fieldType of FIELD_TYPES) {
        type.createEl("option", { value: fieldType.type, text: fieldType.label });
      }
      type.value = column.type;
      type.disabled = column.target === "existing";

      enabled.addEventListener("change", () => {
        column.enabled = enabled.checked;
        onChange();
      });
      target.addEventListener("change", () => {
        if (target.value === "__new__") {
          column.target = "new";
          delete column.fieldId;
          column.type = inferFieldType(preview.dataRows.map((item) => item[column.sourceIndex] ?? ""));
        } else {
          const field = this.documentModel.fields.find((item) => item.id === target.value);
          if (field) {
            column.target = "existing";
            column.fieldId = field.id;
            column.fieldName = field.name;
            column.type = field.type;
          }
        }
        onChange();
      });
      type.addEventListener("change", () => {
        column.type = type.value as DuoweiFieldType;
        onChange();
      });
    }
  }

  private renderImportPreview(container: HTMLElement, preview: ImportPreview): void {
    container.empty();
    const errors = preview.errors.slice(0, 6);
    const title = container.createDiv({ cls: "mt-import-preview__title" });
    title.createSpan({ text: "数据预览" });
    title.createSpan({ text: preview.errors.length > 0 ? `${preview.errors.length} 个错误` : "无错误" });
    if (errors.length > 0) {
      const errorList = container.createDiv({ cls: "mt-import-preview__errors" });
      for (const error of errors) {
        const item = errorList.createDiv({ cls: "mt-import-preview__error" });
        item.createSpan({ cls: "mt-import-preview__error-cell", text: `${error.rowIndex + 2} 行 · ${error.columnName}` });
        item.createSpan({ cls: "mt-import-preview__error-message", text: error.message });
      }
      if (preview.errors.length > errors.length) {
        errorList.createDiv({ cls: "mt-import-preview__more", text: `还有 ${preview.errors.length - errors.length} 个错误未显示` });
      }
    }
    const table = container.createDiv({ cls: "mt-import-preview__table" });
    const enabledColumns = preview.columns.filter((column) => column.enabled).slice(0, 8);
    const head = table.createDiv({ cls: "mt-import-preview__row mt-import-preview__row--head" });
    for (const column of enabledColumns) head.createDiv({ cls: "mt-import-preview__cell", text: column.fieldName });
    for (const row of preview.dataRows.slice(0, 5)) {
      const line = table.createDiv({ cls: "mt-import-preview__row" });
      for (const column of enabledColumns) line.createDiv({ cls: "mt-import-preview__cell", text: row[column.sourceIndex] ?? "" });
    }
  }

  private fieldForImportColumn(column: ImportColumnPlan): DuoweiField {
    if (column.target === "existing" && column.fieldId) {
      const existing = this.documentModel.fields.find((field) => field.id === column.fieldId);
      if (existing) return existing;
    }
    return {
      id: `preview_${column.sourceIndex}`,
      name: column.fieldName,
      type: column.type,
      width: defaultFieldWidth(column.type),
      options: column.type === "singleSelect" || column.type === "multiSelect" ? [] : undefined
    };
  }

  private importColumnSample(rows: string[][], sourceIndex: number): string {
    return rows
      .map((row) => row[sourceIndex] ?? "")
      .find((value) => value.trim() !== "")
      ?.trim() ?? "";
  }

  private uniqueImportFieldName(document: DuoweiDocument, baseName: string): string {
    return uniqueName(baseName || "字段", new Set(document.fields.map((field) => field.name)));
  }

  private applyImportPreview(preview: ImportPreview): void {
    const latest = this.refreshImportPreview(preview);
    const enabledColumns = latest.columns.filter((column) => column.enabled);
    if (enabledColumns.length === 0 || latest.validRows === 0) return;
    const failedRows = new Set(latest.errors.map((error) => error.rowIndex));
    this.applyMutation(`导入 ${latest.sourceName}`, (document) => {
      const fieldsByColumn = new Map<number, DuoweiField>();
      for (const column of enabledColumns) {
        if (column.target === "existing" && column.fieldId) {
          const field = document.fields.find((item) => item.id === column.fieldId);
          if (field) fieldsByColumn.set(column.sourceIndex, field);
          continue;
        }
        const field = createDuoweiField(column.type, this.uniqueImportFieldName(document, column.fieldName), defaultFieldWidth(column.type));
        if (field.type === "singleSelect") {
          field.options = [];
          const values = latest.dataRows.map((row) => row[column.sourceIndex] ?? "");
          for (const value of [...new Set(values.map((item) => item.trim()).filter(Boolean))].slice(0, 40)) {
            field.options.push({
              id: `opt_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`,
              name: value,
              color: nextOptionColor(field.options)
            });
          }
        }
        document.fields.push(field);
        for (const view of document.views) {
          view.fieldOrder.push(field.id);
          if (view.type === "kanban" && view.cardFieldIds.length < 3) view.cardFieldIds.push(field.id);
          if (view.type === "gallery" && view.cardFieldIds.length < 4) view.cardFieldIds.push(field.id);
        }
        fieldsByColumn.set(column.sourceIndex, field);
      }
      for (let rowIndex = 0; rowIndex < latest.dataRows.length; rowIndex += 1) {
        if (failedRows.has(rowIndex)) continue;
        const row = latest.dataRows[rowIndex] ?? [];
        const values: Record<string, unknown> = {};
        for (const column of enabledColumns) {
          const field = fieldsByColumn.get(column.sourceIndex);
          if (!field) continue;
          values[field.id] = this.parseRawValue(row[column.sourceIndex] ?? "", field);
        }
        document.records.push(createDuoweiRecord(document.fields, values));
      }
    });
    if (latest.errors.length > 0) {
      const skippedRows = new Set(latest.errors.map((error) => error.rowIndex)).size;
      new Notice(`已导入 ${latest.validRows} 行，跳过 ${skippedRows} 行。`, 5000);
      this.addOperationLog("import", `导入 ${latest.sourceName}`, `导入 ${latest.validRows} 行，跳过 ${skippedRows} 行`, "warning");
    } else {
      new Notice(`已导入 ${latest.validRows} 行。`, 3000);
      this.addOperationLog("import", `导入 ${latest.sourceName}`, `导入 ${latest.validRows} 行`);
    }
  }

  private beginResize(event: PointerEvent, field: DuoweiField): void {
    event.preventDefault();
    event.stopPropagation();
    const startX = event.clientX;
    const startWidth = field.width ?? defaultFieldWidth(field.type);
    const onMove = (moveEvent: PointerEvent) => {
      const width = Math.max(72, Math.min(640, startWidth + moveEvent.clientX - startX));
      field.width = width;
      this.renderAll(true);
    };
    const onUp = () => {
      this.rootEl.win.removeEventListener("pointermove", onMove);
      this.rootEl.win.removeEventListener("pointerup", onUp);
      this.markDirty("调整列宽");
    };
    this.rootEl.win.addEventListener("pointermove", onMove);
    this.rootEl.win.addEventListener("pointerup", onUp, { once: true });
  }

  private handleGridKeydown(event: KeyboardEvent): void {
    if (isEditorElement(event.target)) return;
    if (event.ctrlKey || event.metaKey) {
      const key = event.key.toLowerCase();
      if (key === "a") {
        event.preventDefault();
        this.selectAll();
        return;
      }
      if (key === "z") {
        event.preventDefault();
        if (event.shiftKey) this.redo();
        else this.undo();
        return;
      }
      if (key === "y") {
        event.preventDefault();
        this.redo();
        return;
      }
      if (key === "d") {
        event.preventDefault();
        this.fillSelection("down");
        return;
      }
      if (key === "r") {
        event.preventDefault();
        this.fillSelection("right");
        return;
      }
    }

    if (!this.activeCell) return;

    switch (event.key) {
      case "ArrowUp":
        event.preventDefault();
        this.moveActiveCell(-1, 0, event.shiftKey);
        return;
      case "ArrowDown":
        event.preventDefault();
        this.moveActiveCell(1, 0, event.shiftKey);
        return;
      case "ArrowLeft":
        event.preventDefault();
        this.moveActiveCell(0, -1, event.shiftKey);
        return;
      case "ArrowRight":
        event.preventDefault();
        this.moveActiveCell(0, 1, event.shiftKey);
        return;
      case "Tab":
        event.preventDefault();
        this.moveActiveCell(0, event.shiftKey ? -1 : 1, false);
        return;
      case "Enter":
      case "F2":
        event.preventDefault();
        this.startActiveCellEdit();
        return;
      case "Delete":
      case "Backspace":
        event.preventDefault();
        this.clearSelection();
        return;
      case " ":
        event.preventDefault();
        this.toggleActiveCheckbox();
        return;
      default:
        if (isPrintableEditKey(event)) {
          event.preventDefault();
          this.startActiveCellEdit(event.key);
        }
    }
  }

  private handleCopy(event: ClipboardEvent): void {
    if (isEditorElement(event.target)) return;
    const text = this.selectionToTsv();
    if (!text) return;
    event.preventDefault();
    event.clipboardData?.setData("text/plain", text);
  }

  private handlePaste(event: ClipboardEvent): void {
    if (isEditorElement(event.target)) return;
    const text = event.clipboardData?.getData("text/plain");
    if (!text) return;
    event.preventDefault();
    this.pasteText(text);
  }

  private pasteText(text: string): void {
    const range = this.normalizedSelectionRange();
    const active = this.activeCell;
    if (!range || !active) return;
    const matrix = parseClipboardTable(text);
    const fillSelection = matrix.length === 1 && matrix[0]?.length === 1 && (range.rowEnd > range.rowStart || range.columnEnd > range.columnStart);
    const fields = this.visibleFields();
    try {
      this.applyMutation("粘贴", (document) => {
        const targetRecords = this.visibleRecords.slice(range.rowStart, range.rowEnd + 1);
        for (let rowOffset = 0; rowOffset < (fillSelection ? targetRecords.length : matrix.length); rowOffset += 1) {
          const visibleRecord = targetRecords[rowOffset] ?? this.visibleRecords[active.rowIndex + rowOffset];
          const record = document.records.find((item) => item.id === visibleRecord?.id);
          if (!record) continue;
          const row = fillSelection ? matrix[0] ?? [] : matrix[rowOffset] ?? [];
          for (let columnOffset = 0; columnOffset < (fillSelection ? range.columnEnd - range.columnStart + 1 : row.length); columnOffset += 1) {
            const field = fields[range.columnStart + columnOffset];
            const targetField = document.fields.find((item) => item.id === field?.id);
            if (!targetField) continue;
            if (isComputedField(targetField)) continue;
            const raw = fillSelection ? matrix[0]?.[0] ?? "" : row[columnOffset] ?? "";
            record.values[targetField.id] = this.parseRawValue(raw, targetField, record.id);
            record.updatedAt = new Date().toISOString();
          }
        }
      });
    } catch (error) {
      const message = error instanceof Error ? error.message : "粘贴失败";
      this.setStatus(message, "error");
      new Notice(message, 3000);
      this.renderAll(true);
    }
  }

  private copySelectionToClipboard(): void {
    const text = this.selectionToTsv();
    if (!text) return;
    void navigator.clipboard.writeText(text).then(
      () => this.setStatus("已复制", "saved"),
      () => new Notice("复制失败，请使用 Ctrl+C。", 3000)
    );
  }

  private selectionToTsv(): string {
    const range = this.normalizedSelectionRange();
    if (!range) return "";
    const fields = this.visibleFields().slice(range.columnStart, range.columnEnd + 1);
    const rows = this.visibleRecords.slice(range.rowStart, range.rowEnd + 1);
    return rows
      .map((record) => fields.map((field) => this.displayValue(record.values[field.id], field)).join("\t"))
      .join("\n");
  }

  private moveActiveCell(rowDelta: number, columnDelta: number, extend: boolean): void {
    if (!this.activeCell) return;
    const fields = this.visibleFields();
    const rowIndex = clamp(this.activeCell.rowIndex + rowDelta, 0, Math.max(0, this.visibleRecords.length - 1));
    const columnIndex = clamp(this.activeCell.columnIndex + columnDelta, 0, Math.max(0, fields.length - 1));
    const record = this.visibleRecords[rowIndex];
    const field = fields[columnIndex];
    if (!record || !field) return;
    this.activeCell = { recordId: record.id, fieldId: field.id, rowIndex, columnIndex };
    if (extend && this.selectionRange) {
      this.selectionRange = { ...this.selectionRange, focusRow: rowIndex, focusColumn: columnIndex };
    } else {
      this.selectionRange = { anchorRow: rowIndex, anchorColumn: columnIndex, focusRow: rowIndex, focusColumn: columnIndex };
    }
    this.scrollCellIntoView(rowIndex, columnIndex);
    this.renderAll();
  }

  private moveAfterCommit(rowIndex: number, columnIndex: number, move: "none" | "down" | "right" | "left"): void {
    if (move === "down") this.moveActiveCell(1, 0, false);
    else if (move === "right") this.moveActiveCell(0, 1, false);
    else if (move === "left") this.moveActiveCell(0, -1, false);
    else this.focusRenderedActiveCell();
  }

  private startActiveCellEdit(initial?: string): void {
    if (!this.activeCell) return;
    const cell = this.cellElement(this.activeCell.rowIndex, this.activeCell.columnIndex);
    const record = this.visibleRecords[this.activeCell.rowIndex];
    const field = this.visibleFields()[this.activeCell.columnIndex];
    if (!cell || !record || !field) return;
    this.startCellEdit(cell, record, field, this.activeCell.rowIndex, this.activeCell.columnIndex, initial);
  }

  private toggleActiveCheckbox(): void {
    if (!this.activeCell) return;
    const record = this.visibleRecords[this.activeCell.rowIndex];
    const field = this.visibleFields()[this.activeCell.columnIndex];
    if (!record || !field || field.type !== "checkbox") return;
    this.setCellValue(record, field, record.values[field.id] !== true, "更新勾选");
  }

  private selectRow(rowIndex: number, extend: boolean): void {
    const fields = this.visibleFields();
    if (fields.length === 0) return;
    const anchor = extend && this.selectionRange ? this.selectionRange.anchorRow : rowIndex;
    const record = this.visibleRecords[rowIndex];
    if (!record) return;
    this.activeCell = { recordId: record.id, fieldId: fields[0].id, rowIndex, columnIndex: 0 };
    this.selectionRange = { anchorRow: anchor, anchorColumn: 0, focusRow: rowIndex, focusColumn: fields.length - 1 };
    this.renderAll();
  }

  private selectColumn(columnIndex: number, extend: boolean): void {
    const fields = this.visibleFields();
    const field = fields[columnIndex];
    if (!field) return;
    const anchor = extend && this.selectionRange ? this.selectionRange.anchorColumn : columnIndex;
    const record = this.visibleRecords[0];
    this.activeCell = record ? { recordId: record.id, fieldId: field.id, rowIndex: 0, columnIndex } : null;
    this.selectionRange = {
      anchorRow: 0,
      anchorColumn: anchor,
      focusRow: Math.max(0, this.visibleRecords.length - 1),
      focusColumn: columnIndex
    };
    this.renderAll();
  }

  private selectAll(): void {
    const fields = this.visibleFields();
    if (fields.length === 0 || this.visibleRecords.length === 0) return;
    const first = this.visibleRecords[0];
    this.activeCell = { recordId: first.id, fieldId: fields[0].id, rowIndex: 0, columnIndex: 0 };
    this.selectionRange = {
      anchorRow: 0,
      anchorColumn: 0,
      focusRow: this.visibleRecords.length - 1,
      focusColumn: fields.length - 1
    };
    this.renderAll();
  }

  private undo(): void {
    const operation = this.undoStack.pop();
    if (!operation) return;
    this.redoStack.push({ label: operation.label, before: cloneDuoweiDocument(operation.before), after: cloneDuoweiDocument(this.documentModel) });
    this.documentModel = cloneDuoweiDocument(operation.before);
    this.addOperationLog("undo", "撤销", operation.label);
    this.afterHistoryChange("已撤销");
  }

  private redo(): void {
    const operation = this.redoStack.pop();
    if (!operation) return;
    this.undoStack.push({ label: operation.label, before: cloneDuoweiDocument(this.documentModel), after: cloneDuoweiDocument(operation.after) });
    this.documentModel = cloneDuoweiDocument(operation.after);
    this.addOperationLog("redo", "重做", operation.label);
    this.afterHistoryChange("已重做");
  }

  private afterHistoryChange(status: string): void {
    this.ensureActiveView();
    this.activeCell = this.firstCell();
    this.selectionRange = this.activeCell
      ? {
          anchorRow: this.activeCell.rowIndex,
          anchorColumn: this.activeCell.columnIndex,
          focusRow: this.activeCell.rowIndex,
          focusColumn: this.activeCell.columnIndex
        }
      : null;
    this.markDirty(status);
    this.renderAll(true);
  }

  private applyMutation(label: string, mutator: (document: DuoweiDocument) => void): void {
    if (this.readOnlyReason) {
      new Notice("当前文件处于保护性只读模式，无法编辑。", 3000);
      return;
    }
    const before = cloneDuoweiDocument(this.documentModel);
    const draft = cloneDuoweiDocument(this.documentModel);
    mutator(draft);
    this.refreshFormulaValues(draft);
    touchDuoweiDocument(draft);
    this.documentModel = draft;
    this.ensureActiveView();
    const after = cloneDuoweiDocument(this.documentModel);
    this.undoStack.push({ label, before, after });
    this.redoStack = [];
    this.addOperationLog("edit", label, operationChangeDetail(before, after));
    this.markDirty(label);
    this.renderAll(true);
  }

  private markDirty(label: string): void {
    this.setStatus(label, "saving");
    this.requestSave();
    this.updateUndoRedoButtons();
  }

  private updateUndoRedoButtons(): void {
    this.undoButtonEl.disabled = this.undoStack.length === 0;
    this.redoButtonEl.disabled = this.redoStack.length === 0;
  }

  private setStatus(message: string, state: "saving" | "saved" | "error" | "conflict"): void {
    this.statusEl.setText(message);
    this.statusEl.dataset.state = state;
  }

  private normalizedSelectionRange(): NormalizedSelectionRange | null {
    if (!this.selectionRange) return null;
    return {
      rowStart: Math.min(this.selectionRange.anchorRow, this.selectionRange.focusRow),
      rowEnd: Math.max(this.selectionRange.anchorRow, this.selectionRange.focusRow),
      columnStart: Math.min(this.selectionRange.anchorColumn, this.selectionRange.focusColumn),
      columnEnd: Math.max(this.selectionRange.anchorColumn, this.selectionRange.focusColumn)
    };
  }

  private applySelectionClasses(cell: HTMLElement, rowIndex: number, columnIndex: number): void {
    const range = this.normalizedSelectionRange();
    if (!range) return;
    if (rowIndex < range.rowStart || rowIndex > range.rowEnd || columnIndex < range.columnStart || columnIndex > range.columnEnd) {
      return;
    }
    cell.addClass("is-selected");
    if (rowIndex === range.rowStart) cell.addClass("is-selection-top");
    if (rowIndex === range.rowEnd) cell.addClass("is-selection-bottom");
    if (columnIndex === range.columnStart) cell.addClass("is-selection-left");
    if (columnIndex === range.columnEnd) cell.addClass("is-selection-right");
  }

  private applyFillPreviewClasses(cell: HTMLElement, rowIndex: number, columnIndex: number): void {
    const drag = this.fillDrag;
    if (!drag?.direction) return;
    const range = drag.baseRange;
    const isDownPreview =
      drag.direction === "down" &&
      rowIndex > range.rowEnd &&
      rowIndex <= drag.targetRowEnd &&
      columnIndex >= range.columnStart &&
      columnIndex <= range.columnEnd;
    const isRightPreview =
      drag.direction === "right" &&
      columnIndex > range.columnEnd &&
      columnIndex <= drag.targetColumnEnd &&
      rowIndex >= range.rowStart &&
      rowIndex <= range.rowEnd;
    if (!isDownPreview && !isRightPreview) return;
    cell.addClass("is-fill-preview");
    if (isDownPreview && rowIndex === range.rowEnd + 1) cell.addClass("is-fill-preview-top");
    if (isDownPreview && rowIndex === drag.targetRowEnd) cell.addClass("is-fill-preview-bottom");
    if (isDownPreview && columnIndex === range.columnStart) cell.addClass("is-fill-preview-left");
    if (isDownPreview && columnIndex === range.columnEnd) cell.addClass("is-fill-preview-right");
    if (isRightPreview && columnIndex === range.columnEnd + 1) cell.addClass("is-fill-preview-left");
    if (isRightPreview && columnIndex === drag.targetColumnEnd) cell.addClass("is-fill-preview-right");
    if (isRightPreview && rowIndex === range.rowStart) cell.addClass("is-fill-preview-top");
    if (isRightPreview && rowIndex === range.rowEnd) cell.addClass("is-fill-preview-bottom");
  }

  private applyColumnDragClasses(header: HTMLElement, columnIndex: number): void {
    const drag = this.columnDrag;
    if (!drag) return;
    if (drag.sourceIndex === columnIndex) header.addClass("is-drag-source");
    if (drag.targetInsertIndex === columnIndex) header.addClass("is-drop-before");
    if (drag.targetInsertIndex === columnIndex + 1) header.addClass("is-drop-after");
  }

  private applyRowDragClasses(rowHeader: HTMLElement, rowIndex: number): void {
    const drag = this.rowDrag;
    if (!drag) return;
    if (drag.sourceIndex === rowIndex) rowHeader.addClass("is-drag-source");
    if (drag.targetInsertIndex === rowIndex) rowHeader.addClass("is-drop-before");
    if (drag.targetInsertIndex === rowIndex + 1) rowHeader.addClass("is-drop-after");
  }

  private isCellSelected(rowIndex: number, columnIndex: number): boolean {
    const range = this.normalizedSelectionRange();
    return Boolean(
      range &&
        rowIndex >= range.rowStart &&
        rowIndex <= range.rowEnd &&
        columnIndex >= range.columnStart &&
        columnIndex <= range.columnEnd
    );
  }

  private isRowSelected(rowIndex: number): boolean {
    const range = this.normalizedSelectionRange();
    const fieldCount = this.visibleFields().length;
    return Boolean(range && range.rowStart <= rowIndex && range.rowEnd >= rowIndex && range.columnStart === 0 && range.columnEnd === fieldCount - 1);
  }

  private isColumnSelected(columnIndex: number): boolean {
    const range = this.normalizedSelectionRange();
    return Boolean(
      range &&
        range.columnStart <= columnIndex &&
        range.columnEnd >= columnIndex &&
        range.rowStart === 0 &&
        range.rowEnd === Math.max(0, this.visibleRecords.length - 1)
    );
  }

  private isActive(recordId: string, fieldId: string): boolean {
    return this.activeCell?.recordId === recordId && this.activeCell.fieldId === fieldId;
  }

  private selectionKey(): string {
    const range = this.normalizedSelectionRange();
    return range ? `${range.rowStart}:${range.rowEnd}:${range.columnStart}:${range.columnEnd}` : "";
  }

  private fillDragKey(): string {
    const drag = this.fillDrag;
    return drag
      ? `${drag.direction ?? "none"}:${drag.baseRange.rowStart}:${drag.baseRange.rowEnd}:${drag.baseRange.columnStart}:${drag.baseRange.columnEnd}:${drag.targetRowEnd}:${drag.targetColumnEnd}`
      : "";
  }

  private rowDragKey(): string {
    const drag = this.rowDrag;
    return drag ? `${drag.sourceIndex}:${drag.targetInsertIndex ?? ""}` : "";
  }

  private canReorderRows(): boolean {
    const view = this.currentView();
    return view.type === "grid" && !this.quickSearch && view.filters.length === 0 && view.sorts.length === 0;
  }

  private frozenFieldCount(fields: DuoweiField[]): number {
    const view = this.currentView();
    if (view.type !== "grid" || !Number.isFinite(view.frozenFieldCount)) return 0;
    return clamp(Math.floor(view.frozenFieldCount), 0, fields.length);
  }

  private frozenLeftOffsets(fields: DuoweiField[]): number[] {
    const offsets: number[] = [];
    let left = 40;
    for (const field of fields) {
      offsets.push(left);
      left += field.width ?? defaultFieldWidth(field.type);
    }
    return offsets;
  }

  private applyFrozenColumnStyle(
    element: HTMLElement,
    fields: DuoweiField[],
    columnIndex: number,
    frozenCount: number,
    frozenLeft: number[]
  ): void {
    if (columnIndex >= frozenCount) return;
    element.addClass("is-frozen");
    element.style.left = `${frozenLeft[columnIndex] ?? 40}px`;
    if (columnIndex === frozenCount - 1 || columnIndex === fields.length - 1) element.addClass("is-frozen-edge");
  }

  private firstCell(): ActiveCell | null {
    const record = this.visibleRecords[0] ?? this.documentModel.records[0];
    const field = this.visibleFields()[0] ?? this.documentModel.fields[0];
    if (!record || !field) return null;
    return { recordId: record.id, fieldId: field.id, rowIndex: 0, columnIndex: 0 };
  }

  private scrollCellIntoView(rowIndex: number, columnIndex: number): void {
    const fields = this.visibleFields();
    const rowHeight = this.rowHeight();
    const rowTop = rowIndex * rowHeight;
    const rowBottom = rowTop + rowHeight;
    if (rowTop < this.scrollerEl.scrollTop) this.scrollerEl.scrollTop = rowTop;
    else if (rowBottom > this.scrollerEl.scrollTop + this.scrollerEl.clientHeight) {
      this.scrollerEl.scrollTop = rowBottom - this.scrollerEl.clientHeight;
    }

    let left = 40;
    for (let index = 0; index < columnIndex; index += 1) {
      left += fields[index]?.width ?? defaultFieldWidth(fields[index]?.type ?? "text");
    }
    const frozenCount = this.frozenFieldCount(fields);
    if (columnIndex < frozenCount) return;
    const width = fields[columnIndex]?.width ?? 180;
    const frozenWidth = this.frozenVisibleWidth(fields);
    const visibleLeft = this.scrollerEl.scrollLeft + frozenWidth;
    if (left < visibleLeft) this.scrollerEl.scrollLeft = Math.max(0, left - frozenWidth);
    else if (left + width > this.scrollerEl.scrollLeft + this.scrollerEl.clientWidth) {
      this.scrollerEl.scrollLeft = left + width - this.scrollerEl.clientWidth + frozenWidth;
    }
  }

  private focusRenderedActiveCell(scroll = true): void {
    if (!this.activeCell) return;
    if (scroll) this.scrollCellIntoView(this.activeCell.rowIndex, this.activeCell.columnIndex);
    const cell = this.cellElement(this.activeCell.rowIndex, this.activeCell.columnIndex);
    if (cell && this.rootEl.doc.activeElement !== cell) cell.focus();
  }

  private focusRecordInGrid(record: DuoweiRecord, field: DuoweiField | null | undefined): void {
    const grid = this.viewByType("grid");
    const rowIndex = Math.max(0, this.visibleRecords.findIndex((item) => item.id === record.id));
    const targetField = field ?? this.documentModel.fields[0];
    const columnIndex = Math.max(0, this.visibleFields().findIndex((item) => item.id === targetField?.id));
    this.applyMutation("切换到表格", (document) => {
      const view = document.views.find((item) => item.id === grid.id) ?? document.views.find((item) => item.type === "grid");
      if (view) document.activeViewId = view.id;
    });
    this.recomputeRecords();
    const fields = this.visibleFields();
    const nextRowIndex = clamp(
      this.visibleRecords.findIndex((item) => item.id === record.id),
      0,
      Math.max(0, this.visibleRecords.length - 1)
    );
    const nextColumnIndex = clamp(
      fields.findIndex((item) => item.id === targetField?.id),
      0,
      Math.max(0, fields.length - 1)
    );
    const nextRecord = this.visibleRecords[nextRowIndex] ?? this.visibleRecords[rowIndex] ?? record;
    const nextField = fields[nextColumnIndex] ?? fields[columnIndex] ?? targetField;
    this.activeCell = nextRecord && nextField ? { recordId: nextRecord.id, fieldId: nextField.id, rowIndex: nextRowIndex, columnIndex: nextColumnIndex } : null;
    this.selectionRange = this.activeCell
      ? {
          anchorRow: this.activeCell.rowIndex,
          anchorColumn: this.activeCell.columnIndex,
          focusRow: this.activeCell.rowIndex,
          focusColumn: this.activeCell.columnIndex
        }
      : null;
    this.renderAll(true);
  }

  private cellElement(rowIndex: number, columnIndex: number): HTMLElement | null {
    return this.bodyEl.querySelector(
      `.mt-grid-cell[data-row="${rowIndex}"][data-column="${columnIndex}"]`
    ) as HTMLElement | null;
  }

  private totalWidth(fields: DuoweiField[]): number {
    return 40 + fields.reduce((sum, field) => sum + (field.width ?? defaultFieldWidth(field.type)), 0);
  }

  private frozenVisibleWidth(fields: DuoweiField[]): number {
    return fields
      .slice(0, this.frozenFieldCount(fields))
      .reduce((sum, field) => sum + (field.width ?? defaultFieldWidth(field.type)), 40);
  }

  private gridTemplate(fields: DuoweiField[]): string {
    return `40px ${fields.map((field) => `${field.width ?? defaultFieldWidth(field.type)}px`).join(" ")}`;
  }

  private rowHeight(): number {
    const view = this.currentView();
    const density = view.type === "grid" ? view.rowHeight : "default";
    if (density === "compact") return 28;
    if (density === "comfortable") return 40;
    return 32;
  }

  private displayValue(value: unknown, field: DuoweiField): string {
    if (value === undefined || value === null) return "";
    if (field.type === "checkbox") return value === true ? "是" : "否";
    if (field.type === "singleSelect") {
      const option = field.options?.find((item) => item.id === value || item.name === value);
      return option?.name ?? String(value);
    }
    if (field.type === "multiSelect") {
      const values = Array.isArray(value) ? value : [value];
      return values
        .filter((item) => item !== undefined && item !== null && item !== "")
        .map((item) => field.options?.find((option) => option.id === item || option.name === item)?.name ?? String(item))
        .join(", ");
    }
    return String(value);
  }

  private refreshFormulaValues(document: DuoweiDocument): void {
    // Basic 版没有公式/查找/汇总等计算字段，无需回填。
    void document;
  }

  private editValue(value: unknown, field: DuoweiField): string {
    if (field.type === "singleSelect" || field.type === "multiSelect") return this.displayValue(value, field);
    if (value === undefined || value === null) return "";
    return String(value);
  }

  private fieldTypeIcon(type: DuoweiFieldType): string {
    return FIELD_TYPES.find((item) => item.type === type)?.icon ?? "type";
  }

  private uniqueFieldName(base: string): string {
    const names = new Set(this.documentModel.fields.map((field) => field.name));
    if (!names.has(base)) return base;
    let index = 2;
    while (names.has(`${base} ${index}`)) index += 1;
    return `${base} ${index}`;
  }
}

function createDocumentForView(name: string): DuoweiDocument {
  const document = parseDuoweiDocument("", name).document;
  document.name = name;
  return document;
}

function backupTimestamp(): string {
  return new Date().toISOString().replace(/[:.]/g, "-");
}

function backupKindLabel(kind: BackupFileInfo["kind"]): string {
  return kind === "auto" ? "自动备份" : "冲突备份";
}

function backupKindDisplayName(kind: BackupFileInfo["kind"]): string {
  return kind === "auto" ? "自动备份" : "冲突备份";
}

function backupPrefixes(tableBaseName: string, kind?: BackupFileInfo["kind"]): string[] {
  const labels = kind ? [backupKindLabel(kind)] : [backupKindLabel("auto"), backupKindLabel("conflict")];
  return labels.map((label) => `${tableBaseName}.${label}.`);
}

function backupKindFromName(baseName: string): BackupFileInfo["kind"] {
  return baseName.includes(".自动备份.") ? "auto" : "conflict";
}

function backupDisplayName(file: TFile, tableBaseName: string): string {
  const prefixes = tableBaseName ? backupPrefixes(tableBaseName) : [];
  const suffix = `.${file.extension}`;
  let label = file.name;
  for (const prefix of prefixes) {
    if (label.startsWith(prefix)) {
      label = label.slice(prefix.length);
      break;
    }
  }
  if (label.endsWith(suffix)) label = label.slice(0, -suffix.length);
  return label || file.name;
}

function formatDateTimeLabel(date: Date): string {
  if (Number.isNaN(date.getTime())) return "未知时间";
  return date.toLocaleString(undefined, {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit"
  });
}

function formatByteSize(size: number): string {
  if (!Number.isFinite(size) || size < 0) return "未知大小";
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
  return `${(size / 1024 / 1024).toFixed(1)} MB`;
}

function conflictSignature(path: string, diskData: string, currentData: string): string {
  return `${path}:${stringHash(diskData)}:${stringHash(currentData)}`;
}

function stringHash(value: string): string {
  let hash = 2166136261;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(36);
}

function syncTimeLabel(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

function operationLogIcon(item: OperationLogItem): string {
  if (item.status === "error") return "circle-alert";
  if (item.status === "warning") return "triangle-alert";
  switch (item.type) {
    case "undo":
      return "undo-2";
    case "redo":
      return "redo-2";
    case "sync":
      return "refresh-cw";
    case "conflict":
      return "shield-alert";
    case "import":
      return "upload";
    case "export":
      return "download";
    case "system":
      return "settings";
    default:
      return "pencil";
  }
}

function operationLogTypeLabel(type: OperationLogItem["type"]): string {
  switch (type) {
    case "edit":
      return "编辑";
    case "undo":
      return "撤销";
    case "redo":
      return "重做";
    case "sync":
      return "同步";
    case "conflict":
      return "冲突";
    case "import":
      return "导入";
    case "export":
      return "导出";
    case "system":
      return "系统";
  }
}

function createDocumentDiffSummary(
  leftData: string,
  rightData: string,
  leftFallbackName: string,
  rightFallbackName: string,
  leftTitle: string,
  rightTitle: string
): DocumentDiffSummary {
  const base: DocumentDiffSummary = {
    leftTitle,
    rightTitle,
    addedFields: 0,
    removedFields: 0,
    changedFields: 0,
    addedRecords: 0,
    removedRecords: 0,
    changedRecords: 0,
    changedValues: 0,
    notePathChanges: 0,
    viewChanges: 0,
    leftUpdatedAt: null,
    rightUpdatedAt: null,
    error: null
  };
  const left = parseDuoweiDocument(leftData, leftFallbackName);
  const right = parseDuoweiDocument(rightData, rightFallbackName);
  base.leftUpdatedAt = left.document.meta.updatedAt;
  base.rightUpdatedAt = right.document.meta.updatedAt;
  if (left.repaired || right.repaired) {
    base.error = [left.repaired ? `${leftTitle} 需要修复：${left.error ?? "结构不完整"}` : "", right.repaired ? `${rightTitle} 需要修复：${right.error ?? "结构不完整"}` : ""]
      .filter(Boolean)
      .join("；");
    return base;
  }
  const leftFields = new Map(left.document.fields.map((field) => [field.id, field]));
  const rightFields = new Map(right.document.fields.map((field) => [field.id, field]));
  for (const [id, field] of rightFields) {
    const oldField = leftFields.get(id);
    if (!oldField) base.addedFields += 1;
    else if (JSON.stringify(field) !== JSON.stringify(oldField)) base.changedFields += 1;
  }
  for (const id of leftFields.keys()) {
    if (!rightFields.has(id)) base.removedFields += 1;
  }

  const leftRecords = new Map(left.document.records.map((record) => [record.id, record]));
  const rightRecords = new Map(right.document.records.map((record) => [record.id, record]));
  for (const [id, record] of rightRecords) {
    const oldRecord = leftRecords.get(id);
    if (!oldRecord) {
      base.addedRecords += 1;
      continue;
    }
    let changed = false;
    if ((oldRecord.notePath ?? null) !== (record.notePath ?? null)) {
      base.notePathChanges += 1;
      changed = true;
    }
    const fieldIds = new Set([...Object.keys(oldRecord.values), ...Object.keys(record.values)]);
    for (const fieldId of fieldIds) {
      if (JSON.stringify(oldRecord.values[fieldId] ?? null) === JSON.stringify(record.values[fieldId] ?? null)) continue;
      base.changedValues += 1;
      changed = true;
    }
    if (changed) base.changedRecords += 1;
  }
  for (const id of leftRecords.keys()) {
    if (!rightRecords.has(id)) base.removedRecords += 1;
  }
  if (JSON.stringify(left.document.views) !== JSON.stringify(right.document.views)) base.viewChanges = 1;
  return base;
}

function operationChangeDetail(before: DuoweiDocument, after: DuoweiDocument): string {
  const details: string[] = [];
  const recordDelta = after.records.length - before.records.length;
  const fieldDelta = after.fields.length - before.fields.length;
  if (recordDelta > 0) details.push(`新增 ${recordDelta} 行`);
  else if (recordDelta < 0) details.push(`删除 ${Math.abs(recordDelta)} 行`);
  if (fieldDelta > 0) details.push(`新增 ${fieldDelta} 列`);
  else if (fieldDelta < 0) details.push(`删除 ${Math.abs(fieldDelta)} 列`);
  const beforeRecordIds = new Set(before.records.map((record) => record.id));
  const afterFieldsById = new Map(after.fields.map((field) => [field.id, field]));
  let changedCells = 0;
  let changedRecords = 0;
  for (const afterRecord of after.records) {
    if (!beforeRecordIds.has(afterRecord.id)) continue;
    const beforeRecord = before.records.find((record) => record.id === afterRecord.id);
    if (!beforeRecord) continue;
    let recordChanged = false;
    for (const field of afterFieldsById.values()) {
      if (JSON.stringify(beforeRecord.values[field.id] ?? null) === JSON.stringify(afterRecord.values[field.id] ?? null)) continue;
      changedCells += 1;
      recordChanged = true;
    }
    if (recordChanged) changedRecords += 1;
  }
  if (changedCells > 0) details.push(`修改 ${changedRecords} 行 ${changedCells} 个值`);
  return details.join("，") || "更新表格状态";
}

interface VaultFilePickerOptions {
  title: string;
  files: TFile[];
  onChoose: (file: TFile) => void;
}

class VaultFilePickerModal extends Modal {
  private query = "";
  private listEl!: HTMLDivElement;

  constructor(
    app: App,
    private readonly options: VaultFilePickerOptions
  ) {
    super(app);
  }

  onOpen(): void {
    this.modalEl.addClass("mt-file-picker-modal");
    this.titleEl.empty();
    this.titleEl.createSpan({ text: this.options.title });
    this.contentEl.empty();
    const search = this.contentEl.createEl("input", {
      cls: "mt-file-picker__search",
      type: "search",
      attr: { placeholder: "搜索文件名或路径", "aria-label": "搜索文件" }
    });
    this.listEl = this.contentEl.createDiv({ cls: "mt-file-picker__list" });
    search.addEventListener("input", () => {
      this.query = search.value.trim().toLowerCase();
      this.renderList();
    });
    this.renderList();
    this.modalEl.win.setTimeout(() => search.focus(), 0);
  }

  onClose(): void {
    this.contentEl.empty();
  }

  private renderList(): void {
    this.listEl.empty();
    const files = this.options.files
      .filter((file) => {
        if (!this.query) return true;
        return file.path.toLowerCase().includes(this.query) || file.basename.toLowerCase().includes(this.query);
      })
      .slice(0, 80);
    if (files.length === 0) {
      this.listEl.createDiv({ cls: "mt-file-picker__empty", text: "没有匹配的文件" });
      return;
    }
    for (const file of files) {
      const item = this.listEl.createEl("button", { cls: "mt-file-picker__item", attr: { type: "button" } });
      const icon = item.createSpan({ cls: "mt-file-picker__icon", attr: { "aria-hidden": "true" } });
      setIcon(icon, file.extension === "md" ? "file-text" : "paperclip");
      const text = item.createSpan({ cls: "mt-file-picker__text" });
      text.createSpan({ cls: "mt-file-picker__name", text: file.name });
      text.createSpan({ cls: "mt-file-picker__path", text: file.path });
      item.addEventListener("click", () => {
        this.options.onChoose(file);
        this.close();
      });
    }
  }
}

function inputTypeForField(type: DuoweiFieldType): string {
  switch (type) {
    case "number":
      return "number";
    case "date":
      return "date";
    case "email":
      return "email";
    default:
      return "text";
  }
}

function linkedFieldIcon(type: DuoweiFieldType): IconName {
  switch (type) {
    case "email":
      return "mail";
    case "noteLink":
      return "file-text";
    case "attachment":
      return "paperclip";
    default:
      return "link";
  }
}

function stripWikiLink(value: string): string {
  const trimmed = value.trim();
  const match = trimmed.match(/^\[\[([^|\]]+)(?:\|[^\]]+)?\]\]$/);
  return (match?.[1] ?? trimmed).trim();
}

function parseRawValue(raw: string, field: DuoweiField): unknown {
  const value = raw.trim();
  if (value === "") return field.type === "checkbox" ? false : undefined;
  switch (field.type) {
    case "number": {
      const number = Number(value);
      if (!Number.isFinite(number)) throw new Error("请输入有效数字");
      return number;
    }
    case "checkbox":
      return ["true", "1", "yes", "y", "是", "对", "已完成"].includes(value.toLowerCase());
    case "singleSelect":
      return optionIdForLabel(field, value);
    case "multiSelect":
      return value
        .split(/[,，]/)
        .map((item) => item.trim())
        .filter(Boolean)
        .map((item) => optionIdForLabel(field, item));
    case "email":
      return normalizeEmailAddress(value);
    case "noteLink":
      return normalizeNoteLinkValue(value);
    default:
      return raw;
  }
}

function normalizeEmailAddress(value: string): string {
  const email = value.trim().replace(/^mailto:/i, "");
  if (!/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(email)) {
    throw new Error("请输入有效邮箱，例如 name@example.com");
  }
  return email;
}

function normalizeNoteLinkValue(value: string): string {
  const cleaned = stripWikiLink(value);
  if (!cleaned || /[\r\n]/.test(cleaned)) {
    throw new Error("请输入有效笔记链接");
  }
  return cleaned;
}

function optionIdForLabel(field: DuoweiField, label: string): string {
  field.options = field.options ?? [];
  const existing = field.options.find((option) => option.id === label || option.name === label);
  if (existing) return existing.id;
  const option = {
    id: `opt_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`,
    name: label,
    color: nextOptionColor(field.options)
  };
  field.options.push(option);
  return option.id;
}

function cloneFieldForType(field: DuoweiField, type: DuoweiFieldType): DuoweiField {
  const clone: DuoweiField = {
    ...field,
    type,
    options: field.options ? field.options.map((option) => ({ ...option })) : undefined
  };
  if ((type === "singleSelect" || type === "multiSelect") && !clone.options) clone.options = [];
  return clone;
}

function cloneFieldForBulkParse(field: DuoweiField): DuoweiField {
  return {
    ...field,
    options: field.options ? field.options.map((option) => ({ ...option })) : undefined
  };
}

function analyzeFieldMigration(records: DuoweiRecord[], sourceField: DuoweiField, targetField: DuoweiField): FieldMigrationImpact {
  const impact: FieldMigrationImpact = { nonEmpty: 0, changed: 0, emptied: 0, failed: 0, items: [] };
  for (let rowIndex = 0; rowIndex < records.length; rowIndex += 1) {
    const record = records[rowIndex];
    if (!record) continue;
    const before = record.values[sourceField.id];
    if (before === undefined || before === null || before === "") continue;
    impact.nonEmpty += 1;
    try {
      const after = coerceValueForMigration(before, targetField);
      if (after === undefined || after === null || after === "") impact.emptied += 1;
      if (JSON.stringify(before) !== JSON.stringify(after)) impact.changed += 1;
      impact.items.push({ recordId: record.id, rowIndex, before, after });
    } catch (error) {
      impact.emptied += 1;
      impact.failed += 1;
      impact.items.push({
        recordId: record.id,
        rowIndex,
        before,
        error: error instanceof Error ? error.message : "无法转换"
      });
    }
  }
  return impact;
}

function coerceValueForMigration(value: unknown, field: DuoweiField): unknown {
  if (value === undefined || value === null || value === "") return field.type === "checkbox" ? false : undefined;
  if (field.type === "number") {
    const number = Number(value);
    if (!Number.isFinite(number)) throw new Error(`“${String(value)}”不是有效数字`);
    return number;
  }
  if (field.type === "date") {
    const text = String(value).trim();
    if (!/^\d{4}-\d{2}-\d{2}/.test(text)) throw new Error(`“${text}”不是有效日期`);
    return text;
  }
  return coerceValue(value, field);
}

function frontmatterValueForField(value: unknown, field: DuoweiField): unknown {
  if (value === undefined || value === null || value === "") return undefined;
  switch (field.type) {
    case "checkbox":
      return value === true;
    case "number": {
      const number = Number(value);
      return Number.isFinite(number) ? number : undefined;
    }
    case "singleSelect": {
      const option = field.options?.find((item) => item.id === value || item.name === value);
      return option?.name ?? String(value);
    }
    case "multiSelect": {
      const values = Array.isArray(value) ? value : [value];
      const mapped = values
        .filter((item) => item !== undefined && item !== null && item !== "")
        .map((item) => field.options?.find((option) => option.id === item || option.name === item)?.name ?? String(item));
      return mapped.length > 0 ? mapped : undefined;
    }
    default:
      return value;
  }
}

function duoweiValueFromFrontmatter(value: unknown, field: DuoweiField): unknown {
  if (value === undefined || value === null || value === "") return field.type === "checkbox" ? false : undefined;
  switch (field.type) {
    case "checkbox":
      return value === true || String(value).toLowerCase() === "true" || String(value) === "是";
    case "number": {
      const number = Number(value);
      return Number.isFinite(number) ? number : undefined;
    }
    case "singleSelect":
      return optionIdForLabel(field, String(value));
    case "multiSelect": {
      const values = Array.isArray(value) ? value : String(value).split(/[,，]/);
      return values
        .map((item) => String(item).trim())
        .filter(Boolean)
        .map((item) => optionIdForLabel(field, item));
    }
    default:
      return value;
  }
}

function frontmatterKeyFromFieldName(name: string): string {
  const normalized = name
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "_")
    .replace(/[^\p{Letter}\p{Number}_-]+/gu, "");
  return normalized || "field";
}

function coerceValue(value: unknown, field: DuoweiField): unknown {
  if (value === undefined || value === null || value === "") return field.type === "checkbox" ? false : undefined;
  if (field.type === "checkbox") return value === true || value === "true" || value === "是";
  if (field.type === "number") {
    const number = Number(value);
    return Number.isFinite(number) ? number : undefined;
  }
  if (field.type === "multiSelect") {
    const values = Array.isArray(value) ? value : String(value).split(/[,，]/);
    return values.map((item) => optionIdForLabel(field, String(item).trim())).filter(Boolean);
  }
  if (field.type === "singleSelect") return optionIdForLabel(field, String(value));
  return String(value);
}

function inferFieldType(values: string[]): DuoweiFieldType {
  const nonEmpty = values.map((value) => value.trim()).filter(Boolean);
  if (nonEmpty.length === 0) return "text";
  if (nonEmpty.every((value) => isBooleanText(value))) return "checkbox";
  if (nonEmpty.every((value) => Number.isFinite(Number(value)))) return "number";
  if (nonEmpty.every((value) => /^\d{4}-\d{2}-\d{2}/.test(value))) return "date";
  const unique = new Set(nonEmpty);
  if (unique.size <= Math.min(40, Math.max(3, Math.ceil(nonEmpty.length * 0.6)))) return "singleSelect";
  return "text";
}

function isBooleanText(value: string): boolean {
  return ["true", "false", "1", "0", "yes", "no", "y", "n", "是", "否", "对", "错", "已完成", "未完成"].includes(
    value.trim().toLowerCase()
  );
}

function uniqueName(baseName: string, usedNames: Set<string>): string {
  if (!usedNames.has(baseName)) {
    usedNames.add(baseName);
    return baseName;
  }
  let index = 2;
  while (usedNames.has(`${baseName} ${index}`)) index += 1;
  const name = `${baseName} ${index}`;
  usedNames.add(name);
  return name;
}

function isDuoweiField(value: DuoweiField | undefined): value is DuoweiField {
  return value !== undefined;
}

function isComputedField(field: DuoweiField): boolean {
  // Basic 版没有公式/查找/汇总等计算字段。
  void field;
  return false;
}

function computedReadonlyMessage(field: DuoweiField, includeHint = true): string {
  void field;
  return includeHint ? "该字段只读。" : "只读字段";
}

function createDefaultViewForType(type: DuoweiViewType, fields: DuoweiField[]): DuoweiViewConfig {
  if (type === "kanban") return createDefaultKanbanView(fields);
  if (type === "gallery") return createDefaultGalleryView(fields);
  return createDefaultGridView(fields);
}

function viewSwitchLabel(type: DuoweiViewType): string {
  if (type === "kanban") return "切换到看板";
  if (type === "gallery") return "切换到画廊";
  return "切换到表格";
}

function viewTypeLabel(type: DuoweiViewType): string {
  if (type === "kanban") return "看板";
  if (type === "gallery") return "画廊";
  return "表格";
}

function viewTypeIcon(type: DuoweiViewType): IconName {
  if (type === "kanban") return "columns-3";
  if (type === "gallery") return "layout-grid";
  return "table-2";
}

function parseClipboardTable(text: string): string[][] {
  const normalized = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  const trimmed = normalized.endsWith("\n") ? normalized.slice(0, -1) : normalized;
  return trimmed.split("\n").map((row) => row.split("\t"));
}

function cloneCellValue(value: unknown): unknown {
  if (Array.isArray(value)) return [...value];
  if (value && typeof value === "object") return JSON.parse(JSON.stringify(value)) as unknown;
  return value;
}

function isEditorElement(target: EventTarget | null): boolean {
  return target instanceof HTMLElement && Boolean(target.closest("input, textarea, select, .mt-cell-editor"));
}

function isPrintableEditKey(event: KeyboardEvent): boolean {
  if (event.isComposing) return false;
  if (event.ctrlKey || event.metaKey || event.altKey) return false;
  return event.key.length === 1 && event.key !== " ";
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}
