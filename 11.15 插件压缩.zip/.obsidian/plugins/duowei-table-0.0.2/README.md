# Duowei Table

[![Language: English](https://img.shields.io/badge/Language-English-0078d4)](README.md)
[![Language: Simplified Chinese](https://img.shields.io/badge/Language-%E7%AE%80%E4%BD%93%E4%B8%AD%E6%96%87-d73a49)](README_CN.md)

Local, spreadsheet-style structured data for Obsidian. Records, fields, views,
and settings live in plain-text JSON `.duowei` files inside your vault, so they
can be read, diffed, synchronized, and backed up with ordinary tools.

The Community Edition includes the complete local table engine, 22 field types,
seven view types, imports and exports, Markdown integration, and backup recovery.
It requires no account, license key, trial, payment, or cloud service.

An optional enhanced edition, **[Duowei Table Pro][pro]**, is distributed
separately. It is never required to use the Community Edition.

See the [v0.0.3 Release Notes](RELEASE_NOTES.md) for changes since the initial
Community Edition.

> **Interface language:** the plugin interface, commands, and settings are
> currently in Simplified Chinese. This English README is a translated usage
> guide; it does not indicate that the interface itself has been localized.

---

## Features

**Field types (22):** text, long text, number, checkbox, date, date and time,
single select, multiple select, URL, email, phone, rating, progress, note link,
attachment, relation, lookup, rollup, formula, created time, updated time, and
auto number.

**Views (7):** grid, Kanban, gallery, calendar, timeline, form, and dashboard.

- Standalone `.duowei` files, with a command for creating a blank table
- Add, delete, rename, reorder, and retype fields; type changes include a
  migration preview before values are converted
- Cell editing, range selection, matrix copy and paste, automatic row/column
  expansion, clear, undo/redo, fill handles, and previewed bulk edits
- Search, type-aware filters, sorting, field visibility, row height, frozen
  columns, conditional formatting, and up to three grouping levels per view
- Column summaries for sums, averages, extrema, filled/unfilled counts, unique
  values, and checked values
- Kanban drag-to-change-value; configurable gallery covers; calendar and timeline
  date layouts; validated forms; dashboard metric cards and charts
- Create, switch, rename, duplicate, and delete views from a persistent view bar
- A record detail panel with previous/next navigation, field groups, and Markdown
  preview for long text
- Number, percentage, currency, date, and date-time formatting; required fields
  and numeric range validation
- Formula fields with field references, arithmetic, comparisons, logic, and
  aggregate functions
- Same-file and cross-file relations, plus lookup, rollup, and reverse-relation
  fields
- CSV/TSV import with preview, field mapping, type confirmation, and error reports;
  CSV/TSV export for the current table or view
- Editable folder imports, live read-only vault indexes, and migration from
  Obsidian Bases
- Bind records to Markdown notes and synchronize selected fields with frontmatter
- Embed filtered table views and individual dashboard charts in Markdown notes
- Note links, attachments, email addresses, and URLs with validation, file pickers,
  hover previews, image thumbnails, and a lightbox
- Autosave, external-modification detection, isolated `.duoweibak` snapshots,
  per-cell conflict merging, backup restoration, and persistent operation logs
- Row virtualization, cached indexes, paginated cards, and a lightweight edit
  pipeline for large tables
- Light, dark, desktop, tablet, and mobile responsive styles

## Usage

### Standalone tables

1. Open the Command Palette.
2. Run **创建空白多维表格** (*Create blank multidimensional table*).
3. The plugin creates and opens a `.duowei` file. New tables are stored in the
   `多维表格` folder by default.
4. Add fields with the `+` button in the header, then add records or configure
   filters, groups, sorting, colors, and views from the toolbar.

Design principles:

- A row is a record; it does not have to correspond to a Markdown file.
- A column is a field that can be managed directly inside the table.
- Cell values, field definitions, and view settings live in the `.duowei` file.
- Markdown binding, frontmatter synchronization, and Bases migration are optional
  capabilities rather than prerequisites.

Example tables are available in [`examples/content-operations`](examples/content-operations).
Copy them into a vault and open them after enabling the plugin.

### Imports and vault data sources

- **从 Base 创建多维表格** (*Create a table from Base*) converts a selected
  `.base` file into a standalone table.
- **从当前 Base 创建多维表格** (*Create a table from the current Base*) converts
  the Base currently open in Obsidian.
- **从文件夹创建多维表格** (*Create a table from a folder*) can create either an
  editable imported table or a live read-only index of notes, images, documents,
  media, or all files in a vault scope.
- CSV/TSV import and export are available from the table menus.
- **快速添加记录到多维表格** (*Quick-add a record*) appends a record without
  opening the target table.

Editable folder imports can bind records to Markdown files and synchronize
configured fields with frontmatter. Live vault indexes keep source files as the
single source of truth and are intentionally read-only inside the table.

### Bases-compatible layout

1. Enable Obsidian's core **Bases** plugin.
2. Enable Duowei Table.
3. Create or open a `.base` file.
4. Select **多维表格** (*Duowei Table*) from the view/layout menu.

The compatibility layout uses Bases and Markdown/frontmatter as its data source.
Use one of the Base conversion commands when you want an independent `.duowei`
file instead.

### Embedding tables in notes

Embed a table or a named view with an Obsidian wikilink:

```md
![[多维表格/项目管理.duowei]]
![[多维表格/项目管理.duowei#表格]]
```

Use a `duowei` code block to select a view, record limit, and fields:

````md
```duowei
path: 多维表格/项目管理.duowei
view: 表格
limit: 10
fields: 标题, 状态, 截止日期
```
````

Embedded tables are read-only mini views that follow the target view's filters
and sorting. In the Markdown editor, run **插入多维表格图表引用** (*Insert a
Duowei Table chart reference*) to embed an individual dashboard chart.

### Keyboard operations

- `Ctrl/Cmd+C` and `Ctrl/Cmd+V`: copy or paste a cell/range/TSV matrix
- `Delete` or `Backspace`: clear editable cells
- `Tab` and `Shift+Tab`: move between cells
- `Ctrl/Cmd+H`: find and replace
- `Ctrl/Cmd+Arrow`: jump to a data boundary
- `Home` and `End`: jump to the start or end of a row
- Hold `Shift` with navigation shortcuts to extend the selection

## Editions and compatibility

The Community Edition is free to install and use. Every feature documented here
works without an account, license key, trial, or payment and is licensed under
the GNU General Public License v3.0.

The separately distributed **[Duowei Table Pro][pro]** primarily adds AI fields,
external calendar/task synchronization, and favorites synchronization. Formula,
relation, lookup, rollup, long-text, calendar, timeline, form, and dashboard
features are already part of the current Community Edition.

Both editions use the `.duowei` extension and `schemaVersion: 1` data format.
Files created by the Community Edition can be opened directly in Pro. Keep a
backup before editing a file that contains Pro-only configuration in the
Community Edition.

> Do not enable both editions at the same time. They register the same file
> extension and view types.

## Data and privacy

- `.duowei` files are plain-text JSON stored inside your vault.
- No account or cloud database is required.
- The Community Edition contains no analytics, telemetry, crash reporting, user
  identifiers, account service, or background vault upload logic.
- AI requests, external calendar/task synchronization, and favorites
  synchronization are not implemented in the Community Edition.
- External modifications are detected before saving; the plugin creates a
  conflict snapshot instead of silently overwriting the file.
- Automatic backups use the `.duoweibak` extension and are stored in
  `多维表格备份/{{folder}}` by default. The default minimum interval is 10 minutes,
  with 12 snapshots retained per table.
- Tables, backups, and dropped attachments stay inside the vault by default.
  On desktop, CSV/TSV export writes outside the vault only after you explicitly
  choose a destination.

## Network use

Core features such as editing, formulas, filtering, views, and local backups work
offline. The plugin contains no telemetry endpoint, account synchronization
service, or background logic that uploads vault data.

Normal network access may still occur when you deliberately open an external
link, display a remote image URL, copy a chart containing remote resources as an
image, use Obsidian's official update mechanism, or open an external website
linked from this document. Otherwise, the local table workflow does not depend
on an external service.

## Installation

Requirements:

- Obsidian `1.10.0` or later
- Desktop and mobile are supported
- Node.js 20 and npm are recommended only when building from source

**Manual installation:** create the folder below, then copy `main.js`,
`manifest.json`, and `styles.css` from the release package into it:

```text
<Your Vault>/.obsidian/plugins/obsidian-multidimensional-table-community/
```

Restart Obsidian or reload third-party plugins, turn off Restricted Mode if
necessary, and enable **多维表格（社区版）** in Settings → Community plugins.

**Build from source:**

```bash
npm ci
npm run build
```

Copy the generated `main.js` together with `manifest.json` and `styles.css` into
the plugin folder above.

## Development

```bash
npm ci
npm run dev       # Watch source files and rebuild
npm run build     # TypeScript checks + production bundle
npm run verify    # Build and run core/computed-field regression tests
```

Main directories:

```text
src/
├─ bases/       # Obsidian Bases compatibility view
├─ duowei/      # Standalone table engine, views, imports, and embeds
├─ grid/        # Grid virtualization
├─ settings/    # Plugin settings
└─ write/       # Record write-back queue
examples/       # Example .duowei files
scripts/        # Build verification and performance tests
tests/          # Test vault fixtures
```

## Support

- **Bug reports — [this repository's issue tracker][issues].** Include your
  Obsidian version, operating system, and a minimal `.duowei` file that reproduces
  the problem whenever possible.
- **Questions and discussion — QQ group `1094620986`.** The group communicates
  in Simplified Chinese.
- **Email — <jepicaju862@gmail.com>.** Use email for private reproduction files
  or anything you would rather not post publicly.
- **Duowei Table Pro — <https://peyote.info/plugins/duowei-table-pro/>.** Licensing,
  billing, and Pro-only capability questions belong on the dedicated Pro page.

[issues]: ../../issues

## License

[GNU General Public License v3.0](LICENSE)

[pro]: https://peyote.info/plugins/duowei-table-pro/
