import { readFile, stat } from "node:fs/promises";

/**
 * 发布门禁：既校验构建产物完整性，也守住上架时对官方目录做出的那几条承诺。
 * 任何一条失败都必须视为不可上架，而不是警告。
 */

const PLUGIN_ID = "duowei-table";

const required = ["main.js", "manifest.json", "styles.css", "LICENSE", "README.md"];
for (const file of required) {
  const info = await stat(file);
  if (!info.isFile() || info.size === 0) throw new Error(`${file} 缺失或为空`);
}

const manifest = JSON.parse(await readFile("manifest.json", "utf8"));
const pkg = JSON.parse(await readFile("package.json", "utf8"));
const versions = JSON.parse(await readFile("versions.json", "utf8"));

if (manifest.id !== PLUGIN_ID) throw new Error(`manifest id 必须是 ${PLUGIN_ID}`);
if (manifest.id.includes("obsidian")) throw new Error("插件 id 不得包含 obsidian");
if (/obsidian/i.test(manifest.name)) throw new Error("插件名不得包含 Obsidian");
if (manifest.minAppVersion !== "1.10.0") throw new Error("最低版本必须覆盖 BasesView API");
if (manifest.isDesktopOnly !== false) throw new Error("必须保持移动端兼容");

// 三处版本号必须一致，否则官方 Release 校验会直接失败。
if (manifest.version !== pkg.version) throw new Error("manifest 与 package.json 版本不一致");
if (!versions[manifest.version]) throw new Error("versions.json 缺少当前版本条目");
if (versions[manifest.version] !== manifest.minAppVersion) {
  throw new Error("versions.json 中的 minAppVersion 与 manifest 不一致");
}

const bundle = await readFile("main.js", "utf8");

// 违反开发者政策或与 README 披露矛盾的内容，一律不得进入产物。
const forbidden = [
  "app.internalPlugins",
  "eval(",
  "new Function(",
  // README 承诺本插件不发起任何网络请求
  "requestUrl",
  "XMLHttpRequest",
  "fetch(",
  "WebSocket"
];
for (const token of forbidden) {
  if (bundle.includes(token)) throw new Error(`构建产物包含禁止内容：${token}`);
}

// 完整版专有能力绝不能泄漏进社区版产物
const proOnly = ["puppeteer", "xiaohongshu", "googleWorkspace", "microsoftTodo", "aiField"];
for (const token of proOnly) {
  if (bundle.includes(token)) throw new Error(`社区版产物泄漏完整版内容：${token}`);
}

for (const token of ["duowei-grid", "processFrontMatter", "registerBasesView"]) {
  if (!bundle.includes(token)) throw new Error(`构建产物缺少关键能力：${token}`);
}

console.log(`build verification passed (${bundle.length.toLocaleString()} bytes)`);
