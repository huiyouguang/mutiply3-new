import { performance } from "node:perf_hooks";

function computeVirtualWindow({ scrollTop, viewportHeight, rowHeight, count, overscan = 6 }) {
  const safeCount = Math.max(0, Math.floor(count));
  const safeRowHeight = Math.max(1, rowHeight);
  if (safeCount === 0) return { start: 0, end: 0, offset: 0 };
  const firstVisible = Math.floor(Math.max(0, scrollTop) / safeRowHeight);
  const visibleCount = Math.ceil(Math.max(0, viewportHeight) / safeRowHeight);
  const start = Math.max(0, firstVisible - overscan);
  const end = Math.min(safeCount, firstVisible + visibleCount + overscan);
  return { start, end, offset: start * safeRowHeight };
}

const iterations = 250_000;
const started = performance.now();
let checksum = 0;
for (let index = 0; index < iterations; index += 1) {
  const result = computeVirtualWindow({
    scrollTop: (index * 37) % 3_200_000,
    viewportHeight: 900,
    rowHeight: 32,
    count: 100_000,
    overscan: 8
  });
  checksum += result.start + result.end;
}
const elapsed = performance.now() - started;

if (!Number.isFinite(checksum) || checksum <= 0) throw new Error("virtual window checksum failed");
if (elapsed > 500) throw new Error(`virtual window budget exceeded: ${elapsed.toFixed(1)} ms`);

console.log(`virtual window benchmark passed: ${iterations.toLocaleString()} calls in ${elapsed.toFixed(1)} ms`);
