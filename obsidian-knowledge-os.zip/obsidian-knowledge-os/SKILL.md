---
name: obsidian-knowledge-os
description: Obsidian 知识库 AI 驱动管理技能。提供知识加工站到主知识库的双层架构工作流，包括 Inbox 批量处理、知识笔记创建与路由分发、项目进度跟踪、全库分析、标签推荐、孤立笔记检测、模板应用等能力。当用户提出处理 Inbox、创建知识笔记、检查项目进度、生成周报、找孤立笔记、批量打标签、应用内容模板、话题归因、知识库分析、整理笔记等意图时触发。不依赖任何云端 AI 插件，完全通过 CodeBuddy Agent 本地执行。
---

# Obsidian Knowledge OS Skill

以 CodeBuddy Agent 为 AI 大脑，驱动 Obsidian Vault 的知识管理系统。该 Skill 将原 Knowledge OS 系统（依赖已停用的 Claudian 插件）适配为 CodeBuddy 本地方案。

## 核心架构：加工站 → 主知识库

该 Vault 采用双层架构：

```
┌─ AI Knowledge OS/ (加工站/厨房) ─┐
│  00-Inbox/      ← 待处理的原始信息
│  Templates/     ← 3 种处理模板
│  Agents/        ← Agent 角色定义  
│  Knowledge/     ← 模板示例（非主库）
│  Projects/      ← 项目跟踪
│  Analytics/     ← 分析报告
│  Dashboard.md   ← 驾驶舱入口
└────────────────────────────────────┘
            │ AI 加工后分发
            ▼
┌─ 主知识库 (外层目录) ─────────────┐
│  04成长/知识管理/  ← 考试/学习类
│  03Life os/        ← 生活/书籍/电影/播客
│  工作/             ← 跨境电商/税务
│  TaskNotes/        ← 任务/健康/心情
│  01 主页/          ← 仪表盘
└────────────────────────────────────┘
```

**关键原则**：AI Knowledge OS 不存储最终知识，它是加工后分发的厨房。所有加工完成的笔记按 domain 路由到外层主目录。

## 使用方式

### 读取 Vault 文件
使用 `read_file` 直接读取 Vault 中的任何文件。Vault 根路径为工作区根目录。

### 写入/修改 Vault 文件
使用 `write_to_file` 或 `replace_in_file` 直接操作 Vault 中的文件。创建知识笔记时必须在目标目录生成文件。

### 读取参考文件
当需要详细的领域路由表、模板规范、批量处理菜谱或 Agent 提示词时，读取 `references/` 目录下的对应文件。

## 工作流规则

### 1. Inbox 处理 SOP

当用户说"处理 Inbox"、"清理收件箱"时执行：

1. **列出**：读取 `AI Knowledge OS/00-Inbox/` 下所有 `.md` 文件
2. **逐个分析**：
   - 判断是否值得保留（无价值内容标记为删除）
   - 识别 domain（领域）和 type（概念/案例/方法）
   - 评估 rating（1-5，可复用性+证据充分度）
   - 确定 status（seed/growing/evergreen）
3. **查路由表**：读取 `references/routing-table.md`，确定目标目录
4. **生成知识笔记**：读取 `references/templates.md`，按知识笔记模板生成完整 frontmatter + 内容
5. **推荐 Wikilink**：分析内容，从已有笔记中推荐 3-5 个关联链接
6. **写入目标**：在主知识库目录创建 `.md` 文件
7. **清理 Inbox**：删除或归档原始文件到 `AI Knowledge OS/00-Inbox/.archive/`
8. **输出报告**：总数 / 新建 / 归档 / 删除

### 2. 知识笔记创建 SOP

当用户说"创建知识笔记"、"记录这个概念"时：

1. **加载模板**：读取 `assets/知识笔记模板.md`
2. **确定 domain**：分析内容，从已有领域列表匹配或建议新建
3. **填充 frontmatter**：
   - `title`: 用户指定或从内容提取
   - `domain`: 所属领域（必填）
   - `type`: concept/case/method/fact（必填）
   - `status`: seed→growing→evergreen（根据内容成熟度）
   - `rating`: 1-5（根据可复用性和证据充分度）
   - `source`: 信息来源（如有）
   - `tags`: 2-5 个标签，优先复用 Vault 已有标签
4. **填充正文**：一句话定义 → 为什么重要 → 证据与来源 → 适用边界
5. **推荐关联**：列出 3-5 个 Wikilink
6. **路由分发**：查路由表确定目标路径，写入文件

### 3. 项目跟踪 SOP

当用户说"检查项目进度"、"创建项目"、"更新项目"时：

1. 读取 `AI Knowledge OS/Projects/` 目录下所有 `.md` 文件
2. 读取 `AI Knowledge OS/Projects/Projects.base` 获取项目视图配置
3. 检查逾期项目（due < today 且 status != done）
4. 检查停滞项目（progress 长时间未更新）
5. 生成进度报告，含每个项目的下一步建议

### 4. 全库分析 SOP

当用户说"生成周报"、"知识分析"、"找孤立笔记"时：

- **周报**：统计本周新建/更新笔记、推荐连接、识别知识缺口
- **孤立检测**：扫描主知识库所有 `.md`，找 0 入链 + 0 出链 的笔记
- **缺口分析**：识别高频标签对应的笔记数量不足的领域

### 5. 批量处理 SOP

当用户说"批量打标签"、"批量应用模板"、"批量归档 Inbox"时：

读取 `references/batch-recipes.md` 获取具体菜谱，按对应流程执行。

## 目录排除规则

以下目录在全局扫描时应排除：
- `.obsidian/` — Obsidian 配置
- `.codebuddy/` — CodeBuddy 配置  
- `02 WorkBuddy/` — 开发应用
- `AI Knowledge OS/` — 加工站自身（仅 Inbox 处理时读取）
- `TaskNotes/健康数据/` — 日更流水数据
- `TaskNotes/心情/` — 日更心情数据
- `.trash/` — 回收站
- `node_modules/` — 依赖

## Domain → 路径路由

详细路由表见 `references/routing-table.md`。核心映射：

| domain | 目标路径 |
|--------|----------|
| 考试/注会/中级/司法/税务师 | `04成长/知识管理/` + 对应考试子目录 |
| 工作/跨境电商/税务合规 | `工作/` |
| 书籍/阅读 | `03Life os/05书籍/` |
| 电影 | `03Life os/06电影/` |
| 播客 | `03Life os/播客生活/` |
| 人生/哲学 | `03Life os/人生哲学/` |
| 生活/日常 | `03Life os/日常收藏/` |
| 企业AI/AI技术/知识工程 | `AI Knowledge OS/Knowledge/`（暂留在加工站，成熟后移出） |
| 项目跟踪 | `AI Knowledge OS/Projects/`（不移动） |
| 未知/无法归类 | `04成长/知识管理/`（兜底） |

## Agent 角色体系

当用户调用特定 Agent 时，使用 `references/agent-prompts.md` 中的优化提示词。

三个角色：
1. **内容助手** — 从知识生成公众号/视频稿/提案
2. **商业分析助手** — 分析企业客户、场景和落地路径
3. **学习助手** — 论文/资料转为可复用概念

## Frontmatter 字段规范

所有知识笔记必须包含以下 frontmatter 字段：

```yaml
---
title: "标题"           # 必填
domain: 领域            # 必填，从路由表匹配
type: concept|case|method|fact  # 必填
status: seed|growing|evergreen  # 必填
rating: 1-5             # 必填，价值评分
source: 来源             # 选填
tags:                   # 必填，2-5个标签
  - tag1
  - tag2
---
```

状态流转规则：
- `seed` → 初建，信息不完整，无链接或仅 1-2 个链接
- `growing` → 信息较完整，有 3+ 个 Wikilink
- `evergreen` → 充分论证，被多处引用，可复用的稳定知识

## 项目 Frontmatter 规范

```yaml
---
title: "标题"           # 必填
type: project           # 固定值
status: planning|active|blocked|done  # 必填
progress: 0-100         # 必填，百分比
next_action: 下一步      # 必填，可验收的下一步
due: YYYY-MM-DD         # 选填，截止日期
domain: 领域            # 选填
tags:                   # 必填
  - project/active
---
```

## 关键约束

1. **永远不要在 AI Knowledge OS/Knowledge/ 下创建最终笔记**。该目录仅存放模板示例。新知识笔记必须路由到外层主目录。
2. **加工站目录不可删除或改名**。插件代码硬编码了 `AI Knowledge OS` 路径名。
3. **.base 文件仅用于 Obsidian 展示**，Agent 不从 .base 读取数据。Agent 直接从 Markdown frontmatter 扫描。
4. **不要修改 `.obsidian/plugins/ai-knowledge-os/main.js`**。该文件是编译后的插件代码。
5. **批量操作前先告知用户操作数量**，获得确认后执行。
6. **所有写入使用 UTF-8 编码**，Wikilink 使用 `[[路径/文件名]]` 格式。
