# 分析引擎计算逻辑

Dashboard 和 Analytics 页面的统计计算伪代码，用于 Agent 手动执行全库分析。

## Dashboard 指标

### 笔记总数
```
排除系统目录后，统计所有 .md 文件数量
```

### 内部链接数
```
扫描所有 .md 文件中的 [[Wikilink]] 引用
去重后统计唯一链接对
```

### 未完成任务数
```
扫描所有 .md 文件中的 - [ ] 未完成复选框
排除 "AI Knowledge OS/Templates" 和系统目录
```

### 领域分布
```
从所有知识笔记的 frontmatter 中提取 domain 字段
按 domain 分组统计数量
```

### 最近更新（Top 10）
```
扫描主知识库所有 .md 文件的 file.mtime
按修改时间倒序排列，取前 10
```

### 高频标签（Top 5）
```
从所有 .md 文件的 frontmatter tags 中提取
排除 system/ 开头的系统标签
按使用频率排序，取前 5
```

## Analytics 分析

### 孤立笔记检测
```
输入：主知识库所有 .md 文件（排除系统目录）
输出：孤立笔记列表

对每个笔记：
  content = 读取文件全文
  出链 = 提取 content 中所有 [[xxx]] 引用
  入链 = 搜索全库，看哪些文件引用了当前笔记
  
  if 出链.count == 0 AND 入链.count == 0:
    标记为"完全孤立"
  elif 入链.count == 0 AND 出链.count > 0:
    标记为"弱连接（无入链）"
  elif 出链.count == 0 AND 入链.count > 0:
    标记为"弱连接（无出链）"
```

### 知识增长趋势
```
统计过去 4 周的新建/更新笔记数
按 domain 分组统计增长分布
识别增长最快和最慢的领域
```

### 缺口分析
```
1. 统计现有 domain 的笔记数
2. 识别核心知识链中的缺失环节
3. 检查高频标签对应笔记的 rating 分布
4. 找出 rating ≤2 的高频标签笔记 → 建议升级
5. 找出 status=seed 且创建超过 30 天 → 建议推进
```

### 知识价值排序
```
基于以下因素综合评分：
- rating（权重 0.4）
- 入链数（权重 0.35）— 被引用越多越有价值
- 出链数（权重 0.15）— 连接越多越完善
- 更新时间（权重 0.1）— 越新越好

公式：score = rating * 0.4 + in_links * 0.35 + out_links * 0.15 + freshness * 0.1
```

### 进度风险检测（Projects）
```
对每个项目：
  if due < today AND status != "done":
    标记为"已逾期"
  elif status != "done" AND progress == 0 AND 创建超过 14 天:
    标记为"启动风险"
  elif status == "blocked":
    标记为"阻塞中"
```

## 排除规则

所有分析都排除以下目录：
```
- .obsidian/
- .codebuddy/
- .git/
- .trash/
- node_modules/
- 02 WorkBuddy/
- AI Knowledge OS/Templates/（模板不是知识）
- AI Knowledge OS/00-Inbox/（未处理的原件）
- TaskNotes/健康数据/（日更流水）
- TaskNotes/心情/（日更心情）
```

## 使用方式

Agent 在执行分析时：
1. 使用 `search_file` 配合 glob 模式扫描目标目录
2. 使用 `read_file` 逐个读取并解析 frontmatter
3. 使用 `search_content` 搜索 Wikilink 引用关系
4. 汇总结果按以上逻辑计算
5. 输出 Markdown 格式报告
