# Vault 目录结构

主知识库的完整目录结构和各目录用途说明。

## 目录树

```
/Users/guochenfa/Downloads/mutiply3/
├── 01 主页/                  ← Obsidian 仪表盘和主页
│   ├── 仪表盘.md            ← DataviewJS 驱动的知识工作台
│   ├── 主页2.md             ← 备用主页
│   ├── 健康追踪.md          ← 健康数据追踪面板
│   └── Agent 控制台.md      ← Agent 输出汇总
│
├── 00 Inbox/                 ← 原始收件箱（直接捕获入口）
│
├── AI Knowledge OS/          ← 🏭 加工站（不存储最终知识）
│   ├── 00-Inbox/            ← 加工站收件箱
│   ├── Agents/              ← Agent 角色定义
│   ├── Analytics/           ← 分析报告
│   ├── Knowledge/           ← 模板示例（2 篇示例笔记）
│   ├── Projects/            ← 项目跟踪（1 个示例项目）
│   ├── Templates/           ← 3 种处理模板
│   ├── Dashboard.md         ← 加工站驾驶舱
│   ├── START-HERE.md        ← 使用说明
│   ├── Knowledge Map.canvas ← 知识网络可视化
│   └── README.md
│
├── 02 WorkBuddy/             ← AGI 开发应用（非知识内容）
│   ├── server/              ← Express + Agent SDK 服务
│   └── client/              ← 前端界面
│
├── 03Life os/                ← 📚 生活知识库
│   ├── 05书籍/              ← 读书笔记（42 项）
│   ├── 06电影/              ← 影视笔记（14 项）
│   ├── 播客生活/            ← 播客笔记（12 项）
│   ├── 人生哲学/            ← 深度思考
│   ├── 日常收藏/            ← 日常积累（129 项）
│   ├── 日常周记/            ← 周复盘
│   ├── 摄影摄像/            ← 摄影相关
│   ├── 思维拓展/            ← 思维模型
│   ├── 能力拓展/            ← 能力提升
│   ├── 30-Reading/          ← 阅读相关
│   └── 03LifeOS.base        ← Obsidian Bases 视图
│
├── 04成长/                   ← 🎓 学习与考试知识库
│   └── 知识管理/            ← 知识管理主目录（402 项）
│       ├── 001 考研/        ← 考研相关
│       ├── 002 司法考试/    ← 司法考试（法考）
│       ├── 003 中级/        ← 中级会计职称
│       ├── 004 注会/        ← 注册会计师考试
│       ├── 005 注册税务师/  ← 注册税务师
│       └── 错题库/          ← 各科错题汇总
│
├── 工作/                    ← 💼 工作知识库
│   ├── 亚马逊相关知识.md    ← 亚马逊跨境电商
│   └── ...                 ← 其他工作文件
│
├── TaskNotes/               ← 📋 任务与日更数据
│   ├── 01 task/             ← 任务管理
│   ├── 健康数据/            ← 日更健康记录
│   ├── 心情/                ← 日更心情日记
│   ├── Start Here.md        ← 任务系统入口
│   └── Tasks.md             ← 任务汇总
│
├── Templates/               ← 全库通用模板
├── 08数据库/                ← Obsidian Bases 视图文件
├── thino/                   ← Thino 快速笔记插件
├── Clippings/               ← 网页裁剪
└── .obsidian/               ← Obsidian 配置（不可修改）
    └── plugins/
        └── ai-knowledge-os/ ← AI Knowledge OS 插件
```

## 目录类型分类

### 🏭 加工站（只读/暂存）
- `AI Knowledge OS/` — Agent 从这里读模板和本 Skill 规则，但**不在这里创建最终笔记**

### 📚 主知识库（写入目标）
- `04成长/知识管理/` — 考试、学习、技能类知识
- `03Life os/` — 生活、书籍、电影、思考
- `工作/` — 工作相关专业内容

### 📋 流式数据（排除扫描）
- `TaskNotes/健康数据/` — 每日重复数据
- `TaskNotes/心情/` — 每日重复数据
- `thino/` — 快速记录，非正式知识

### ⚙️ 系统目录（不可操作）
- `.obsidian/` — Obsidian 配置
- `.codebuddy/` — CodeBuddy 配置
- `02 WorkBuddy/` — 开发应用
- `08数据库/` — Bases 视图配置
- `Templates/` — 全库模板（读为主）

## 链接路径格式

Obsidian 使用 Vault 相对路径：

- ✅ `[[04成长/知识管理/004 注会/笔记名]]`
- ✅ `[[工作/亚马逊相关知识]]`
- ✅ `[[03Life os/05书籍/某书笔记]]`
- ✅ `[[AI Knowledge OS/Knowledge/企业 AI 转型]]`
- ❌ `/Users/guochenfa/Downloads/mutiply3/04成长/...`（绝对路径无效）
